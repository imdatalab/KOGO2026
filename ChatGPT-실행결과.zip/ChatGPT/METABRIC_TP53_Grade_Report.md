# METABRIC TP53 mutation, expression, and histological grade

## Methods
Source: METABRIC_RNA_Mutation.csv. Eligible participants had a histological grade of 1, 2, or 3. Grade 1–2 was combined as the reference group and compared with Grade 3. The source field `tp53_mut` was stripped of surrounding whitespace; the literal text `0` was encoded as 0 (**no mutation reported**), and any nonblank, nonzero mutation annotation was encoded as 1 (**mutation reported**). Blank and missing values were not encoded as 0. TP53 mRNA expression used the original `tp53` column without additional transformation. No grade imputation was used.

Primary TP53 mutation prevalence comparison: Pearson's chi-square test without continuity correction (all 2×2 expected counts ≥5), with a two-sided Fisher exact test as a sensitivity analysis. The **crude** odds ratio is the odds of a reported TP53 mutation in Grade 3 relative to Grade 1–2; its 95% confidence interval uses a log-odds (Wald) approximation (statsmodels Table2x2). Expression normality was inspected using group-wise skewness and Shapiro–Wilk tests. Mann–Whitney U (Grade 3 first) compared the expression distributions, with Welch's t-test as a sensitivity analysis. Two-sided p-values; no multiplicity correction was applied.

## Analyzed population and mutation coding
- Original records: 1,904
- Excluded (grade missing): 72
- Final Grade 1–2: 905; Grade 3: 927; Total: 1,832.
- TP53 annotation missing among eligible patients: 0; TP53 expression missing: 0.

## TP53 mutation prevalence
| Status | Grade 1–2 (n=905) | Grade 3 (n=927) |
|---|---:|---:|
| TP53 mutation reported | 140 (15.47%) | 507 (54.69%) |
| No mutation reported | 765 (84.53%) | 420 (45.31%) |

- Primary test: Pearson chi-square (without Yates correction), χ²(1) = 308.398, p = 4.87774e-69.
- Unadjusted OR = 6.596, 95% Wald CI [5.284, 8.234].
- Two-sided Fisher exact sensitivity p = 7.40411e-72.
- Difference in prevalence (Grade 3 − Grade 1–2) = 39.22 percentage points.

## TP53 mRNA expression
| Statistic | Grade 1–2 | Grade 3 |
|---|---:|---:|
| n (nonmissing) | 905 | 927 |
| Mean ± SD | 0.0213 ± 0.8448 | -0.0170 ± 1.1401 |
| Median (Q1–Q3) | 0.0106 (-0.5277–0.5820) | -0.0780 (-0.8898–0.7209) |
| Skewness | -0.018 | 0.486 |
| Shapiro–Wilk p | 0.1181 | 1.071e-08 |

Mann–Whitney U (Grade 3 first) = 396837; p = 0.045600. Rank-biserial correlation = -0.0540. The Welch sensitivity t-test gave t = -0.819, df = 1707.3, p = 0.413006. Median difference (Grade 3 − Grade 1–2) = -0.0886 (source-data units).

## Mutation ascertainment sensitivity
`mutation_count` was missing for 45 grade-eligible records (27 in Grade 1–2 and 18 in Grade 3); all had `tp53_mut = '0'`. Omitting these cases: N = 1787; OR = 6.648 (95% CI 5.319–8.310); chi-square p = 1.10887e-68. This sensitivity analysis addresses ambiguity of the zero annotation in these records, not all potential measurement errors.

## Figure legends (academic English)
**Figure 1. Frequency of reported TP53 mutations according to histological grade.** Bars indicate the percentages of patients with and without a reported TP53 mutation in Grade 1–2 (n = 905) and Grade 3 (n = 927). Labels above the bars show percentages and patient counts. Mutation status was derived from `tp53_mut`, with the literal string `0` defined as no mutation reported and a nonzero mutation annotation defined as mutation reported. The source annotation `0` does not independently establish wild-type status. The between-group comparison was performed using Pearson's chi-square test.

**Figure 2. Distribution of TP53 mRNA expression according to histological grade.** Box plots show TP53 mRNA expression for Grade 1–2 (n = 905) and Grade 3 (n = 927) using values from the source-data `tp53` field. The central line represents the median; box limits indicate the 25th and 75th percentiles; whiskers extend to the most extreme values within 1.5 times the interquartile range, and points beyond the whiskers represent outliers. Distributions were compared using a two-sided Mann–Whitney U test (p = 0.0456). No additional expression normalization was performed.

## Interpretation and limitations
Grade 3 was associated with a higher frequency of reported TP53 mutations than Grade 1–2 (crude OR 6.60); no causal claim is supported. TP53 mRNA expression showed a small distributional shift by the Mann–Whitney test, but rank-biserial effect size was near zero and a Welch comparison of means was nonsignificant. These are unadjusted exploratory associations. Measurement platform/normalization cannot be inferred solely from the CSV. Importantly, a recorded mutation annotation of `0` denotes no reported variant and is not equivalent to independently confirmed wild type.
