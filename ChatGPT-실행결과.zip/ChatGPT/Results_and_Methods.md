# METABRIC Grade 3 classification: executed results

## Design
N=1832 after excluding 72 missing-grade records. 
Train n=1465 (Grade 3=741); test n=367 (Grade 3=186).
The **test set was isolated before imputation/scaling/encoding**. All 4 prespecified models were tuned using only training-set stratified 5-fold CV; CV selection metric was AUROC.

## Best training-CV results

| algorithm           | feature_set    | selection_criterion                       | best_parameters                                                 |   CV_AUROC_mean |   CV_AUROC_SD |   CV_AUPRC_mean |   CV_AUPRC_SD |
|:--------------------|:---------------|:------------------------------------------|:----------------------------------------------------------------|----------------:|--------------:|----------------:|--------------:|
| Logistic Regression | Clinical-only  | Maximum mean training-set 5-fold CV AUROC | {"classifier__C": 10.0}                                         |          0.7440 |        0.0203 |          0.7612 |        0.0180 |
| Logistic Regression | Clinical + RNA | Maximum mean training-set 5-fold CV AUROC | {"classifier__C": 10.0}                                         |          0.7712 |        0.0149 |          0.7853 |        0.0213 |
| Random Forest       | Clinical-only  | Maximum mean training-set 5-fold CV AUROC | {"classifier__max_depth": 8, "classifier__min_samples_leaf": 5} |          0.7507 |        0.0136 |          0.7722 |        0.0174 |
| Random Forest       | Clinical + RNA | Maximum mean training-set 5-fold CV AUROC | {"classifier__max_depth": 8, "classifier__min_samples_leaf": 1} |          0.7700 |        0.0101 |          0.7872 |        0.0169 |

## Held-out test performance (threshold 0.5)

| algorithm           | feature_set    |   test_n |   test_grade3_n |   decision_threshold |   AUROC |   AUPRC_average_precision |   Accuracy |   Sensitivity |   Specificity |   F1_score |   TN |   FP |   FN |   TP |
|:--------------------|:---------------|---------:|----------------:|---------------------:|--------:|--------------------------:|-----------:|--------------:|--------------:|-----------:|-----:|-----:|-----:|-----:|
| Logistic Regression | Clinical-only  |      367 |             186 |               0.5000 |  0.7505 |                    0.7877 |     0.6921 |        0.5753 |        0.8122 |     0.6544 |  147 |   34 |   79 |  107 |
| Logistic Regression | Clinical + RNA |      367 |             186 |               0.5000 |  0.7774 |                    0.8003 |     0.7057 |        0.6505 |        0.7624 |     0.6914 |  138 |   43 |   65 |  121 |
| Random Forest       | Clinical-only  |      367 |             186 |               0.5000 |  0.7509 |                    0.7712 |     0.6812 |        0.6022 |        0.7624 |     0.6569 |  138 |   43 |   74 |  112 |
| Random Forest       | Clinical + RNA |      367 |             186 |               0.5000 |  0.7837 |                    0.7944 |     0.7030 |        0.6505 |        0.7569 |     0.6895 |  137 |   44 |   65 |  121 |

## Paired held-out incremental comparison (integrated minus clinical)

| algorithm           |   Delta_AUROC_B_minus_A |   Delta_AUPRC_B_minus_A |   Delta_Accuracy_B_minus_A |   Delta_Sensitivity_B_minus_A |   Delta_Specificity_B_minus_A |   Delta_F1_B_minus_A |   Delta_AUROC_CI_lower |   Delta_AUROC_CI_upper |   Delta_AUPRC_CI_lower |   Delta_AUPRC_CI_upper |
|:--------------------|------------------------:|------------------------:|---------------------------:|------------------------------:|------------------------------:|---------------------:|-----------------------:|-----------------------:|-----------------------:|-----------------------:|
| Logistic Regression |                  0.0269 |                  0.0126 |                     0.0136 |                        0.0753 |                       -0.0497 |               0.0370 |                -0.0044 |                 0.0591 |                -0.0158 |                 0.0389 |
| Random Forest       |                  0.0328 |                  0.0231 |                     0.0218 |                        0.0484 |                       -0.0055 |               0.0326 |                -0.0016 |                 0.0675 |                -0.0094 |                 0.0566 |

## Interpretation and limitations

- These values are internal holdout estimates from one fixed 80:20 split, NOT independent external validation.
- The bootstrap CI for model differences conditions on fixed fitted models and the single held-out sample.
- AUPRC is average precision (non-interpolated definition).
- Classification metrics use a prespecified probability threshold of 0.5; 1 denotes Grade 3.
- Predictors are limited to the exact columns requested; Grade-derived and outcome variables are excluded.
- Clinical/RNA collection timing is unverified; results do not establish early prediction or clinical utility.
- Observed differences between feature sets cannot be interpreted causally.
