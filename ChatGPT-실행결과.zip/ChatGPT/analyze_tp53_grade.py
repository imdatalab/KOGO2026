#!/usr/bin/env python3
"""Reproducible METABRIC: TP53 mutation/expression versus histological grade.

Usage:
    python analyze_tp53_grade.py \
      --input METABRIC_RNA_Mutation.csv --output-dir .

Analysis population: histological Grade 1, 2, or 3. Binary target:
Grade 1-2 versus Grade 3. '0' in tp53_mut denotes NO REPORTED mutation,
not verified wild-type status. Other nonblank strings denote REPORTED mutation.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.contingency_tables import Table2x2
from statsmodels.stats.proportion import proportion_confint

GROUPS = ["Grade 1–2", "Grade 3"]


def as_pretty_p(p: float) -> str:
    return f"{p:.3e}" if p < 0.001 else f"{p:.4f}"


def load_data(path: Path) -> tuple[pd.DataFrame, pd.DataFrame, int]:
    df = pd.read_csv(path, dtype={"tp53_mut": "string"}, low_memory=False)
    required = ["patient_id", "neoplasm_histologic_grade", "tp53_mut", "tp53", "mutation_count"]
    missing_cols = sorted(set(required) - set(df.columns))
    if missing_cols:
        raise ValueError(f"Required columns absent: {missing_cols}")
    if df["patient_id"].duplicated().any():
        raise ValueError("Duplicated patient_id detected: confirm patient-level data before proceeding.")

    grade = pd.to_numeric(df["neoplasm_histologic_grade"], errors="coerce")
    unknown_grade_n = int((grade.notna() & ~grade.isin([1, 2, 3])).sum())
    if unknown_grade_n:
        raise ValueError(f"Unrecognized nonmissing histological grades: {unknown_grade_n}")
    study = df.loc[grade.isin([1, 2, 3]), required].copy()
    study["histological_grade"] = grade.loc[study.index].astype(int)
    study["grade_group"] = np.where(study["histological_grade"].eq(3), GROUPS[1], GROUPS[0])

    # Preserve distinction between literal '0', reported nonzero text, and missing text.
    raw = study["tp53_mut"].astype("string").str.strip()
    missing_mut = raw.isna() | raw.eq("").fillna(False)
    is_zero = raw.eq("0").fillna(False)
    mutation = pd.Series(pd.NA, index=study.index, dtype="Int64")
    mutation.loc[is_zero] = 0
    mutation.loc[(~missing_mut) & (~is_zero)] = 1
    study["TP53_mut_binary"] = mutation
    study["tp53_expression"] = pd.to_numeric(study["tp53"], errors="coerce")
    study["mutation_count"] = pd.to_numeric(study["mutation_count"], errors="coerce")
    return df, study, unknown_grade_n


def count_group_mutations(study: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for group in GROUPS:
        sub = study.loc[study["grade_group"].eq(group)]
        mutation = sub["TP53_mut_binary"]
        n_yes, n_no = int(mutation.eq(1).sum()), int(mutation.eq(0).sum())
        n_miss = int(mutation.isna().sum())
        n_valid = n_yes + n_no
        low, high = proportion_confint(n_yes, n_valid, alpha=0.05, method="wilson") if n_valid else (np.nan, np.nan)
        rows.append({
            "Histological grade group": group,
            "N (all grade-eligible)": len(sub),
            "TP53 mutation reported (n)": n_yes,
            "No TP53 mutation reported (n)": n_no,
            "TP53 mutation field missing (n)": n_miss,
            "N valid mutation annotations": n_valid,
            "Mutation frequency (%)": 100.0 * n_yes / n_valid if n_valid else np.nan,
            "Mutation frequency 95% CI lower (%)": 100.0 * low,
            "Mutation frequency 95% CI upper (%)": 100.0 * high,
        })
    return pd.DataFrame(rows)


def association_analysis(freq: pd.DataFrame) -> dict:
    group12 = freq.iloc[0]
    group3 = freq.iloc[1]
    # First row: Grade 3, second row: Grade 1-2; first column: reported mutation.
    tab = np.array([
        [int(group3["TP53 mutation reported (n)"]), int(group3["No TP53 mutation reported (n)"])],
        [int(group12["TP53 mutation reported (n)"]), int(group12["No TP53 mutation reported (n)"])],
    ], dtype=int)
    if np.any(tab == 0):
        # statsmodels uses continuity correction for odds ratio when a cell is zero.
        zero_cell_note = "At least one zero cell: Table2x2 shifts zero cells for the OR/CI."
    else:
        zero_cell_note = "No zero cells."
    chi2 = stats.chi2_contingency(tab, correction=False)
    fisher_or, fisher_p = stats.fisher_exact(tab, alternative="two-sided")
    t = Table2x2(tab)
    or_low, or_high = t.oddsratio_confint(alpha=0.05, method="normal")
    main_test = "Pearson chi-square (without Yates correction)" if np.all(chi2.expected_freq >= 5) else "Fisher exact (two-sided)"
    main_p = float(chi2.pvalue) if np.all(chi2.expected_freq >= 5) else float(fisher_p)
    return {
        "table": tab,
        "expected": chi2.expected_freq,
        "test": main_test,
        "p": main_p,
        "chi2": float(chi2.statistic),
        "chi2_p": float(chi2.pvalue),
        "fisher_or": float(fisher_or),
        "fisher_p": float(fisher_p),
        "or": float(t.oddsratio),
        "or_low": float(or_low),
        "or_high": float(or_high),
        "zero_cell_note": zero_cell_note,
        "grade3_frequency": tab[0, 0] / tab[0].sum(),
        "grade12_frequency": tab[1, 0] / tab[1].sum(),
    }


def expression_analysis(study: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    stats_rows = []
    sample_by_group = {}
    for g in GROUPS:
        series = study.loc[study["grade_group"].eq(g), "tp53_expression"]
        x = series.loc[np.isfinite(series)].to_numpy(dtype=float)
        sample_by_group[g] = x
        sw_p = float(stats.shapiro(x).pvalue) if 3 <= len(x) <= 5000 else np.nan
        stats_rows.append({
            "Histological grade group": g,
            "Expression nonmissing (n)": len(x),
            "Expression missing (n)": int(series.isna().sum()),
            "Mean": float(np.mean(x)),
            "SD (sample)": float(np.std(x, ddof=1)),
            "Median": float(np.median(x)),
            "Q1": float(np.quantile(x, 0.25)),
            "Q3": float(np.quantile(x, 0.75)),
            "Minimum": float(np.min(x)),
            "Maximum": float(np.max(x)),
            "Skewness": float(stats.skew(x)),
            "Shapiro-Wilk p": sw_p,
        })
    x12 = sample_by_group[GROUPS[0]]
    x3 = sample_by_group[GROUPS[1]]
    mwu = stats.mannwhitneyu(x3, x12, alternative="two-sided", method="asymptotic")
    welch = stats.ttest_ind(x3, x12, equal_var=False, alternative="two-sided")
    result = {
        "mwu": float(mwu.statistic),
        "mwu_p": float(mwu.pvalue),
        "rank_biserial": float(2 * mwu.statistic / (len(x3) * len(x12)) - 1),
        "welch_t": float(welch.statistic),
        "welch_p": float(welch.pvalue),
        "welch_df": float(welch.df),
        "median_difference_grade3_minus_grade12": float(np.median(x3) - np.median(x12)),
        "mean_difference_grade3_minus_grade12": float(np.mean(x3) - np.mean(x12)),
        "data": sample_by_group,
    }
    return pd.DataFrame(stats_rows), result


def mutate_fig(freq: pd.DataFrame, path: Path) -> None:
    pct_mut = freq["Mutation frequency (%)"].to_numpy(float)
    pct_no = 100.0 - pct_mut
    no_counts = freq["No TP53 mutation reported (n)"].to_numpy(int)
    yes_counts = freq["TP53 mutation reported (n)"].to_numpy(int)
    x = np.arange(len(GROUPS))
    w = 0.34
    fig, ax = plt.subplots(figsize=(7.0, 4.6), facecolor="white")
    ax.set_facecolor("white")
    b0 = ax.bar(x - w/2, pct_no, width=w, label="No TP53 mutation reported")
    b1 = ax.bar(x + w/2, pct_mut, width=w, label="TP53 mutation reported")
    ax.bar_label(b0, labels=[f"{p:.1f}%\n(n={n})" for p, n in zip(pct_no, no_counts)], padding=3, fontsize=9)
    ax.bar_label(b1, labels=[f"{p:.1f}%\n(n={n})" for p, n in zip(pct_mut, yes_counts)], padding=3, fontsize=9)
    ax.set_xticks(x, [f"{g}\n(n={n:,})" for g, n in zip(GROUPS, freq["N (all grade-eligible)"])])
    ax.set_ylim(0, 108)
    ax.set_xlabel("Histological grade", labelpad=9)
    ax.set_ylabel("Patients within grade group (%)", labelpad=9)
    ax.set_title("TP53 mutation frequency by histological grade", pad=15, fontsize=13)
    ax.legend(title="Mutation annotation", loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=2, frameon=False, fontsize=9, title_fontsize=9)
    ax.yaxis.grid(True, linestyle=":", alpha=0.25)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.savefig(path, dpi=450, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def expression_fig(expr: dict, path: Path) -> None:
    x12, x3 = expr["data"][GROUPS[0]], expr["data"][GROUPS[1]]
    fig, ax = plt.subplots(figsize=(6.4, 4.8), facecolor="white")
    ax.set_facecolor("white")
    box = ax.boxplot([x12, x3], widths=0.50, showfliers=True, whis=1.5,
                     patch_artist=False, tick_labels=[f"Grade 1–2\n(n={len(x12):,})", f"Grade 3\n(n={len(x3):,})"],
                     flierprops={"markersize": 3, "alpha": 0.45})
    ax.legend([box["medians"][0], box["boxes"][0]], ["Median", "Interquartile range"],
              loc="upper left", frameon=False, fontsize=9)
    ax.set_ylim(min(float(np.min(x12)), float(np.min(x3))) - 0.4,
                max(float(np.max(x12)), float(np.max(x3))) + 1.1)
    ax.text(0.97, 0.97, f"Mann–Whitney U p = {expr['mwu_p']:.4f}",
            ha="right", va="top", transform=ax.transAxes, fontsize=9)
    ax.set_xlabel("Histological grade", labelpad=9)
    ax.set_ylabel("TP53 mRNA expression (source-data scale)", labelpad=9)
    ax.set_title("TP53 mRNA expression by histological grade", pad=15, fontsize=13)
    ax.yaxis.grid(True, linestyle=":", alpha=0.25)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.savefig(path, dpi=450, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def create_report(path: Path, raw: pd.DataFrame, study: pd.DataFrame, freq: pd.DataFrame, assoc: dict,
                  exp_table: pd.DataFrame, exp: dict, sen: dict) -> None:
    g12, g3 = freq.iloc[0], freq.iloc[1]
    x12, x3 = exp_table.iloc[0], exp_table.iloc[1]
    txt = f"""# METABRIC TP53 mutation, expression, and histological grade

## Methods
Source: METABRIC_RNA_Mutation.csv. Eligible participants had a histological grade of 1, 2, or 3. Grade 1–2 was combined as the reference group and compared with Grade 3. The source field `tp53_mut` was stripped of surrounding whitespace; the literal text `0` was encoded as 0 (**no mutation reported**), and any nonblank, nonzero mutation annotation was encoded as 1 (**mutation reported**). Blank and missing values were not encoded as 0. TP53 mRNA expression used the original `tp53` column without additional transformation. No grade imputation was used.

Primary TP53 mutation prevalence comparison: Pearson's chi-square test without continuity correction (all 2×2 expected counts ≥5), with a two-sided Fisher exact test as a sensitivity analysis. The **crude** odds ratio is the odds of a reported TP53 mutation in Grade 3 relative to Grade 1–2; its 95% confidence interval uses a log-odds (Wald) approximation (statsmodels Table2x2). Expression normality was inspected using group-wise skewness and Shapiro–Wilk tests. Mann–Whitney U (Grade 3 first) compared the expression distributions, with Welch's t-test as a sensitivity analysis. Two-sided p-values; no multiplicity correction was applied.

## Analyzed population and mutation coding
- Original records: {len(raw):,}
- Excluded (grade missing): {raw['neoplasm_histologic_grade'].isna().sum():,}
- Final Grade 1–2: {int(g12['N (all grade-eligible)']):,}; Grade 3: {int(g3['N (all grade-eligible)']):,}; Total: {len(study):,}.
- TP53 annotation missing among eligible patients: {study['TP53_mut_binary'].isna().sum():,}; TP53 expression missing: {study['tp53_expression'].isna().sum():,}.

## TP53 mutation prevalence
| Status | Grade 1–2 (n={int(g12['N (all grade-eligible)'])}) | Grade 3 (n={int(g3['N (all grade-eligible)'])}) |
|---|---:|---:|
| TP53 mutation reported | {int(g12['TP53 mutation reported (n)'])} ({g12['Mutation frequency (%)']:.2f}%) | {int(g3['TP53 mutation reported (n)'])} ({g3['Mutation frequency (%)']:.2f}%) |
| No mutation reported | {int(g12['No TP53 mutation reported (n)'])} ({100-g12['Mutation frequency (%)']:.2f}%) | {int(g3['No TP53 mutation reported (n)'])} ({100-g3['Mutation frequency (%)']:.2f}%) |

- Primary test: {assoc['test']}, χ²(1) = {assoc['chi2']:.3f}, p = {assoc['chi2_p']:.6g}.
- Unadjusted OR = {assoc['or']:.3f}, 95% Wald CI [{assoc['or_low']:.3f}, {assoc['or_high']:.3f}].
- Two-sided Fisher exact sensitivity p = {assoc['fisher_p']:.6g}.
- Difference in prevalence (Grade 3 − Grade 1–2) = {100*(assoc['grade3_frequency']-assoc['grade12_frequency']):.2f} percentage points.

## TP53 mRNA expression
| Statistic | Grade 1–2 | Grade 3 |
|---|---:|---:|
| n (nonmissing) | {int(x12['Expression nonmissing (n)'])} | {int(x3['Expression nonmissing (n)'])} |
| Mean ± SD | {x12['Mean']:.4f} ± {x12['SD (sample)']:.4f} | {x3['Mean']:.4f} ± {x3['SD (sample)']:.4f} |
| Median (Q1–Q3) | {x12['Median']:.4f} ({x12['Q1']:.4f}–{x12['Q3']:.4f}) | {x3['Median']:.4f} ({x3['Q1']:.4f}–{x3['Q3']:.4f}) |
| Skewness | {x12['Skewness']:.3f} | {x3['Skewness']:.3f} |
| Shapiro–Wilk p | {as_pretty_p(x12['Shapiro-Wilk p'])} | {as_pretty_p(x3['Shapiro-Wilk p'])} |

Mann–Whitney U (Grade 3 first) = {exp['mwu']:.0f}; p = {exp['mwu_p']:.6f}. Rank-biserial correlation = {exp['rank_biserial']:.4f}. The Welch sensitivity t-test gave t = {exp['welch_t']:.3f}, df = {exp['welch_df']:.1f}, p = {exp['welch_p']:.6f}. Median difference (Grade 3 − Grade 1–2) = {exp['median_difference_grade3_minus_grade12']:.4f} (source-data units).

## Mutation ascertainment sensitivity
`mutation_count` was missing for {int(study['mutation_count'].isna().sum())} grade-eligible records ({int(study.loc[(study.grade_group == GROUPS[0]), 'mutation_count'].isna().sum())} in Grade 1–2 and {int(study.loc[(study.grade_group == GROUPS[1]), 'mutation_count'].isna().sum())} in Grade 3); all had `tp53_mut = '0'`. Omitting these cases: N = {sen['n']}; OR = {sen['or']:.3f} (95% CI {sen['or_low']:.3f}–{sen['or_high']:.3f}); chi-square p = {sen['p']:.6g}. This sensitivity analysis addresses ambiguity of the zero annotation in these records, not all potential measurement errors.

## Figure legends (academic English)
**Figure 1. Frequency of reported TP53 mutations according to histological grade.** Bars indicate the percentages of patients with and without a reported TP53 mutation in Grade 1–2 (n = {int(g12['N (all grade-eligible)'])}) and Grade 3 (n = {int(g3['N (all grade-eligible)'])}). Labels above the bars show percentages and patient counts. Mutation status was derived from `tp53_mut`, with the literal string `0` defined as no mutation reported and a nonzero mutation annotation defined as mutation reported. The source annotation `0` does not independently establish wild-type status. The between-group comparison was performed using Pearson's chi-square test.

**Figure 2. Distribution of TP53 mRNA expression according to histological grade.** Box plots show TP53 mRNA expression for Grade 1–2 (n = {len(exp['data'][GROUPS[0]])}) and Grade 3 (n = {len(exp['data'][GROUPS[1]])}) using values from the source-data `tp53` field. The central line represents the median; box limits indicate the 25th and 75th percentiles; whiskers extend to the most extreme values within 1.5 times the interquartile range, and points beyond the whiskers represent outliers. Distributions were compared using a two-sided Mann–Whitney U test (p = {exp['mwu_p']:.4f}). No additional expression normalization was performed.

## Interpretation and limitations
Grade 3 was associated with a higher frequency of reported TP53 mutations than Grade 1–2 (crude OR {assoc['or']:.2f}); no causal claim is supported. TP53 mRNA expression showed a small distributional shift by the Mann–Whitney test, but rank-biserial effect size was near zero and a Welch comparison of means was nonsignificant. These are unadjusted exploratory associations. Measurement platform/normalization cannot be inferred solely from the CSV. Importantly, a recorded mutation annotation of `0` denotes no reported variant and is not equivalent to independently confirmed wild type.
"""
    path.write_text(txt, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="METABRIC_RNA_Mutation.csv", type=Path)
    parser.add_argument("--output-dir", default=".", type=Path)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    raw, study, _ = load_data(args.input)
    freq = count_group_mutations(study)
    association = association_analysis(freq)
    exp_table, exp = expression_analysis(study)

    sensit = study.loc[study["mutation_count"].notna()]
    sen_assoc = association_analysis(count_group_mutations(sensit))
    sen = {"n": len(sensit), "or": sen_assoc["or"], "or_low": sen_assoc["or_low"],
           "or_high": sen_assoc["or_high"], "p": sen_assoc["chi2_p"]}

    study[["patient_id", "histological_grade", "grade_group", "tp53_mut", "TP53_mut_binary", "tp53_expression", "mutation_count"]].to_csv(
        output / "METABRIC_TP53_Derived_Cohort.csv", index=False, encoding="utf-8-sig")
    freq.to_csv(output / "METABRIC_TP53_Mutation_Frequency.csv", index=False, encoding="utf-8-sig")
    exp_table.to_csv(output / "METABRIC_TP53_Expression_Summary.csv", index=False, encoding="utf-8-sig")

    results = pd.DataFrame([
        {"Analysis": "Mutation association (Grade 3 vs Grade 1–2)", "Method": association["test"], "Statistic": association["chi2"], "P-value": association["p"],
         "Effect size": "Crude OR", "Effect value": association["or"], "95% CI lower": association["or_low"], "95% CI upper": association["or_high"], "N": int(freq["N valid mutation annotations"].sum())},
        {"Analysis": "Mutation association: Fisher sensitivity", "Method": "Fisher exact (two-sided)", "Statistic": association["fisher_or"], "P-value": association["fisher_p"],
         "Effect size": "Fisher sample OR", "Effect value": association["fisher_or"], "95% CI lower": np.nan, "95% CI upper": np.nan, "N": int(freq["N valid mutation annotations"].sum())},
        {"Analysis": "mRNA expression (Grade 3 vs Grade 1–2)", "Method": "Mann–Whitney U (two-sided)", "Statistic": exp["mwu"], "P-value": exp["mwu_p"],
         "Effect size": "Rank-biserial correlation", "Effect value": exp["rank_biserial"], "95% CI lower": np.nan, "95% CI upper": np.nan, "N": sum(exp_table["Expression nonmissing (n)"])},
        {"Analysis": "mRNA expression: mean sensitivity", "Method": "Welch's t-test (two-sided)", "Statistic": exp["welch_t"], "P-value": exp["welch_p"],
         "Effect size": "Mean difference (Grade 3 minus Grade 1–2)", "Effect value": exp["mean_difference_grade3_minus_grade12"], "95% CI lower": np.nan, "95% CI upper": np.nan, "N": sum(exp_table["Expression nonmissing (n)"])},
        {"Analysis": "Mutation association: excluding missing mutation_count", "Method": "Pearson chi-square (without Yates correction)", "Statistic": sen_assoc["chi2"], "P-value": sen["p"],
         "Effect size": "Crude OR", "Effect value": sen["or"], "95% CI lower": sen["or_low"], "95% CI upper": sen["or_high"], "N": sen["n"]},
    ])
    results.to_csv(output / "METABRIC_TP53_Statistical_Tests.csv", index=False, encoding="utf-8-sig")
    mutate_fig(freq, output / "Figure_1_TP53_Mutation_Frequency.png")
    expression_fig(exp, output / "Figure_2_TP53_mRNA_Expression.png")
    create_report(output / "METABRIC_TP53_Grade_Report.md", raw, study, freq, association, exp_table, exp, sen)

    print(f"Raw N: {len(raw)}, grade missing: {raw['neoplasm_histologic_grade'].isna().sum()}, included N: {len(study)}")
    print("TP53 mutation coding: '0' -> 0; nonzero, nonblank annotations -> 1; missing -> NA")
    print(freq.to_string(index=False, float_format=lambda f: f"{f:.5f}"))
    print(f"Primary mutation association: chi-square(1)={association['chi2']:.6f}, p={association['chi2_p']:.12g}, "
          f"OR={association['or']:.6f}, 95% CI=({association['or_low']:.6f}, {association['or_high']:.6f}); Fisher p={association['fisher_p']:.12g}")
    print(exp_table.to_string(index=False, float_format=lambda f: f"{f:.6f}"))
    print(f"Expression MW U(Grade3 first)={exp['mwu']:.1f}, p={exp['mwu_p']:.8g}, RBC={exp['rank_biserial']:.6f}; "
          f"Welch t={exp['welch_t']:.6f}, df={exp['welch_df']:.3f}, p={exp['welch_p']:.8g}")
    print(f"Sensitivity excluded missing mutation_count: N={sen['n']}, OR={sen['or']:.6f}, "
          f"95% CI ({sen['or_low']:.6f},{sen['or_high']:.6f}), p={sen['p']:.12g}")
    for p in sorted(output.glob("*TP53*")):
        if p.is_file():
            print(f"Created: {p.name} ({p.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
