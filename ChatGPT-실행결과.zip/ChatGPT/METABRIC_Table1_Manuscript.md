**Table 1. Clinicopathological characteristics of patients with recorded histological Grade 1–2 versus Grade 3 in the METABRIC cohort.**

| Characteristic | Overall (N = 1,832) | Grade 1–2 (n = 905) | Grade 3 (n = 927) | Missing, n [G1–2; G3] | p-value |
|---|---:|---:|---:|---:|---:|
| **Demographic characteristics** |  |  |  |  |  |
| **Age at diagnosis, years** | 60.9 ± 13.0 | 62.7 ± 12.4 | 59.2 ± 13.4 | 0 [0; 0] | <0.001 |
| **Inferred menopausal state** |  |  |  | 0 [0; 0] | <0.001 |
| ↳ Pre | 405 (22.1%) | 161 (17.8%) | 244 (26.3%) |  |  |
| ↳ Post | 1,427 (77.9%) | 744 (82.2%) | 683 (73.7%) |  |  |
| **Clinicopathological characteristics** |  |  |  |  |  |
| **Tumor size (recorded units)** | 23.0 (17.0–30.0) | 20.0 (16.0–29.0) | 25.0 (19.0–32.2) | 17 [10; 7] | <0.001 |
| **Positive lymph nodes, n** | 0 (0–2) | 0 (0–1) | 1 (0–3) | 0 [0; 0] | <0.001 |
| **Estrogen receptor status** |  |  |  | 0 [0; 0] | <0.001 |
| ↳ Positive | 1,396 (76.2%) | 845 (93.4%) | 551 (59.4%) |  |  |
| ↳ Negative | 436 (23.8%) | 60 (6.6%) | 376 (40.6%) |  |  |
| **Progesterone receptor status** |  |  |  | 0 [0; 0] | <0.001 |
| ↳ Positive | 959 (52.3%) | 621 (68.6%) | 338 (36.5%) |  |  |
| ↳ Negative | 873 (47.7%) | 284 (31.4%) | 589 (63.5%) |  |  |
| **HER2 status** |  |  |  | 0 [0; 0] | <0.001 |
| ↳ Positive | 229 (12.5%) | 53 (5.9%) | 176 (19.0%) |  |  |
| ↳ Negative | 1,603 (87.5%) | 852 (94.1%) | 751 (81.0%) |  |  |
| **Tumor cellularity** |  |  |  | 52 [32; 20] | 0.017 |
| ↳ Low | 192 (10.8%) | 98 (11.2%) | 94 (10.4%) |  |  |
| ↳ Moderate | 673 (37.8%) | 356 (40.8%) | 317 (35.0%) |  |  |
| ↳ High | 915 (51.4%) | 419 (48.0%) | 496 (54.7%) |  |  |
| **Histologic subtype (recorded)** |  |  |  | 14 [7; 7] | <0.001 |
| ↳ Ductal/NST | 1,406 (77.3%) | 616 (68.6%) | 790 (85.9%) |  |  |
| ↳ Mixed | 199 (10.9%) | 136 (15.1%) | 63 (6.8%) |  |  |
| ↳ Lobular | 132 (7.3%) | 91 (10.1%) | 41 (4.5%) |  |  |
| ↳ Medullary | 25 (1.4%) | 4 (0.4%) | 21 (2.3%) |  |  |
| ↳ Mucinous | 21 (1.2%) | 20 (2.2%) | 1 (0.1%) |  |  |
| ↳ Tubular/cribriform | 21 (1.2%) | 21 (2.3%) | 0 (0.0%) |  |  |
| ↳ Other | 14 (0.8%) | 10 (1.1%) | 4 (0.4%) |  |  |
| **Recorded tumor stage** |  |  |  | 476 [257; 219] | <0.001 |
| ↳ Stage 0 | 1 (0.1%) | 1 (0.2%) | 0 (0.0%) |  |  |
| ↳ Stage 1 | 457 (33.7%) | 273 (42.1%) | 184 (26.0%) |  |  |
| ↳ Stage 2 | 776 (57.2%) | 331 (51.1%) | 445 (62.9%) |  |  |
| ↳ Stage 3 | 113 (8.3%) | 38 (5.9%) | 75 (10.6%) |  |  |
| ↳ Stage 4 | 9 (0.7%) | 5 (0.8%) | 4 (0.6%) |  |  |
| **Primary tumor laterality** |  |  |  | 103 [48; 55] | 0.330 |
| ↳ Left | 894 (51.7%) | 433 (50.5%) | 461 (52.9%) |  |  |
| ↳ Right | 835 (48.3%) | 424 (49.5%) | 411 (47.1%) |  |  |
| **Dataset characteristics** |  |  |  |  |  |
| **METABRIC cohort** |  |  |  | 0 [0; 0] | <0.001 |
| ↳ Cohort 1 | 467 (25.5%) | 221 (24.4%) | 246 (26.5%) |  |  |
| ↳ Cohort 2 | 283 (15.4%) | 136 (15.0%) | 147 (15.9%) |  |  |
| ↳ Cohort 3 | 689 (37.6%) | 322 (35.6%) | 367 (39.6%) |  |  |
| ↳ Cohort 4 | 227 (12.4%) | 116 (12.8%) | 111 (12.0%) |  |  |
| ↳ Cohort 5 | 166 (9.1%) | 110 (12.2%) | 56 (6.0%) |  |  |

**Footnote.** Values are mean ± standard deviation (SD), median (first–third quartile [Q1–Q3]), or n (%), as appropriate. Percentages use the available-case denominator for each characteristic within each group. Missing n [G1–2; G3] denotes total missing observations [Grade 1–2 missing; Grade 3 missing]. For continuous characteristics, p-values were obtained using Welch’s two-sample t-test (age) or a two-sided Mann–Whitney U test (tumor size and positive lymph-node count). For categorical characteristics, Pearson’s chi-square test was applied when all expected cell counts were at least five; for sparse 2×k tables, the Fisher–Freeman–Halton exact test with Monte Carlo simulation (199,999 replicates; seed 20261004) was used. P-values are two-sided and unadjusted. All tests excluded missing observations on a per-characteristic basis. Of 1,904 original records, 72 with missing histological grade were excluded. No observations were removed on the basis of the clinical predictors. HER2, human epidermal growth factor receptor 2; NST, no special type. The physical units of tumor size must be checked against the original dataset documentation; no units were inferred from the CSV. Histological subtype, tumor stage, cellularity, laterality and cohort are descriptive characteristics, not necessarily predictors in the primary models.
