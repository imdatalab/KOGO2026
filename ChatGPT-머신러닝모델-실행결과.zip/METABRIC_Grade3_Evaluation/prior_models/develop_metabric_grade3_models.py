#!/usr/bin/env python3
"""METABRIC exploratory Grade-3 classification.

Usage:
  python develop_metabric_grade3_models.py \
    --input METABRIC_RNA_Mutation.csv --output-dir METABRIC_Grade3_ML

No test-set operation is used for feature engineering, tuning or model selection.
Only predefined inputs are used; preprocessing is fitted inside sklearn Pipelines.
"""
from __future__ import annotations

import argparse
import json
import platform
from pathlib import Path

import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, average_precision_score, confusion_matrix, f1_score,
    precision_recall_curve, recall_score, roc_auc_score, roc_curve,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

SEED = 42
GRADE = 'neoplasm_histologic_grade'
CONTINUOUS_CLINICAL = [
    'age_at_diagnosis', 'tumor_size', 'lymph_nodes_examined_positive'
]
CATEGORICAL_CLINICAL = ['er_status', 'pr_status', 'her2_status']
RNA_FEATURES = ['brca1','brca2','tp53','pten','erbb2','pik3ca','ccnd1','myc']
CLINICAL_FEATURES = CONTINUOUS_CLINICAL + CATEGORICAL_CLINICAL
FEATURE_SETS = {'Clinical-only': CLINICAL_FEATURES,
                'Clinical + RNA': CLINICAL_FEATURES + RNA_FEATURES}


def preprocess(use_rna: bool) -> ColumnTransformer:
    numeric = CONTINUOUS_CLINICAL + (RNA_FEATURES if use_rna else [])
    numerical_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler()),
    ])
    categorical_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('encoder', OneHotEncoder(handle_unknown='ignore')),
    ])
    return ColumnTransformer(
        transformers=[('numeric', numerical_pipeline, numeric),
                      ('categorical', categorical_pipeline, CATEGORICAL_CLINICAL)],
        remainder='drop', sparse_threshold=0.0,
    )


def make_model(algorithm: str, use_rna: bool):
    if algorithm == 'Logistic Regression':
        classifier = LogisticRegression(
            penalty='l2', solver='lbfgs', max_iter=3000, random_state=SEED
        )
        grid = {'classifier__C': [0.01, 0.1, 1.0, 10.0]}
    elif algorithm == 'Random Forest':
        classifier = RandomForestClassifier(
            n_estimators=200, max_features='sqrt',
            bootstrap=True, class_weight=None,
            random_state=SEED, n_jobs=2,
        )
        grid = {'classifier__max_depth': [None, 8],
                'classifier__min_samples_leaf': [1, 5]}
    else:
        raise ValueError(f'Unsupported algorithm: {algorithm}')
    pipeline = Pipeline([
        ('preprocessor', preprocess(use_rna)),
        ('classifier', classifier),
    ])
    return pipeline, grid


def metrics(y_true, y_probability, threshold=0.5):
    y_pred = (np.asarray(y_probability) >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        'AUROC': float(roc_auc_score(y_true, y_probability)),
        'AUPRC_average_precision': float(average_precision_score(y_true, y_probability)),
        'Accuracy': float(accuracy_score(y_true, y_pred)),
        'Sensitivity': float(recall_score(y_true, y_pred, pos_label=1, zero_division=0)),
        'Specificity': float(tn / (tn + fp)),
        'F1_score': float(f1_score(y_true, y_pred, pos_label=1, zero_division=0)),
        'TN': int(tn), 'FP': int(fp), 'FN': int(fn), 'TP': int(tp),
    }


def paired_stratified_bootstrap_delta(y, p_a, p_b, repeats=2000, seed=42):
    """Descriptive CI conditional on fitted models and one fixed test split."""
    y = np.asarray(y, dtype=int)
    p_a, p_b = np.asarray(p_a), np.asarray(p_b)
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    rng = np.random.default_rng(seed)
    auc_delta, ap_delta = [], []
    for _ in range(repeats):
        draw = np.concatenate([
            rng.choice(pos, size=len(pos), replace=True),
            rng.choice(neg, size=len(neg), replace=True),
        ])
        yt = y[draw]
        auc_delta.append(roc_auc_score(yt, p_b[draw]) - roc_auc_score(yt, p_a[draw]))
        ap_delta.append(average_precision_score(yt, p_b[draw]) - average_precision_score(yt, p_a[draw]))
    return {
        'Delta_AUROC_CI_lower': float(np.percentile(auc_delta, 2.5)),
        'Delta_AUROC_CI_upper': float(np.percentile(auc_delta, 97.5)),
        'Delta_AUPRC_CI_lower': float(np.percentile(ap_delta, 2.5)),
        'Delta_AUPRC_CI_upper': float(np.percentile(ap_delta, 97.5)),
    }


def plot_curves(y_test, predictions, output_dir):
    # Deliberately plot each of the four prespecified models, irrespective of ranking.
    plt.rcParams.update({'font.size': 9, 'axes.spines.top': False,
                         'axes.spines.right': False, 'figure.facecolor': 'white',
                         'axes.facecolor': 'white', 'savefig.facecolor': 'white'})
    specs = {
        ('Clinical-only', 'Logistic Regression'): ('#325C86', '-', 'Clinical / LR'),
        ('Clinical + RNA', 'Logistic Regression'): ('#9B2743', '-', 'Clinical + RNA / LR'),
        ('Clinical-only', 'Random Forest'): ('#325C86', '--', 'Clinical / RF'),
        ('Clinical + RNA', 'Random Forest'): ('#9B2743', '--', 'Clinical + RNA / RF'),
    }
    f, ax = plt.subplots(figsize=(6.0, 5.1))
    for key, (color, ls, name) in specs.items():
        probs = predictions[key]
        x, tpr, _ = roc_curve(y_test, probs)
        auc = roc_auc_score(y_test, probs)
        ax.plot(x, tpr, color=color, linestyle=ls, lw=1.8, label=f'{name} (AUROC {auc:.3f})')
    ax.plot([0, 1], [0, 1], color='#888888', linestyle=':', lw=1)
    ax.set(xlabel='False positive rate (1 - Specificity)', ylabel='True positive rate (Sensitivity)',
           title='Grade 3 classification: held-out test set', xlim=(0, 1), ylim=(0, 1.01))
    ax.legend(loc='lower right', fontsize=8, frameon=False)
    f.tight_layout()
    f.savefig(output_dir/'Heldout_ROC.png', dpi=350, bbox_inches='tight')
    plt.close(f)

    f, ax = plt.subplots(figsize=(6.0, 5.1))
    for key, (color, ls, name) in specs.items():
        probs = predictions[key]
        precision, recall, _ = precision_recall_curve(y_test, probs)
        ap = average_precision_score(y_test, probs)
        ax.plot(recall, precision, color=color, linestyle=ls, lw=1.8,
                label=f'{name} (AP {ap:.3f})')
    ax.axhline(np.asarray(y_test).mean(), color='#888888', linestyle=':', lw=1,
               label=f'Grade 3 prevalence ({np.asarray(y_test).mean():.3f})')
    ax.set(xlabel='Recall (Sensitivity)', ylabel='Precision (Positive predictive value)',
           title='Grade 3 classification: held-out test set', xlim=(0, 1), ylim=(0, 1.01))
    ax.legend(loc='lower left', fontsize=8, frameon=False)
    f.tight_layout()
    f.savefig(output_dir/'Heldout_PR.png', dpi=350, bbox_inches='tight')
    plt.close(f)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, default=Path('METABRIC_RNA_Mutation.csv'))
    parser.add_argument('--output-dir', type=Path, default=Path('METABRIC_Grade3_ML'))
    args = parser.parse_args()
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    (out/'trained_models').mkdir(exist_ok=True)

    df = pd.read_csv(args.input, low_memory=False)
    expected = [GRADE, 'patient_id'] + CLINICAL_FEATURES + RNA_FEATURES
    absent = sorted(set(expected).difference(df.columns))
    if absent:
        raise ValueError(f'Missing columns: {absent}')
    if df['patient_id'].duplicated().any():
        raise ValueError('Duplicate patient_id; resolve subject-level grouping before splitting.')
    grades = pd.to_numeric(df[GRADE], errors='coerce')
    cohort = df.loc[grades.notna(), expected].copy()
    invalid = ~cohort[GRADE].isin([1, 2, 3])
    if invalid.any():
        raise ValueError(f'Noncanonical nonmissing grade values: {cohort.loc[invalid,GRADE].unique()}')
    cohort['target_grade3'] = (cohort[GRADE] == 3).astype(int)
    for column in CONTINUOUS_CLINICAL + RNA_FEATURES:
        cohort[column] = pd.to_numeric(cohort[column], errors='coerce')
        cohort[column] = cohort[column].replace([np.inf, -np.inf], np.nan)
    for column in CATEGORICAL_CLINICAL:
        cohort[column] = cohort[column].astype('string').str.strip().replace({'': pd.NA})
        # sklearn's imputer accepts Python object categoricals; no categorical code is imposed.
        cohort[column] = cohort[column].astype(object).where(cohort[column].notna(), np.nan)

    X = cohort[CLINICAL_FEATURES + RNA_FEATURES]
    y = cohort['target_grade3']
    patients = cohort['patient_id']
    idx_train, idx_test = train_test_split(
        np.arange(len(cohort)), test_size=0.20, stratify=y,
        shuffle=True, random_state=SEED,
    )
    X_train, X_test = X.iloc[idx_train], X.iloc[idx_test]
    y_train, y_test = y.iloc[idx_train], y.iloc[idx_test]
    assert set(patients.iloc[idx_train]).isdisjoint(set(patients.iloc[idx_test]))
    assert len(X_train) + len(X_test) == len(cohort)
    assert y_train.nunique() == y_test.nunique() == 2

    assignments = pd.DataFrame({
        'patient_id': np.r_[patients.iloc[idx_train].to_numpy(), patients.iloc[idx_test].to_numpy()],
        'partition': ['train'] * len(idx_train) + ['test'] * len(idx_test),
        'target_grade3': np.r_[y_train.to_numpy(), y_test.to_numpy()],
    })
    assignments.to_csv(out/'Split_Assignments.csv', index=False)
    missing = pd.DataFrame({
        'variable': X.columns,
        'training_missing_n': X_train.isna().sum().reindex(X.columns).to_numpy(),
        'test_missing_n': X_test.isna().sum().reindex(X.columns).to_numpy(),
    })
    missing.to_csv(out/'Predictor_Missingness_By_Split.csv', index=False)

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    # Model selection based only on CV AUROC in the Training Set.
    scorers = {'AUROC': 'roc_auc', 'AUPRC': 'average_precision'}
    all_cv_rows, best_rows, test_rows = [], [], []
    predictions = {}
    pred_table = pd.DataFrame({'patient_id': patients.iloc[idx_test].to_numpy(),
                               'observed_grade3': y_test.to_numpy()})

    for algorithm in ['Logistic Regression', 'Random Forest']:
        for feature_set, features in FEATURE_SETS.items():
            pipeline, parameters = make_model(algorithm, feature_set == 'Clinical + RNA')
            gs = GridSearchCV(
                estimator=pipeline, param_grid=parameters,
                scoring=scorers, refit='AUROC',
                cv=cv, n_jobs=1, return_train_score=True,
                error_score='raise',
            )
            gs.fit(X_train[features], y_train)
            cv_table = pd.DataFrame(gs.cv_results_)
            for j, row in cv_table.iterrows():
                all_cv_rows.append({
                    'algorithm': algorithm, 'feature_set': feature_set,
                    'candidate_index': int(j),
                    'hyperparameters': json.dumps(row['params'], sort_keys=True),
                    'CV_AUROC_mean': float(row['mean_test_AUROC']),
                    'CV_AUROC_SD': float(row['std_test_AUROC']),
                    'CV_AUPRC_mean': float(row['mean_test_AUPRC']),
                    'CV_AUPRC_SD': float(row['std_test_AUPRC']),
                    'CV_train_AUROC_mean': float(row['mean_train_AUROC']),
                    'CV_rank_AUROC': int(row['rank_test_AUROC']),
                })
            ix = gs.best_index_
            best_rows.append({
                'algorithm': algorithm, 'feature_set': feature_set,
                'selection_criterion': 'Maximum mean training-set 5-fold CV AUROC',
                'best_parameters': json.dumps(gs.best_params_, sort_keys=True),
                'CV_AUROC_mean': float(cv_table.loc[ix, 'mean_test_AUROC']),
                'CV_AUROC_SD': float(cv_table.loc[ix, 'std_test_AUROC']),
                'CV_AUPRC_mean': float(cv_table.loc[ix, 'mean_test_AUPRC']),
                'CV_AUPRC_SD': float(cv_table.loc[ix, 'std_test_AUPRC']),
            })
            # Test data are first passed to models only AFTER training CV and refit complete.
            best_model = gs.best_estimator_
            prob_test = best_model.predict_proba(X_test[features])[:, 1]
            key = (feature_set, algorithm)
            predictions[key] = prob_test
            result = {
                'algorithm': algorithm,
                'feature_set': feature_set,
                'test_n': int(len(y_test)),
                'test_grade3_n': int(y_test.sum()),
                'decision_threshold': 0.5,
                **metrics(y_test, prob_test, threshold=0.5),
            }
            test_rows.append(result)
            shortname = ('Clinical' if feature_set == 'Clinical-only' else 'Integrated')
            shortname += ('_LR' if algorithm == 'Logistic Regression' else '_RF')
            pred_table[f'{shortname}_probability'] = prob_test
            pred_table[f'{shortname}_predicted'] = (prob_test >= 0.5).astype(int)
            joblib.dump(best_model, out/'trained_models'/f'{shortname}.joblib', compress=3)
            print(f'{algorithm} | {feature_set} | best CV AUROC {gs.best_score_:.4f} | '
                  f'Test AUROC {result["AUROC"]:.4f} | AP {result["AUPRC_average_precision"]:.4f}',
                  flush=True)

    cv_df = pd.DataFrame(all_cv_rows)
    best_df = pd.DataFrame(best_rows)
    test_df = pd.DataFrame(test_rows)
    cv_df.to_csv(out/'Training_CV_All_Candidates.csv', index=False)
    best_df.to_csv(out/'Training_CV_Selected_Models.csv', index=False)
    test_df.to_csv(out/'Heldout_Test_Performance.csv', index=False)
    pred_table.to_csv(out/'Heldout_Test_Predictions.csv', index=False)

    delta_rows = []
    for algorithm in ['Logistic Regression', 'Random Forest']:
        pc = predictions[('Clinical-only', algorithm)]
        pi = predictions[('Clinical + RNA', algorithm)]
        mc, mi = metrics(y_test, pc), metrics(y_test, pi)
        ci = paired_stratified_bootstrap_delta(y_test, pc, pi, repeats=2000, seed=SEED)
        delta_rows.append({
            'algorithm': algorithm,
            'Delta_AUROC_B_minus_A': mi['AUROC'] - mc['AUROC'],
            'Delta_AUPRC_B_minus_A': mi['AUPRC_average_precision'] - mc['AUPRC_average_precision'],
            'Delta_Accuracy_B_minus_A': mi['Accuracy'] - mc['Accuracy'],
            'Delta_Sensitivity_B_minus_A': mi['Sensitivity'] - mc['Sensitivity'],
            'Delta_Specificity_B_minus_A': mi['Specificity'] - mc['Specificity'],
            'Delta_F1_B_minus_A': mi['F1_score'] - mc['F1_score'],
            **ci,
        })
    delta_df = pd.DataFrame(delta_rows)
    delta_df.to_csv(out/'Paired_Incremental_Performance.csv', index=False)
    plot_curves(y_test, predictions, out)

    meta = {
        'input_file': args.input.name,
        'random_state': SEED,
        'original_n': int(len(df)),
        'excluded_missing_grade_n': int(grades.isna().sum()),
        'eligible_n': int(len(cohort)),
        'grade3_n': int(y.sum()),
        'grade1_2_n': int((1-y).sum()),
        'training_n': int(len(y_train)),
        'training_grade3_n': int(y_train.sum()),
        'training_grade1_2_n': int((1-y_train).sum()),
        'test_n': int(len(y_test)),
        'test_grade3_n': int(y_test.sum()),
        'test_grade1_2_n': int((1-y_test).sum()),
        'clinical_features': CLINICAL_FEATURES,
        'rna_features': RNA_FEATURES,
        'split': 'train_test_split(test_size=0.20,stratify=y,random_state=42,shuffle=True)',
        'training_validation': 'StratifiedKFold(n_splits=5,shuffle=True,random_state=42)',
        'hyperparameter_selection': 'Training CV AUROC only; refit on full Training Set',
        'test_threshold': 0.5,
        'AUPRC_definition': 'scikit-learn average_precision_score (non-interpolated)',
        'test_bootstrap': 'Stratified paired bootstrap, 2000 resamples; fixed-model CI, not external validation',
        'python_version': platform.python_version(),
        'numpy_version': np.__version__,
        'pandas_version': pd.__version__,
        'scipy_version': scipy.__version__,
        'sklearn_version': sklearn.__version__,
        'matplotlib_version': matplotlib.__version__,
    }
    (out/'Run_Metadata.json').write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')
    lines = [
        '# METABRIC Grade 3 classification: executed results',
        '',
        '## Design',
        f"N={len(cohort)} after excluding {grades.isna().sum()} missing-grade records. ",
        f"Train n={len(y_train)} (Grade 3={y_train.sum()}); test n={len(y_test)} (Grade 3={y_test.sum()}).",
        'The **test set was isolated before imputation/scaling/encoding**. All 4 prespecified '
        'models were tuned using only training-set stratified 5-fold CV; CV selection metric was AUROC.',
        '', '## Best training-CV results', '',
        best_df.to_markdown(index=False, floatfmt='.4f'),
        '', '## Held-out test performance (threshold 0.5)', '',
        test_df.to_markdown(index=False, floatfmt='.4f'),
        '', '## Paired held-out incremental comparison (integrated minus clinical)', '',
        delta_df.to_markdown(index=False, floatfmt='.4f'),
        '', '## Interpretation and limitations', '',
        '- These values are internal holdout estimates from one fixed 80:20 split, NOT independent external validation.',
        '- The bootstrap CI for model differences conditions on fixed fitted models and the single held-out sample.',
        '- AUPRC is average precision (non-interpolated definition).',
        '- Classification metrics use a prespecified probability threshold of 0.5; 1 denotes Grade 3.',
        '- Predictors are limited to the exact columns requested; Grade-derived and outcome variables are excluded.',
        '- Clinical/RNA collection timing is unverified; results do not establish early prediction or clinical utility.',
        '- Observed differences between feature sets cannot be interpreted causally.',
    ]
    (out/'Results_and_Methods.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print('\nSplit details:', {k: meta[k] for k in ['eligible_n','training_n','training_grade3_n','test_n','test_grade3_n']})
    print('Selected CV:')
    print(best_df.to_string(index=False, float_format=lambda v:f'{v:.4f}'))
    print('Test metrics:')
    print(test_df.to_string(index=False, float_format=lambda v:f'{v:.4f}'))
    print('Incremental differences:')
    print(delta_df.to_string(index=False, float_format=lambda v:f'{v:.4f}'))
    print('Files written to', out.resolve(), flush=True)

if __name__ == '__main__':
    main()
