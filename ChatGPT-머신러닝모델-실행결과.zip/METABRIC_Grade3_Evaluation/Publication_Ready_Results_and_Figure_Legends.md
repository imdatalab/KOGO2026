# METABRIC Grade 3 Classification: Publication-Ready Model Evaluation

## Dataset and analysis design
The original METABRIC file contained 1,904 records. After removing 72 individuals with missing `neoplasm_histologic_grade`, 1,832 records remained (Grade 1–2: n = 905; Grade 3: n = 927). The original patient-disjoint, stratified 80:20 allocation (`random_state=42`) was preserved (training: n = 1,465 [Grade 3, n = 741]; hold-out test: n = 367 [Grade 3, n = 186]). The original pre-fitted four sklearn pipelines were reused and their predictions verified against saved patient-level held-out predictions, with an absolute tolerance of 1×10⁻¹². None of the held-out test records was used to refit any model or rank input predictors. Grade 3 was the positive class, and the prespecified decision threshold was 0.50.

### Candidate inputs
Clinical models used age at diagnosis, tumor size, positive lymph node count, ER status, PR status, and HER2 status. Integrated models additionally used BRCA1, BRCA2, TP53, PTEN, ERBB2, PIK3CA, CCND1, and MYC expression. All numeric predictors were median-imputed and standardized, and categorical predictors were mode-imputed and one-hot encoded, exclusively inside `ColumnTransformer`/`Pipeline`. There were 15 missing tumor sizes in the training set and 2 in the test set; the saved pipelines' tumor-size imputation statistic was confirmed to equal the full-training median (22 in the recorded data units). All prior model hyperparameters had been chosen using stratified 5-fold training cross-validation and AUROC, not test performance.

### Statistical evaluation
Discrimination was evaluated using AUROC and non-interpolated average precision (AUPRC/AP). At the fixed threshold 0.50, accuracy, sensitivity, specificity, F1 score, and four confusion-matrix counts were computed. Brier scores and a ten-quantile-bin reliability curve were used as descriptive probabilistic performance measures. All AUROC 95% confidence intervals were estimated by percentile bootstrap using 5,000 random resamples (`seed=20261004`), separately sampling with replacement the 181 Grade 1–2 and 186 Grade 3 test patients to preserve class prevalence. For paired incremental comparisons, the **same sampled patient indices** were applied to clinical and integrated predictions. These intervals describe fixed fitted models on one held-out split; they do not capture re-training uncertainty or constitute external validation. Feature contributions were assessed using training-only five-fold validation permutation importance, two random feature permutations per fold, with locked preselected hyperparameters. Mean decrease in fold-validation AUROC is reported; this retrospective feature exploration does not use test outcomes.

## Table 2. Discrimination, classification, and probabilistic performance of four prespecified models in the held-out METABRIC test set

| Model | Training CV AUROC, mean ± SD | Test AUROC (bootstrap 95% CI) | AUPRC | Accuracy | Sensitivity | Specificity | F1 score | Brier score |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| Clinical only / Logistic Regression | 0.744 ± 0.020 | 0.750 (0.700–0.799) | 0.788 | 0.692 | 0.575 | 0.812 | 0.654 | 0.197 |
| Clinical + RNA / Logistic Regression | **0.771 ± 0.015** | 0.777 (0.728–0.823) | **0.800** | **0.706** | **0.651** | 0.762 | **0.691** | **0.188** |
| Clinical only / Random Forest | 0.751 ± 0.014 | 0.751 (0.700–0.799) | 0.771 | 0.681 | 0.602 | 0.762 | 0.657 | 0.199 |
| Clinical + RNA / Random Forest | 0.770 ± 0.010 | **0.784 (0.734–0.828)** | 0.794 | 0.703 | **0.651** | 0.757 | 0.689 | 0.189 |

*Footnote.* Test N = 367, including 186 (50.7%) Grade 3 records. Metrics are obtained from the previously selected models, evaluated on the original patient-disjoint test set. Class 1 denotes Grade 3; decision threshold = 0.50. AUROC uncertainty was assessed using a class-stratified 5,000-resample percentile bootstrap. AUPRC is computed using scikit-learn's non-interpolated `average_precision_score`. Lower Brier score denotes better mean squared probabilistic prediction error. Boldface identifies the highest observed value per column, where suitable, and is descriptive; test performance was not used as a prospective selection criterion. CV = cross-validation; SD = standard deviation; RNA = RNA expression.

## Confusion matrices (observed × predicted, class 1 = Grade 3)

| Model | True negative | False positive | False negative | True positive |
|:--|--:|--:|--:|--:|
| Clinical only / LR | 147 | 34 | 79 | 107 |
| Clinical + RNA / LR | 138 | 43 | 65 | 121 |
| Clinical only / RF | 138 | 43 | 74 | 112 |
| Clinical + RNA / RF | 137 | 44 | 65 | 121 |

## Additional information from RNA expression

| Algorithm | Test ΔAUROC (integrated – clinical) | Paired 5,000-bootstrap 95% CI | ΔAUPRC | ΔSensitivity | ΔSpecificity |
|:--|--:|:--|--:|--:|--:|
| Logistic Regression | +0.0269 | −0.0045 to +0.0591 | +0.0126 | +0.0753 | −0.0497 |
| Random Forest | +0.0328 | −0.0018 to +0.0666 | +0.0231 | +0.0484 | −0.0055 |

RNA integration increased observed discrimination for both algorithms in this test sample, but **both paired ΔAUROC confidence intervals included zero**. The increase in sensitivity occurred alongside a decrease in specificity at the prespecified 0.50 threshold. This is an exploratory association between available information and histological grade classification; neither causal contribution nor clinical utility has been established.

## Calibration
The integrated Random Forest had the *highest observed test-set AUROC* (0.7837), and its ten-bin quantile calibration plot is provided as requested; its Brier score was **0.1894**. The training-CV-preferred model, integrated Logistic Regression, had a slightly lower (better) test Brier score (**0.1881**) and a lower observed test AUROC (0.7774). Calibration of a post-hoc test-set winner should be described only as an exploratory evaluation, not as test-driven selection/recalibration. Each reliability bin contained 36 or 37 observations and therefore has substantial sampling variability.

## Training-only predictor importance
Five stratified training-validation folds × two permutation repeats per fold produced ten permutation scores per original input variable. The table below shows leading individual contributions, measured as the mean decrease in validation-fold AUROC after permuting one predictor at a time.

| Clinical + RNA predictor | Integrated LR: mean ΔAUROC | Clinical + RNA predictor | Integrated RF: mean ΔAUROC |
|:--|--:|:--|--:|
| er_status | 0.0728 | er_status | 0.0822 |
| her2_status | 0.0262 | pr_status | 0.0185 |
| pten expression | 0.0256 | erbb2 expression | 0.0177 |
| pr_status | 0.0192 | pten expression | 0.0170 |
| brca1 expression | 0.0153 | her2_status | 0.0139 |
| lymph_nodes_examined_positive | 0.0117 | brca1 expression | 0.0099 |

When interpreting these ranks, correlated variables can share importance; isolated feature permutation may underestimate a joint contribution. Rankings are unstable in smaller samples, depend on the algorithm, and should not be read as independent effects, differential expression, a causal ranking, or biomarker validation. Full results for all 40 model-variable pairs are available in the workbook and CSV file.

## Risk of bias and validity audit

| Assessment | Actual check/result | Consequence |
|:--|:--|:--|
| Computational target leakage | No grade, Nottingham Prognostic Index, treatment, mutation, survival outcome, or patient identifier included as a predictor. The 6 + 8 predictors match the prespecified lists. | No direct target leakage found in supplied model pipeline. Time-of-measurement cannot be independently verified. |
| Missing-data handling | Training set has 15 missing tumor sizes; test set has 2. Preprocessing is inside the original pipelines and fitted within each CV training fold, followed by refitting on the full training set. Saved models' fitted tumor-size median equals training median (22 recorded units). | No global pre-split imputation identified. |
| Patient independence | Original patient IDs are unique; train/test ID intersections are empty; all 367 reproduced predictions numerically agree with archived outputs. | The internal hold-out is patient-disjoint, but it is not external data. |
| Overfitting | Mean fold-fit versus CV-validation AUROC: Clinical LR 0.749 vs 0.744 (gap 0.0049); Integrated LR 0.784 vs 0.771 (0.0133); Clinical RF 0.847 vs 0.751 (0.0961); Integrated RF 0.972 vs 0.770 (0.2025). | RF shows meaningful fit–validation optimism, particularly integrated RF. Similar CV and test discrimination does not erase within-fold optimism. |
| Class imbalance | Training Grade 3 n = 741/1,465 (50.6%); test Grade 3 n = 186/367 (50.7%). | Severe imbalance is absent; no balancing technique required. |
| Validation/selection | The original grid was selected using training CV AUROC (integrated LR 0.7712, integrated RF 0.7700); test AUROC was subsequently observed. | Avoid a retrospective claim that integrated RF was prospectively selected because of its larger test AUROC. |
| Calibration model | Integrated RF displayed because it ranked first on observed test AUROC, without refitting or recalibration. | Descriptive, post-hoc visualization only; integrated LR offers slightly better test Brier score. |
| Comparison uncertainty | Fixed test N = 367, one stratified 80:20 split. Both paired ΔAUROC CIs cross zero. | Incremental benefit is suggested, not conclusively established. Bootstrapping does not create external validation or include model-development variability. |
| External transportability | Data derive from one assembled METABRIC dataset; its internal cohorts and potential assay/batch effects were not independently assessed in this evaluation. | Additional temporal, cross-center or external validations are needed before generalization or use in practice. |
| Test-set reuse | This evaluation extends an earlier report of the same held-out results. No additional model fitting or tuning was performed after viewing its outcomes. | Future model revisions must be validated on new data; repeated adaptive reuse would compromise independence. |

## Manuscript-ready Results paragraph (academic English)
In 1,832 eligible METABRIC cases, 1,465 patients were assigned to the training set and 367 to the patient-disjoint test set. Among the four prespecified models, the integrated Random Forest achieved the highest *observed* test AUROC of 0.784 (95% bootstrap CI, 0.734–0.828), followed by integrated Logistic Regression (0.777 [0.728–0.823]), clinical-only Random Forest (0.751 [0.700–0.799]), and clinical-only Logistic Regression (0.750 [0.700–0.799]). The corresponding AUPRC values were 0.794, 0.800, 0.771, and 0.788, respectively. Compared with the clinical-only models, inclusion of eight RNA expression features increased observed test AUROC by 0.0269 for Logistic Regression (paired 95% CI, −0.0045 to 0.0591) and 0.0328 for Random Forest (−0.0018 to 0.0666). At the prespecified threshold of 0.50, the integrated Logistic Regression classified 121 of 186 Grade 3 cases correctly (sensitivity 0.651) versus 107 of 186 for the clinical-only Logistic Regression (sensitivity 0.575), with a concomitant reduction in specificity (0.762 versus 0.812). The integrated Random Forest had a Brier score of 0.1894, while the training-CV-preferred integrated Logistic Regression had a Brier score of 0.1881. As the confidence intervals for both paired AUROC differences included zero and no external validation data were available, the incremental classification value of these eight RNA features should be regarded as exploratory.

## Figure legends

**Figure 1. Receiver operating characteristic curves of four prespecified classifiers in the held-out METABRIC test set.** The four models share the same 367 patients (Grade 3, n = 186; Grade 1–2, n = 181). Solid curves denote Random Forest, and dashed curves denote Logistic Regression; clinical-only and clinical-plus-RNA models are distinguished by color. The diagonal dotted line represents chance discrimination. Parenthetical values in the legend indicate AUROC and percentile 95% confidence intervals from 5,000 class-stratified test-set bootstrap resamples. The test set was not used for model fitting, feature selection, or hyperparameter tuning.

**Figure 2. Confusion matrices of the four models in the held-out METABRIC test set.** Predictions were dichotomized at the prespecified probability threshold of 0.50, with histological Grade 3 defined as the positive class. Rows represent observed histological grade, and columns represent model-predicted grade. The upper-left, upper-right, lower-left, and lower-right cells give true negatives, false positives, false negatives, and true positives, respectively. Each panel comprises 367 patients.

**Figure 3. Calibration of the integrated Random Forest in the held-out METABRIC test set.** The integrated Random Forest was visualized because it had the highest observed test AUROC among four prespecified models; its identification on the basis of test results was descriptive and did not drive any subsequent model selection or recalibration. Circles indicate the observed frequency of Grade 3 against mean model-estimated risk within ten equal-frequency probability groups (36–37 patients per group); the dotted diagonal indicates ideal calibration. The lower panel shows the distribution of model-estimated Grade 3 probabilities. The Brier score was 0.1894 (lower is better).

**Figure 4. Relative importance of individual clinicopathological and RNA predictors in integrated classification models.** Predictor importance was evaluated using a training-only, five-fold validation permutation procedure with two feature permutations per fold (ten estimates per predictor), with each model's hyperparameters fixed at their training-CV-selected values. Bar length denotes the mean decrease in validation AUROC after permuting the original predictor. Clinical and RNA predictors are color coded. The same held-out test data displayed in Figures 1–3 were not used for this analysis. Importance does not imply causality and may be attenuated for correlated predictors.

## Principal limitations
This is an internally validated retrospective exploratory classification study, not a prospective or early-prediction study. The predictor- and outcome-measurement timing is not established. The small, specific RNA panel is investigator-prespecified, and its result cannot be generalized to arbitrary transcriptomic signatures. A single internal hold-out from the same parent dataset cannot substitute for independent external validation. Bootstrap CIs are conditional on the previously fitted models and fixed split. Feature rankings and post-hoc comparisons require confirmation in independent data.
