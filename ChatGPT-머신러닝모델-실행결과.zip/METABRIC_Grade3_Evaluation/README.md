# Reproducible METABRIC Grade 3 model evaluation

## Inputs
- Original `METABRIC_RNA_Mutation.csv` (provided separately by the user).
- The `prior_models/` folder included in this package: original patient-level split assignments, four previously trained `.joblib` sklearn pipelines, archived held-out predictions and training-CV summaries.

## Run
Use Python and package versions compatible with the archived model pickles (original development environment: Python 3.13.5; scikit-learn 1.8.0). From this folder:

```bash
pip install -r requirements.txt
python evaluate_metabric_models.py \
    --input /path/to/METABRIC_RNA_Mutation.csv \
    --previous-results ./prior_models \
    --output-dir ./reproduced_evaluation
python make_publication_workbook.py --dir ./reproduced_evaluation
```

The last workbook command requires `artifact_tool` (also used for the prepackaged workbook). Main evaluation estimates 5,000 bootstrap resamples; the final training-only permutation-importance analysis may take several minutes depending on CPU.

## Primary outputs
- Publication-ready workbook: `METABRIC_Grade3_Model_Evaluation.xlsx`, with seven sheets (Table 2, raw metrics, confusion, paired comparison, calibration, overfitting, and predictor importance).
- `Publication_Ready_Results_and_Figure_Legends.md`: manuscript-ready English results, method, notes, and four legends.
- Figure 1: combined test ROC; Figure 2: four confusion matrices; Figure 3: test calibration (highest observed test-AUROC model); Figure 4: training-only permutation importance. Figures are 450 dpi PNG and vector PDF.
- All detailed data tables are in CSV. `Execution_Log.txt` records the original two-stage execution and integrity checks.

## Critical precautions
1. The original split is reused. No re-tuning, re-training, or recalibration is performed on the held-out test set. The test-set best AUROC is a description, not a prospective selection criterion.
2. Individual model AUROC 95% CIs and paired ΔAUROC 95% CIs use the same 5,000 class-stratified bootstrap iterations; intervals describe the fixed models in this particular test set.
3. Importance uses **training-only 5-fold cross-validated permutation**, 2 repeats per fold, and does not use the held-out test set. Because hyperparameters were chosen on the same broader training set, importance is exploratory rather than a separate unbiased validation.
4. `patient_id` is used only for integrity checks and joining, not as a predictive feature.
5. Figure PDFs are vector counterparts of the PNGs; check publisher-specific sizing when embedding in the final manuscript.
