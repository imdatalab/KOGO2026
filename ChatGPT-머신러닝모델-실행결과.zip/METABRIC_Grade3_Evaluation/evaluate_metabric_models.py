#!/usr/bin/env python3
"""Reevaluate four previously fitted METABRIC models without changing the test split.

Example:
 python evaluate_metabric_models.py --input /mnt/data/METABRIC_RNA_Mutation.csv \
   --previous-results /mnt/data/_archive/METABRIC_Grade3_ML \
   --output-dir /mnt/data/METABRIC_Grade3_Evaluation

Input artifacts: Original data, previously frozen split/model/prediction artifacts.
The held-out test data are NEVER used to refit, tune, recalibrate, or rank input features.
Feature importance uses training-only folds with locked preselected hyperparameters.
"""
from __future__ import annotations
import argparse
import json
import copy
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
from scipy.stats import rankdata
from sklearn.base import clone
from sklearn.calibration import calibration_curve
from sklearn.inspection import permutation_importance
from sklearn.metrics import (roc_auc_score, average_precision_score, brier_score_loss,
                             confusion_matrix, roc_curve, accuracy_score, recall_score,
                             f1_score)
from sklearn.model_selection import StratifiedKFold

CONT=['age_at_diagnosis','tumor_size','lymph_nodes_examined_positive']
CAT=['er_status','pr_status','her2_status']
RNA=['brca1','brca2','tp53','pten','erbb2','pik3ca','ccnd1','myc']
FEATURES = {'Clinical_LR':CONT+CAT, 'Integrated_LR':CONT+CAT+RNA,
            'Clinical_RF':CONT+CAT, 'Integrated_RF':CONT+CAT+RNA}
MODELS=['Clinical_LR','Integrated_LR','Clinical_RF','Integrated_RF']
LABELS={'Clinical_LR':'Clinical only · LR','Integrated_LR':'Clinical + RNA · LR',
        'Clinical_RF':'Clinical only · RF','Integrated_RF':'Clinical + RNA · RF'}
COLORS={'Clinical_LR':'#315778','Integrated_LR':'#B04050',
        'Clinical_RF':'#50859E','Integrated_RF':'#852C4A'}
STYLES={'Clinical_LR':'--','Integrated_LR':'--','Clinical_RF':'-','Integrated_RF':'-'}
BOOTSTRAP_REPEATS=5000
BOOT_SEED=20261004
THRESHOLD=.5

def configure_plot():
    plt.rcParams.update({'figure.facecolor':'white','savefig.facecolor':'white',
        'axes.facecolor':'white','font.family':'DejaVu Sans','font.size':10,
        'axes.spines.top':False,'axes.spines.right':False,
        'axes.labelsize':11,'axes.titlesize':12,'legend.frameon':False,
        'pdf.fonttype':42,'ps.fonttype':42})

def save(fig, base):
    fig.savefig(str(base)+'.png',dpi=450,bbox_inches='tight',facecolor='white')
    fig.savefig(str(base)+'.pdf',bbox_inches='tight',facecolor='white')
    plt.close(fig)

def metric(y,p):
    y_hat=(p>=THRESHOLD).astype(int)
    tn,fp,fn,tp=confusion_matrix(y,y_hat,labels=[0,1]).ravel().tolist()
    return {'AUROC':roc_auc_score(y,p),'AUPRC_AP':average_precision_score(y,p),
            'Accuracy':accuracy_score(y,y_hat),'Sensitivity':recall_score(y,y_hat),
            'Specificity':tn/(tn+fp),'F1':f1_score(y,y_hat),
            'Brier':brier_score_loss(y,p),'TN':tn,'FP':fp,'FN':fn,'TP':tp}

def strat_bootstrap_indices(y,repeats=BOOTSTRAP_REPEATS,seed=BOOT_SEED):
    rng=np.random.default_rng(seed)
    y=np.asarray(y)
    neg=np.flatnonzero(y==0); pos=np.flatnonzero(y==1)
    for _ in range(repeats):
        # Class-stratified resampling preserves empirical Grade 3 prevalence.
        yield np.concatenate([rng.choice(neg,len(neg),replace=True),
                              rng.choice(pos,len(pos),replace=True)])

def grade3(df):
    g=pd.to_numeric(df['neoplasm_histologic_grade'],errors='coerce')
    if (~g[g.notna()].isin([1,2,3])).any():
        raise AssertionError('Unexpected nonmissing Grade code')
    use=df.loc[g.notna()].copy()
    use['observed_grade3']=(g.loc[g.notna()]==3).astype(int)
    for c in CONT+RNA:
        use[c]=pd.to_numeric(use[c],errors='coerce').replace([np.inf,-np.inf],np.nan)
    for c in CAT:
        use[c]=use[c].astype('string').str.strip().replace({'':pd.NA})
        use[c]=use[c].astype(object).where(use[c].notna(),np.nan)
    return use

def verify_and_load(inp,previous):
    raw=pd.read_csv(inp,low_memory=False)
    assert len(raw)==1904 and raw['patient_id'].is_unique
    dat=grade3(raw)
    assert len(dat)==1832 and dat['observed_grade3'].sum()==927
    assignments=pd.read_csv(previous/'Split_Assignments.csv')
    assert len(assignments)==1832 and assignments.patient_id.is_unique
    train_ids=assignments.loc[assignments.partition=='train','patient_id']
    test_ids=assignments.loc[assignments.partition=='test','patient_id']
    assert len(train_ids)==1465 and len(test_ids)==367
    assert set(train_ids).isdisjoint(set(test_ids))
    assert set(assignments.patient_id)==set(dat.patient_id)
    mapping=dat.set_index('patient_id',verify_integrity=True)
    train=mapping.loc[train_ids].copy(); test=mapping.loc[test_ids].copy()
    assert train['observed_grade3'].eq(assignments.loc[assignments.partition=='train','target_grade3'].to_numpy()).all()
    assert test['observed_grade3'].eq(assignments.loc[assignments.partition=='test','target_grade3'].to_numpy()).all()
    oldp=pd.read_csv(previous/'Heldout_Test_Predictions.csv')
    assert set(oldp.patient_id)==set(test.index)
    oldp=oldp.set_index('patient_id').loc[test.index]
    assert np.array_equal(test['observed_grade3'].to_numpy(),oldp.observed_grade3.to_numpy())
    pred={}; fits={}
    for m in MODELS:
        fits[m]=joblib.load(previous/'trained_models'/f'{m}.joblib')
        proba=fits[m].predict_proba(test[FEATURES[m]])[:,1]
        saved=oldp[f'{m}_probability'].to_numpy()
        assert np.allclose(proba,saved,rtol=0,atol=1e-12),f'{m}: mismatch in saved predictions'
        assert np.array_equal((proba>=THRESHOLD).astype(int),oldp[f'{m}_predicted'].to_numpy())
        pred[m]=proba
    assert int(train.tumor_size.isna().sum())==15 and int(test.tumor_size.isna().sum())==2
    # Verify numerical preprocessing was fit using train only: median tumor_size.
    # Same fitting pipeline reused across all models; source code isolates test before fit.
    train_median=train.tumor_size.median()
    for m in MODELS:
        imp=fits[m].named_steps['preprocessor'].named_transformers_['numeric'].named_steps['imputer']
        names=CONT+(RNA if 'Integrated' in m else [])
        assert np.isclose(imp.statistics_[names.index('tumor_size')],train_median)
    print('DATA_VERIFIED original=1904 eligible=1832 train=1465 test=367 train_positive=741 test_positive=186')
    print('TEST_PREDICTIONS_VERIFIED four previously fitted joblib models match prior CSV (atol=1e-12)')
    print(f'MISSING_VERIFIED tumor_size train=15 test=2; train-only imputation median={train_median:g}')
    return dat,train,test,pred,fits

def cv_training_importances(train,fits,output):
    # No use of test set here. Fixed best estimators refitted independently in each
    # training-validation fold, then shuffled ON VALIDATION folds. For correlated
    # features, individual permutation may underestimate the joint signal.
    y=train['observed_grade3'].to_numpy()
    folds=StratifiedKFold(n_splits=5,shuffle=True,random_state=42)
    rows=[]; baseline=[]
    for model in MODELS:
        use=FEATURES[model]
        X=train[use].copy()
        print('IMPORTANCE_START',model,flush=True)
        for fold,(it,iv) in enumerate(folds.split(X,y),1):
            clf=clone(fits[model])
            clf.fit(X.iloc[it],y[it])
            base_auc=roc_auc_score(y[iv],clf.predict_proba(X.iloc[iv])[:,1])
            # Pass DataFrame so its column names remain aligned with pipeline.
            imp=permutation_importance(clf,X.iloc[iv],y[iv],n_repeats=2,
                                        random_state=1000+fold,scoring='roc_auc',n_jobs=1)
            baseline.append({'Model':model,'Fold':fold,'Validation_AUROC':base_auc})
            for col,arr in zip(use,imp.importances):
                for rep,val in enumerate(arr,1):
                    rows.append({'Model':model,'Predictor':col,'Fold':fold,
                                 'Repeat':rep,'AUROC_Decrease':float(val)})
        print('IMPORTANCE_DONE',model,flush=True)
    details=pd.DataFrame(rows)
    summ=details.groupby(['Model','Predictor'],as_index=False).agg(
        Mean_Delta_AUROC=('AUROC_Decrease','mean'),
        SD_Delta_AUROC=('AUROC_Decrease','std'),
        N_Permutations=('AUROC_Decrease','size'))
    summ['Rank_Within_Model']=summ.groupby('Model')['Mean_Delta_AUROC'].rank(ascending=False,method='first').astype(int)
    summ=summ.sort_values(['Model','Rank_Within_Model'])
    details.to_csv(output/'Training_Only_Permutation_Importance_All_Repeats.csv',index=False)
    summ.to_csv(output/'Training_Only_Permutation_Importance_Summary.csv',index=False)
    pd.DataFrame(baseline).to_csv(output/'Training_Only_CV_Baselines.csv',index=False)
    return summ

def plot_roc(y,pred,out,summary):
    fig,ax=plt.subplots(figsize=(6.8,5.7))
    for m in MODELS:
        fpr,tpr,_=roc_curve(y,pred[m])
        r=summary.loc[summary.Model==m].iloc[0]
        ax.plot(fpr,tpr,color=COLORS[m],ls=STYLES[m],lw=2.05,
                label=f'{LABELS[m]}  AUC {r.AUROC:.3f} ({r.AUROC_CI_low:.3f}–{r.AUROC_CI_high:.3f})')
    ax.plot([0,1],[0,1],linestyle=':',color='#969CA0',lw=1)
    ax.set(xlim=(0,1),ylim=(0,1.015),xlabel='1 − Specificity (false positive rate)',
           ylabel='Sensitivity (true positive rate)',
           title='ROC curves in the held-out test set (n = 367)')
    ax.legend(loc='lower right',fontsize=8.15)
    ax.grid(alpha=.15,linewidth=.6)
    save(fig,out/'Figure_1_Test_ROC_All_Models')

def plot_cms(y,pred,out):
    fig,axes=plt.subplots(2,2,figsize=(8.8,7.6),sharex=False,sharey=False)
    for ax,m in zip(axes.ravel(),MODELS):
        cm=confusion_matrix(y,pred[m]>=THRESHOLD,labels=[0,1])
        ax.imshow(cm,cmap='Blues',vmin=0,vmax=190,interpolation='nearest')
        for i in range(2):
            for j in range(2):
                ax.text(j,i,f'{cm[i,j]}',ha='center',va='center',fontsize=16,
                        weight='semibold',color='white' if cm[i,j]>95 else '#253B50')
        ax.set_xticks([0,1],['Grade 1–2','Grade 3'],fontsize=9)
        ax.set_yticks([0,1],['Grade 1–2','Grade 3'],fontsize=9)
        ax.set(xlabel='Predicted grade',ylabel='Observed grade',title=LABELS[m].replace(' · ',' / '))
        ax.spines[:].set_visible(False)
        ax.tick_params(length=0)
    fig.suptitle('Confusion matrices (threshold = 0.50; n = 367)',fontsize=13,y=.99)
    fig.tight_layout(rect=(0,0,1,.965),h_pad=2.1,w_pad=2)
    save(fig,out/'Figure_2_Test_Confusion_Matrices')

def plot_calibration(y,proba,out,m):
    frac,mean_pred=calibration_curve(y,proba,n_bins=10,strategy='quantile')
    # Show counts with same quantile binning as underlying curve.
    edges=np.unique(np.quantile(proba,np.linspace(0,1,11)))
    bins=pd.cut(proba,edges,include_lowest=True,duplicates='drop',labels=False)
    data=pd.DataFrame({'bin':bins,'y':y,'p':proba})
    bin_table=data.groupby('bin',observed=True).agg(
        n=('y','size'),Predicted_Risk=('p','mean'),Observed_Frequency=('y','mean'))
    bin_table=bin_table.reset_index()
    assert len(frac)==len(bin_table) and np.allclose(frac,bin_table.Observed_Frequency.to_numpy())
    bin_table.to_csv(out/'Calibration_Bins_Highest_Test_AUROC.csv',index=False)
    brier=brier_score_loss(y,proba)
    fig=plt.figure(figsize=(6.2,6.7))
    gs=fig.add_gridspec(2,1,height_ratios=[3.5,1],hspace=.13)
    ax=fig.add_subplot(gs[0]); hist=fig.add_subplot(gs[1],sharex=ax)
    ax.plot([0,1],[0,1],ls=':',color='#888888',label='Perfect calibration',lw=1.3)
    ax.plot(mean_pred,frac,color=COLORS[m],marker='o',ms=5.4,lw=2,
            label=f'{LABELS[m]} (Brier = {brier:.3f})')
    ax.set(xlim=(0,1),ylim=(0,1),ylabel='Observed Grade 3 frequency',
           title='Calibration of the highest observed test-AUROC model')
    ax.legend(loc='upper left',fontsize=9)
    ax.grid(alpha=.15,linewidth=.6)
    hist.hist(proba,bins=np.linspace(0,1,11),color=COLORS[m],alpha=.78,edgecolor='white')
    hist.set(xlim=(0,1),xlabel='Predicted probability of Grade 3',ylabel='Patients')
    hist.grid(axis='y',alpha=.13)
    plt.setp(ax.get_xticklabels(),visible=False)
    save(fig,out/'Figure_3_Test_Calibration_Integrated_RF')
    return bin_table

def plot_importance(imp,out):
    fig,axes=plt.subplots(1,2,figsize=(11.8,5.8),sharex=False)
    for ax,m in zip(axes,['Integrated_LR','Integrated_RF']):
        tmp=imp[imp.Model==m].sort_values('Mean_Delta_AUROC',ascending=False).head(10)
        tmp=tmp.iloc[::-1]
        colors=[('#A4344B' if p in RNA else '#315778') for p in tmp.Predictor]
        ax.barh(np.arange(len(tmp)),tmp.Mean_Delta_AUROC,color=colors,alpha=.88)
        ax.set_yticks(np.arange(len(tmp)),tmp.Predictor.str.upper().str.replace('_',' ',regex=False),fontsize=9)
        ax.axvline(0,color='#666666',lw=.8)
        ax.set(xlabel='Mean reduction in validation AUROC after permutation',
               title=LABELS[m].replace(' · ',' / '))
        ax.grid(axis='x',alpha=.17)
    from matplotlib.patches import Patch
    fig.legend(handles=[Patch(facecolor='#315778',label='Clinical'),Patch(facecolor='#A4344B',label='RNA')],
               ncol=2,frameon=False,loc='lower center',bbox_to_anchor=(.5,-.005))
    fig.suptitle('Training-only cross-validated permutation importance',y=.99,fontsize=13)
    fig.tight_layout(rect=(0,.055,1,.955),w_pad=3)
    save(fig,out/'Figure_4_Training_Permutation_Importance')

def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--input',type=Path,default=Path('METABRIC_RNA_Mutation.csv'))
    cli.add_argument('--previous-results',type=Path,default=Path('prior_models'))
    cli.add_argument('--output-dir',type=Path,default=Path('.'))
    a=cli.parse_args(); out=a.output_dir;out.mkdir(parents=True,exist_ok=True)
    configure_plot()
    dat,train,test,pred,fits=verify_and_load(a.input,a.previous_results)
    y=test['observed_grade3'].to_numpy()
    metrics={m:metric(y,pred[m]) for m in MODELS}
    bs_auc={m:[] for m in MODELS}; bs_delta={'LR':[],'RF':[]}
    for idx in strat_bootstrap_indices(y):
        yt=y[idx]
        aucs={m:roc_auc_score(yt,pred[m][idx]) for m in MODELS}
        for m in MODELS:bs_auc[m].append(aucs[m])
        bs_delta['LR'].append(aucs['Integrated_LR']-aucs['Clinical_LR'])
        bs_delta['RF'].append(aucs['Integrated_RF']-aucs['Clinical_RF'])
    rows=[]
    for m in MODELS:
        lo,hi=np.percentile(bs_auc[m],[2.5,97.5]); met=metrics[m]
        rows.append({'Model':m,'Feature_Set':'Clinical + RNA' if m.startswith('Integrated') else 'Clinical-only',
                     'Algorithm':'Logistic Regression' if m.endswith('LR') else 'Random Forest',
                     'Test_N':len(y),'Grade3_N':int(y.sum()),'AUROC':met['AUROC'],
                     'AUROC_CI_low':lo,'AUROC_CI_high':hi,
                     'AUPRC_AP':met['AUPRC_AP'],'Accuracy':met['Accuracy'],
                     'Sensitivity':met['Sensitivity'],'Specificity':met['Specificity'],
                     'F1':met['F1'],'Brier':met['Brier'],
                     'TN':met['TN'],'FP':met['FP'],'FN':met['FN'],'TP':met['TP']})
    smry=pd.DataFrame(rows);smry.to_csv(out/'Table_2_Heldout_Test_Performance_and_CIs.csv',index=False)
    cmrows=[]
    for m in MODELS:
        met=metrics[m]; cmrows.append({'Model':m,'TN':met['TN'],'FP':met['FP'],'FN':met['FN'],'TP':met['TP'],
                                     'Threshold':THRESHOLD})
    pd.DataFrame(cmrows).to_csv(out/'Test_Confusion_Matrix_Counts.csv',index=False)
    best_test=smry.loc[smry.AUROC.idxmax(),'Model']
    cv=pd.read_csv(a.previous_results/'Training_CV_Selected_Models.csv')
    cv['Model']=cv.apply(lambda r: ('Integrated' if r.feature_set=='Clinical + RNA' else 'Clinical') +
                        ('_LR' if r.algorithm=='Logistic Regression' else '_RF'),axis=1)
    # STRICT ordering criterion: original training-CV AUROC, never test performance.
    best_cv=cv.loc[cv.CV_AUROC_mean.idxmax(),'Model']
    cand=pd.read_csv(a.previous_results/'Training_CV_All_Candidates.csv')
    train_gap=[]
    for _,row in cv.iterrows():
        matched=cand[(cand['algorithm']==row['algorithm']) & (cand['feature_set']==row['feature_set']) &
                     (cand['CV_rank_AUROC']==1)]
        assert len(matched)==1
        r=matched.iloc[0]
        train_gap.append({'Model':row.Model,'Selected_CV_Train_AUROC':r.CV_train_AUROC_mean,
                          'Selected_CV_Validation_AUROC':r.CV_AUROC_mean,
                          'CV_Optimism_Gap':r.CV_train_AUROC_mean-r.CV_AUROC_mean,
                          'Observed_Test_AUROC':metrics[row.Model]['AUROC']})
    gap=pd.DataFrame(train_gap);gap.to_csv(out/'Overfitting_Diagnostics.csv',index=False)
    deltas=[]
    for algo, c, inte in [('LR','Clinical_LR','Integrated_LR'),('RF','Clinical_RF','Integrated_RF')]:
        delta=metrics[inte]['AUROC']-metrics[c]['AUROC']
        ci=np.percentile(bs_delta[algo],[2.5,97.5])
        deltas.append({'Algorithm':algo,'Delta_AUROC_Integrated_minus_Clinical':delta,
                       'Delta_AUROC_CI_low':ci[0],'Delta_AUROC_CI_high':ci[1],
                       'Delta_AUPRC_AP':metrics[inte]['AUPRC_AP']-metrics[c]['AUPRC_AP'],
                       'Delta_Accuracy':metrics[inte]['Accuracy']-metrics[c]['Accuracy'],
                       'Delta_Sensitivity':metrics[inte]['Sensitivity']-metrics[c]['Sensitivity'],
                       'Delta_Specificity':metrics[inte]['Specificity']-metrics[c]['Specificity'],
                       'Delta_F1':metrics[inte]['F1']-metrics[c]['F1']})
    delta=pd.DataFrame(deltas);delta.to_csv(out/'Paired_Incremental_Performance_5000_Bootstrap.csv',index=False)
    plot_roc(y,pred,out,smry);plot_cms(y,pred,out)
    bins=plot_calibration(y,pred[best_test],out,best_test)
    imp=cv_training_importances(train,fits,out)
    plot_importance(imp,out)
    output_predictions=pd.DataFrame({'patient_id':test.index,'observed_grade3':y})
    for m in MODELS:output_predictions[f'{m}_probability']=pred[m]
    output_predictions.to_csv(out/'Verified_Test_Predictions.csv',index=False)
    manifest={'original_n':1904,'analysis_n':len(dat),'excluded_missing_grade_n':72,
        'train_n':len(train),'test_n':len(test),'train_grade3_n':int(train.observed_grade3.sum()),
        'test_grade3_n':int(y.sum()),'train_tumor_size_missing_n':int(train.tumor_size.isna().sum()),
        'test_tumor_size_missing_n':int(test.tumor_size.isna().sum()),
        'best_training_cv_model':best_cv,'highest_observed_test_AUROC_model':best_test,
        'bootstrap':'Stratified resampling within each observed test class, 5000 repetitions, percentile 95% CI; fixed model, split-conditional',
        'threshold':THRESHOLD,'importance':'Training-only 5-fold validation permutation importance, two repeats per fold; selected hyperparameters fixed; no test data',
        'calibration':'Ten equal-frequency bins on independent heldout test; exploratory post-hoc model (highest observed test AUROC); no refitting',
        'validation_scope':'Internal single patient-disjoint stratified 80:20 split; no external validation'}
    (out/'Analysis_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    print('\nTABLE_2');print(smry.to_string(index=False,float_format=lambda x:f'{x:.5f}'))
    print('\nPAIRED_DELTA');print(delta.to_string(index=False,float_format=lambda x:f'{x:.5f}'))
    print('\nOVERFIT_GAP');print(gap.to_string(index=False,float_format=lambda x:f'{x:.5f}'))
    print('\nCALIBRATION best_test=',best_test,'Brier=',metrics[best_test]['Brier'],' CV-selected=',best_cv,
          'CV-selected Brier=',metrics[best_cv]['Brier'])
    for m in ['Integrated_LR','Integrated_RF']:
        sub=imp[imp.Model==m].sort_values('Rank_Within_Model').head(10)
        print('\nTOP_IMPORTANCE',m);print(sub[['Predictor','Mean_Delta_AUROC','SD_Delta_AUROC']].to_string(index=False,float_format=lambda x:f'{x:.5f}'))
    print('EVALUATION_COMPLETE; model integrity/split checks passed; test untouched by refitting or permutation ranking.')

if __name__=='__main__':main()
