#!/usr/bin/env python3
"""Format pre-computed evaluation CSVs into a paper-ready Excel workbook.
Only artifact_tool edits or exports the spreadsheet. Statistical computations
are exclusively performed in evaluate_metabric_models.py.
"""
import argparse,csv
from pathlib import Path
from artifact_tool import Workbook, SpreadsheetFile

def readcsv(path):
    with open(path,encoding='utf-8-sig',newline='') as h:
        return list(csv.DictReader(h))

def num(v):
    try: return float(v)
    except (ValueError,TypeError):return v

def format_sheet(sh, headers, values, title, subtitle='',colwidths=None,footnotes=None):
    n=len(headers)
    last=chr(64+n) if n<=26 else 'Z'
    sh.merge_cells(f'A1:{last}1')
    sh.get_range('A1').values=[[title]]
    sh.get_range(f'A1:{last}1').format={'fill':'#293E59','font':{'color':'#FFFFFF','bold':True,'size':14},'row_height':35,'vertical_alignment':'center'}
    sh.merge_cells(f'A2:{last}2')
    sh.get_range('A2').values=[[subtitle]]
    sh.get_range(f'A2:{last}2').format={'fill':'#E9EFF5','font':{'color':'#293E59','size':10},'row_height':25}
    sh.get_range_by_indexes(3,0,1,n).values=[headers]
    sh.get_range_by_indexes(3,0,1,n).format={
      'fill':'#DCE6ED','font':{'bold':True,'color':'#25364D','size':10},
      'row_height':36,'wrap_text':True,'vertical_alignment':'center'}
    if values:
        sh.get_range_by_indexes(4,0,len(values),n).values=values
        sh.get_range_by_indexes(4,0,len(values),n).format={'row_height':23,'vertical_alignment':'center','font':{'size':10}}
        for i in range(len(values)):
            if i%2==1:
                sh.get_range_by_indexes(4+i,0,1,n).format.fill='#F4F7FA'
    sh.freeze_panes.freeze_rows(4)
    for i in range(n):
        w=colwidths[i] if colwidths and i<len(colwidths) else (25 if i==0 else 16)
        sh.get_range_by_indexes(0,i,max(6,len(values)+5),1).format.column_width=w
    if footnotes:
        for off,foot in enumerate(footnotes):
            pos=5+len(values)+off
            sh.merge_cells(f'A{pos}:{last}{pos}')
            sh.get_range(f'A{pos}').values=[[foot]]
            sh.get_range(f'A{pos}:{last}{pos}').format={'font':{'size':9,'color':'#606975'},'wrap_text':True,'row_height':27}

def main(path, previous_results=None):
    if previous_results is None:
        candidates=[path/'prior_models',path.parent/'prior_models',Path('prior_models')]
        previous_results=next((c for c in candidates if (c/'Training_CV_Selected_Models.csv').exists()),None)
    if previous_results is None:
        raise FileNotFoundError('Supply --previous-results with archived Training_CV_Selected_Models.csv')
    wb=Workbook.create()
    summary=readcsv(path/'Table_2_Heldout_Test_Performance_and_CIs.csv')
    cv=readcsv(previous_results/'Training_CV_Selected_Models.csv')
    cvindex={('Integrated' if r['feature_set']=='Clinical + RNA' else 'Clinical')+('_LR' if r['algorithm']=='Logistic Regression' else '_RF'):r for r in cv}
    order=['Clinical_LR','Integrated_LR','Clinical_RF','Integrated_RF']
    lab={'Clinical_LR':'Clinical only / LR','Integrated_LR':'Clinical + RNA / LR',
         'Clinical_RF':'Clinical only / RF','Integrated_RF':'Clinical + RNA / RF'}
    v=[]
    for r in sorted(summary,key=lambda row:order.index(row['Model'])):
        c=cvindex[r['Model']]
        v.append([lab[r['Model']],
                 f"{float(c['CV_AUROC_mean']):.3f} ± {float(c['CV_AUROC_SD']):.3f}",
                 f"{float(r['AUROC']):.3f} ({float(r['AUROC_CI_low']):.3f}–{float(r['AUROC_CI_high']):.3f})",
                 *[round(float(r[col]),3) for col in ['AUPRC_AP','Accuracy','Sensitivity','Specificity','F1','Brier']]])
    sh=wb.worksheets.add('Table 2 - Performance')
    format_sheet(sh,['Model','Train 5-fold CV AUROC','Test AUROC (95% CI)','AUPRC','Accuracy','Sensitivity','Specificity','F1 score','Brier score'],v,
                 'Table 2. Classification performance of prespecified models',
                 'Held-out test set n = 367 (186 Grade 3; 181 Grade 1–2); threshold = 0.50.',
                 [27,24,30,13,13,15,15,13,15],
                 ['Values from the fixed test set. AUROC 95% CI: 5,000 class-stratified bootstrap resamples (percentile interval).',
                  'AUPRC is non-interpolated average precision. Lower Brier score is better; the highest test AUROC is descriptive, not a model-selection rule.'])

    def add_data(name,src,title,subtitle='',keepstrings=()):
        records=readcsv(path/src)
        fields=list(records[0].keys())
        vals=[]
        for row in records:
            vals.append([row[k] if k in keepstrings or (row[k]!='' and any(c.isalpha() for c in row[k]))
                         else num(row[k]) for k in fields])
        sheet=wb.worksheets.add(name)
        format_sheet(sheet,fields,vals,title,subtitle,
                     [max(18,min(34,len(f)+4)) for f in fields])
    add_data('Raw Test Metrics','Table_2_Heldout_Test_Performance_and_CIs.csv','Exact held-out test performance')
    add_data('Confusion Matrices','Test_Confusion_Matrix_Counts.csv','Confusion matrices (Grade 3 = positive)')
    add_data('Incremental Comparison','Paired_Incremental_Performance_5000_Bootstrap.csv',
             'Paired clinical vs integrated comparisons',
             'Δ = Integrated − Clinical for same algorithm and same 367 test subjects.')
    add_data('Calibration Bins','Calibration_Bins_Highest_Test_AUROC.csv',
             'Highest test-AUROC model: calibration by predicted-risk deciles',
             'Integrated Random Forest; decile sample sizes range 36–37.')
    add_data('Overfit Diagnostics','Overfitting_Diagnostics.csv',
             'Selected Training CV candidate: learning–validation gaps')
    add_data('Importance Summary','Training_Only_Permutation_Importance_Summary.csv',
             'Training-only 5-fold permutation importance',
             'Mean ΔAUROC over 2 repeats per fold (10 permutations per feature); does not touch Test Set.',
             keepstrings=('Model','Predictor'))
    assert len(v)==4 and len(readcsv(path/'Training_Only_Permutation_Importance_Summary.csv'))==40
    outfile=path/'METABRIC_Grade3_Model_Evaluation.xlsx'
    print('INSPECT_TABLE',wb.inspect({'kind':'table','range':'Table 2 - Performance!A4:I8',
                                   'include':'values','table_max_rows':7,'table_max_cols':9}).ndjson[:1500])
    print('INSPECT_ERRORS',wb.inspect({'kind':'match','search_term':'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A',
                 'options':{'use_regex':True,'max_results':25},'summary':'final errors'}).ndjson[:350])
    SpreadsheetFile.export_xlsx(wb).save(str(outfile))
    print('WORKBOOK_EXPORTED',outfile, 'bytes',outfile.stat().st_size)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--dir',type=Path,default=Path('.'))
    parser.add_argument('--previous-results',type=Path,default=None)
    args=parser.parse_args();main(args.dir,args.previous_results)
