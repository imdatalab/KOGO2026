# METABRIC Dataset Audit Report (00_data_audit.md)

## 1. Overview and Variable Blocks
- **Total cohort size**: 1904 patients (target 1,904 verified)
- **Total features**: 693 columns
  - Clinical features: Columns 1–31 (31 variables)
  - mRNA z-scores: Columns 32–520 (489 genes)
  - Somatic mutations: Columns 521–693 (173 genes)

## 2. Event Coding Verification & Cross-Tabulation
Validation of `overall_survival` vs `death_from_cancer`:

| overall_survival   |   Died of Disease |   Died of Other Causes |   Living |   Missing |   All |
|:-------------------|------------------:|-----------------------:|---------:|----------:|------:|
| 0                  |               622 |                    480 |        0 |         1 |  1103 |
| 1                  |                 0 |                      0 |      801 |         0 |   801 |
| All                |               622 |                    480 |      801 |         1 |  1904 |

- **Confirmation**: In this dataset, `overall_survival == 1` represents Living (survived, n=801), and `overall_survival == 0` represents Deceased (death event, n=1,103).
  - `overall_survival == 1`: all correspond to `death_from_cancer == 'Living'` (801 patients).
  - `overall_survival == 0`: partitioned into `Died of Disease` (622 patients), `Died of Other Causes` (480 patients), and 1 patient missing cause of death.
  - Event coding decision verified: `event = (overall_survival == 0).astype(int)`.

## 3. Missing Value Analysis
Clinical variables with missing values:

| Variable                       | Dtype   |   Missing_Count |   Missing_Pct |
|:-------------------------------|:--------|----------------:|--------------:|
| type_of_breast_surgery         | object  |              22 |          1.16 |
| cancer_type_detailed           | object  |              15 |          0.79 |
| cellularity                    | object  |              54 |          2.84 |
| er_status_measured_by_ihc      | object  |              30 |          1.58 |
| neoplasm_histologic_grade      | float64 |              72 |          3.78 |
| tumor_other_histologic_subtype | object  |              15 |          0.79 |
| primary_tumor_laterality       | object  |             106 |          5.57 |
| mutation_count                 | float64 |              45 |          2.36 |
| oncotree_code                  | object  |              15 |          0.79 |
| 3-gene_classifier_subtype      | object  |             204 |         10.71 |
| tumor_size                     | float64 |              20 |          1.05 |
| tumor_stage                    | float64 |             501 |         26.31 |
| death_from_cancer              | object  |               1 |          0.05 |

- mRNA expression missing count: 0 across all 489 genes (0.0%).
- Somatic mutations missing count: 0 (handled as unmutated '0').

## 4. Mutation Binarization and High-Frequency Variants
- Mutations were provided as non-zero strings/amino acid changes or '0'. All non-'0' entries were binarized to 1.
- 46 of 173 genes had mutation frequency >= 3%.

Top 10 mutated genes:

| Gene       |   Frequency |   Count |
|:-----------|------------:|--------:|
| pik3ca_mut |   0.417542  |     795 |
| tp53_mut   |   0.346113  |     659 |
| muc16_mut  |   0.171218  |     326 |
| ahnak2_mut |   0.16334   |     311 |
| kmt2c_mut  |   0.122899  |     234 |
| syne1_mut  |   0.121849  |     232 |
| gata3_mut  |   0.120798  |     230 |
| map3k1_mut |   0.103992  |     198 |
| ahnak_mut  |   0.092437  |     176 |
| dnah11_mut |   0.0919118 |     175 |

## 5. PAM50 Subtype and NC Exclusion
PAM50 distribution in raw cohort (variable `pam50_+_claudin-low_subtype`):

| pam50_+_claudin-low_subtype   |   count |
|:------------------------------|--------:|
| LumA                          |     679 |
| LumB                          |     461 |
| Her2                          |     220 |
| claudin-low                   |     199 |
| Basal                         |     199 |
| Normal                        |     140 |
| NC                            |       6 |

- Per protocol: 'NC' (Not Classified, n=6) is excluded from subtype analyses, and 'LumA' serves as reference.

## 6. Competing Risks Scale
- Breast cancer death (`Died of Disease`): 622 (32.67%)
- Other causes death (`Died of Other Causes`): 480 (25.21%)
- Living (censored): 801 (42.07%)

## 7. Data Leakage & Excluded Variables
The following variables are strictly excluded from predictive machine learning models to prevent leakage and circularity:
- `patient_id`: Unique identifier (non-predictive)
- `overall_survival`: Outcome component
- `death_from_cancer`: Outcome / cause-specific mortality leakage
- `overall_survival_months`: Time-to-event outcome
- `cohort`: Study batch / trial center identifier
- `nottingham_prognostic_index`: Derived composite clinical score based on tumor size, lymph nodes, and grade

