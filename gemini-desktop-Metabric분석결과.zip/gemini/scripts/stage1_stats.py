import os
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from lifelines import KaplanMeierFitter, CoxPHFitter, AalenJohansenFitter
from lifelines.statistics import logrank_test, proportional_hazard_test
import statsmodels.stats.multitest as smm
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT

DATA_PATH = "/Users/hwamin/Downloads/KOGO2026/gemini/data/METABRIC_RNA_Mutation.csv"
OUTPUT_DIR = "/Users/hwamin/Downloads/KOGO2026/gemini/01_stats"
RESULTS_DIR = "/Users/hwamin/Downloads/KOGO2026/gemini/results"
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

# Set high-DPI style
plt.rcParams['font.sans-serif'] = 'Helvetica', 'Arial', 'DejaVu Sans'
plt.rcParams['axes.edgecolor'] = '#333333'
plt.rcParams['axes.linewidth'] = 0.8

def run_stage1():
    print("Loading METABRIC dataset...")
    df = pd.read_csv(DATA_PATH, low_memory=False)
    n_init = len(df)
    
    # Define primary outcome
    # Event: overall_survival == 0 is death (1 = Living)
    df['os_event'] = (df['overall_survival'] == 0).astype(int)
    df['os_time'] = df['overall_survival_months'].astype(float)
    
    pam_col = 'pam50_+_claudin-low_subtype'
    
    # Protocol: Exclude PAM50 == 'NC'
    n_nc = (df[pam_col] == 'NC').sum()
    df_clean = df[df[pam_col] != 'NC'].copy()
    n_after_nc = len(df_clean)
    print(f"Cohort size: {n_init} -> Excluded NC: {n_nc} -> Remaining: {n_after_nc}")
    
    pam_order = ['LumA', 'LumB', 'Her2', 'claudin-low', 'Basal', 'Normal']
    # Filter only available subtypes
    pam_order = [p for p in pam_order if p in df_clean[pam_col].unique()]
    
    # ----------------------------------------------------
    # 1. PAM50-stratified Table 1
    # ----------------------------------------------------
    print("\n--- Generating Table 1 ---")
    cont_vars = [
        ('age_at_diagnosis', 'Age at diagnosis (years)'),
        ('tumor_size', 'Tumor size (mm)'),
        ('lymph_nodes_examined_positive', 'Positive lymph nodes (n)'),
        ('mutation_count', 'Mutation count')
    ]
    
    cat_vars = [
        ('neoplasm_histologic_grade', 'Histologic Grade'),
        ('er_status', 'ER status'),
        ('her2_status', 'HER2 status'),
        ('pr_status', 'PR status'),
        ('chemotherapy', 'Chemotherapy'),
        ('hormone_therapy', 'Hormone therapy'),
        ('radio_therapy', 'Radiotherapy'),
        ('type_of_breast_surgery', 'Type of breast surgery'),
        ('cellularity', 'Cellularity'),
        ('tumor_stage', 'Tumor stage')
    ]
    
    table1_rows = []
    
    # Header summary row
    sub_counts = {p: (df_clean[pam_col] == p).sum() for p in pam_order}
    hdr_row = {'Characteristic': 'Total patients (N)', 'Overall (N=1898)': f"1898 (100.0%)"}
    for p in pam_order:
        hdr_row[f"{p} (N={sub_counts[p]})"] = f"{sub_counts[p]} ({sub_counts[p]/n_after_nc*100:.1f}%)"
    hdr_row['p-value'] = '-'
    table1_rows.append(hdr_row)
    
    # Continuous variables
    for var, label in cont_vars:
        # Normality test across complete cases
        valid_vals = df_clean[var].dropna()
        stat_norm, p_norm = stats.shapiro(valid_vals[:5000]) if len(valid_vals) > 3 else (0, 0)
        is_normal = p_norm > 0.05
        
        # Test across groups
        grouped_vals = [df_clean[df_clean[pam_col] == p][var].dropna().values for p in pam_order]
        if is_normal:
            _, p_val = stats.f_oneway(*grouped_vals)
            test_name = "ANOVA"
            fmt_str = lambda s: f"{s.mean():.1f} ± {s.std():.1f}"
            lbl_suffix = " (mean ± SD)"
        else:
            _, p_val = stats.kruskal(*grouped_vals)
            test_name = "Kruskal-Wallis"
            fmt_str = lambda s: f"{s.median():.1f} [{s.quantile(0.25):.1f}–{s.quantile(0.75):.1f}]"
            lbl_suffix = " (median [IQR])"
            
        row_main = {
            'Characteristic': label + lbl_suffix,
            'Overall (N=1898)': fmt_str(df_clean[var].dropna()),
            'p-value': f"{p_val:.3e}" if p_val < 0.001 else f"{p_val:.3f}"
        }
        for p in pam_order:
            sub_s = df_clean[df_clean[pam_col] == p][var].dropna()
            row_main[f"{p} (N={sub_counts[p]})"] = fmt_str(sub_s) if len(sub_s) > 0 else "N/A"
        table1_rows.append(row_main)
        
        # Missing row
        n_miss = df_clean[var].isnull().sum()
        if n_miss > 0:
            row_miss = {
                'Characteristic': f"  Missing",
                'Overall (N=1898)': f"{n_miss} ({n_miss/n_after_nc*100:.1f}%)",
                'p-value': '-'
            }
            for p in pam_order:
                sub_miss = df_clean[df_clean[pam_col] == p][var].isnull().sum()
                row_miss[f"{p} (N={sub_counts[p]})"] = f"{sub_miss} ({sub_miss/sub_counts[p]*100:.1f}%)"
            table1_rows.append(row_miss)
            
    # Categorical variables
    for var, label in cat_vars:
        # Cross-tab
        ct = pd.crosstab(df_clean[var].fillna('Missing'), df_clean[pam_col])
        # p-value without missing
        valid_df = df_clean.dropna(subset=[var])
        ct_valid = pd.crosstab(valid_df[var], valid_df[pam_col])
        chi2, p_val, dof, _ = stats.chi2_contingency(ct_valid)
        
        table1_rows.append({
            'Characteristic': label,
            'Overall (N=1898)': '',
            **{f"{p} (N={sub_counts[p]})": '' for p in pam_order},
            'p-value': f"{p_val:.3e}" if p_val < 0.001 else f"{p_val:.3f}"
        })
        
        # Categories
        cats = sorted([c for c in df_clean[var].dropna().unique()])
        for c in cats:
            n_tot = (df_clean[var] == c).sum()
            row_cat = {
                'Characteristic': f"  {c}",
                'Overall (N=1898)': f"{n_tot} ({n_tot/n_after_nc*100:.1f}%)",
                'p-value': ''
            }
            for p in pam_order:
                n_sub = ((df_clean[pam_col] == p) & (df_clean[var] == c)).sum()
                row_cat[f"{p} (N={sub_counts[p]})"] = f"{n_sub} ({n_sub/sub_counts[p]*100:.1f}%)"
            table1_rows.append(row_cat)
            
        # Missing
        n_miss = df_clean[var].isnull().sum()
        if n_miss > 0:
            row_miss = {
                'Characteristic': f"  Missing",
                'Overall (N=1898)': f"{n_miss} ({n_miss/n_after_nc*100:.1f}%)",
                'p-value': ''
            }
            for p in pam_order:
                sub_miss = df_clean[df_clean[pam_col] == p][var].isnull().sum()
                row_miss[f"{p} (N={sub_counts[p]})"] = f"{sub_miss} ({sub_miss/sub_counts[p]*100:.1f}%)"
            table1_rows.append(row_miss)
            
    table1_df = pd.DataFrame(table1_rows)
    table1_df.to_csv(os.path.join(OUTPUT_DIR, "table1.csv"), index=False)
    print("Saved table1.csv")
    
    # Create Word docx for Table 1
    doc = Document()
    doc.add_heading("Table 1. Baseline Clinical and Genomic Characteristics of the METABRIC Cohort Stratified by PAM50 Subtype", level=1)
    doc_table = doc.add_table(rows=len(table1_df) + 1, cols=len(table1_df.columns))
    doc_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    doc_table.style = 'Table Grid'
    
    # Set headers
    hdr_cells = doc_table.rows[0].cells
    for col_idx, col_name in enumerate(table1_df.columns):
        hdr_cells[col_idx].text = str(col_name)
        for paragraph in hdr_cells[col_idx].paragraphs:
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(8.5)
                
    # Fill data
    for r_idx, row in table1_df.iterrows():
        row_cells = doc_table.rows[r_idx + 1].cells
        for col_idx, col_name in enumerate(table1_df.columns):
            row_cells[col_idx].text = str(row[col_name])
            for paragraph in row_cells[col_idx].paragraphs:
                for run in paragraph.runs:
                    run.font.size = Pt(8)
    doc.save(os.path.join(OUTPUT_DIR, "table1.docx"))
    print("Saved table1.docx")
    
    # ----------------------------------------------------
    # 2. PAM50 Kaplan-Meier Survival Analysis
    # ----------------------------------------------------
    print("\n--- Generating PAM50 KM Curves ---")
    fig, (ax, ax_table) = plt.subplots(2, 1, figsize=(9.5, 7.5), gridspec_kw={'height_ratios': [3.8, 1.2]}, dpi=300)
    
    colors = {
        'LumA': '#1f77b4',       # Dark blue
        'LumB': '#aec7e8',       # Light blue
        'Her2': '#ff7f0e',       # Orange
        'Basal': '#d62728',      # Red
        'claudin-low': '#9467bd', # Purple
        'Normal': '#2ca02c'      # Green
    }
    
    kmf_dict = {}
    time_pts = [0, 60, 120, 180, 240, 300]
    table_data = []
    km_stats_dict = {}
    
    for p in pam_order:
        sub_df = df_clean[df_clean[pam_col] == p]
        kmf = KaplanMeierFitter()
        kmf.fit(sub_df['os_time'], event_observed=sub_df['os_event'], label=p)
        kmf_dict[p] = kmf
        kmf.plot_survival_function(ax=ax, color=colors.get(p, 'black'), ci_show=True, ci_alpha=0.12, linewidth=1.8)
        
        # Risk table numbers
        at_risk = [int(kmf.event_table.loc[:t, 'at_risk'].iloc[-1]) if t in kmf.event_table.index or len(kmf.event_table.loc[:t]) > 0 else 0 for t in time_pts]
        table_data.append([p] + at_risk)
        
        # 5-year, 10-year OS and median survival
        surv_60 = kmf.predict(60.0)
        surv_120 = kmf.predict(120.0)
        ci_60 = kmf.confidence_interval_survival_function_.loc[60.0] if 60.0 in kmf.confidence_interval_survival_function_.index else (np.nan, np.nan)
        med_surv = kmf.median_survival_time_
        km_stats_dict[p] = {
            '5_year_os': float(surv_60),
            '10_year_os': float(surv_120),
            'median_survival_months': float(med_surv) if not np.isinf(med_surv) else None
        }
        
    # Log-rank test across all groups
    from lifelines.statistics import multivariate_logrank_test
    lr_res = multivariate_logrank_test(df_clean['os_time'], df_clean[pam_col], df_clean['os_event'])
    p_logrank = lr_res.p_value
    
    ax.set_xlim(0, 300)
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("Overall Survival Time (Months)", fontsize=11, fontweight='medium')
    ax.set_ylabel("Overall Survival Probability", fontsize=11, fontweight='medium')
    ax.set_title("Overall Survival Stratified by PAM50 Subtype in METABRIC Cohort (N=1,898)", fontsize=12, fontweight='bold', pad=12)
    ax.grid(True, linestyle='--', alpha=0.35)
    ax.legend(title='PAM50 Subtype', loc='lower left', frameon=True, framealpha=0.9, fontsize=9.5)
    
    lr_text = f"Multivariate Log-rank p < 0.001\n(Chi-square = {lr_res.test_statistic:.2f}, df = {lr_res.degrees_of_freedom})"
    ax.text(0.97, 0.95, lr_text, transform=ax.transAxes, ha='right', va='top', 
            fontsize=9.5, bbox=dict(boxstyle='round,pad=0.5', facecolor='#f8f9fa', edgecolor='#cccccc', alpha=0.9))
    
    # Table below plot
    ax_table.axis('off')
    col_labels = ['Subtype'] + [f"{t} mo" for t in time_pts]
    tbl = ax_table.table(cellText=table_data, colLabels=col_labels, loc='center', cellLoc='center')
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(8.5)
    tbl.scale(1.0, 1.35)
    for (r, c), cell in tbl.get_celld().items():
        cell.set_edgecolor('#cccccc')
        if r == 0:
            cell.set_text_props(weight='bold')
            cell.set_facecolor('#f0f0f0')
            
    plt.tight_layout()
    fig1_path = os.path.join(OUTPUT_DIR, "fig1_km_pam50.png")
    plt.savefig(fig1_path, dpi=300, bbox_inches='tight')
    plt.close()
    print("Saved fig1_km_pam50.png")
    
    # ----------------------------------------------------
    # 3. Multivariate Cox Regression
    # ----------------------------------------------------
    print("\n--- Fitting Multivariate Cox Regression ---")
    cox_cols = [
        'age_at_diagnosis', 'tumor_size', 'lymph_nodes_examined_positive',
        'neoplasm_histologic_grade', 'er_status', 'her2_status',
        'chemotherapy', 'hormone_therapy', 'radio_therapy', pam_col,
        'os_time', 'os_event'
    ]
    df_cox_raw = df_clean[cox_cols].copy()
    n_cox_raw = len(df_cox_raw)
    df_cox = df_cox_raw.dropna().copy()
    n_cox_complete = len(df_cox)
    n_cox_excluded = n_cox_raw - n_cox_complete
    print(f"Cox model: Raw N = {n_cox_raw}, Complete cases = {n_cox_complete}, Excluded = {n_cox_excluded} ({n_cox_excluded/n_cox_raw*100:.1f}%)")
    
    # Encoding for Cox:
    # ER status: Positive (ref: Negative)
    df_cox['er_positive'] = (df_cox['er_status'].astype(str).str.lower().str.startswith('pos')).astype(int)
    # HER2 status: Positive (ref: Negative)
    df_cox['her2_positive'] = (df_cox['her2_status'].astype(str).str.lower().str.startswith('pos')).astype(int)
    # Chemotherapy, hormone, radio: 0 or 1
    df_cox['chemo'] = df_cox['chemotherapy'].astype(int)
    df_cox['hormone'] = df_cox['hormone_therapy'].astype(int)
    df_cox['radio'] = df_cox['radio_therapy'].astype(int)
    
    # Grade: dummy variables (Grade 1 as reference)
    df_cox['grade_2'] = (df_cox['neoplasm_histologic_grade'] == 2).astype(int)
    df_cox['grade_3'] = (df_cox['neoplasm_histologic_grade'] == 3).astype(int)
    
    # PAM50: dummy variables (LumA as reference)
    for p in ['LumB', 'Her2', 'claudin-low', 'Basal', 'Normal']:
        df_cox[f'pam50_{p}'] = (df_cox[pam_col] == p).astype(int)
        
    model_features = [
        'age_at_diagnosis', 'tumor_size', 'lymph_nodes_examined_positive',
        'grade_2', 'grade_3', 'er_positive', 'her2_positive',
        'chemo', 'hormone', 'radio',
        'pam50_LumB', 'pam50_Her2', 'pam50_claudin-low', 'pam50_Basal', 'pam50_Normal',
        'os_time', 'os_event'
    ]
    
    cph = CoxPHFitter()
    cph.fit(df_cox[model_features], duration_col='os_time', event_col='os_event')
    cph_summary = cph.summary.copy()
    cph_summary['HR'] = np.exp(cph_summary['coef'])
    cph_summary['95% CI Lower'] = np.exp(cph_summary['coef lower 95%'])
    cph_summary['95% CI Upper'] = np.exp(cph_summary['coef upper 95%'])
    cph_summary.to_csv(os.path.join(OUTPUT_DIR, "cox_multivariate_summary.csv"))
    print("Multivariate Cox Summary:")
    print(cph_summary[['HR', '95% CI Lower', '95% CI Upper', 'p']].head(10))
    
    # Schoenfeld test for PH assumption
    ph_test = proportional_hazard_test(cph, df_cox[model_features], time_transform='rank')
    ph_summary = ph_test.summary
    ph_summary.to_csv(os.path.join(OUTPUT_DIR, "schoenfeld_ph_test.csv"))
    violating_vars = ph_summary[ph_summary['p'] < 0.05].index.tolist()
    print(f"Variables violating PH assumption (p < 0.05): {violating_vars}")
    
    # Forest Plot
    fig, ax = plt.subplots(figsize=(8.5, 7.5), dpi=300)
    forest_df = cph_summary.copy()
    feature_labels = {
        'age_at_diagnosis': 'Age at diagnosis (per 1 yr)',
        'tumor_size': 'Tumor size (per 1 mm)',
        'lymph_nodes_examined_positive': 'Positive lymph nodes (per 1 node)',
        'grade_2': 'Histologic Grade 2 (vs Grade 1)',
        'grade_3': 'Histologic Grade 3 (vs Grade 1)',
        'er_positive': 'ER Status (Positive vs Negative)',
        'her2_positive': 'HER2 Status (Positive vs Negative)',
        'chemo': 'Chemotherapy (Yes vs No)',
        'hormone': 'Hormone Therapy (Yes vs No)',
        'radio': 'Radiotherapy (Yes vs No)',
        'pam50_LumB': 'PAM50 LumB (vs LumA)',
        'pam50_Her2': 'PAM50 Her2 (vs LumA)',
        'pam50_claudin-low': 'PAM50 Claudin-low (vs LumA)',
        'pam50_Basal': 'PAM50 Basal (vs LumA)',
        'pam50_Normal': 'PAM50 Normal-like (vs LumA)'
    }
    forest_df['Label'] = [feature_labels.get(idx, idx) for idx in forest_df.index]
    forest_df = forest_df.iloc[::-1] # top to bottom
    
    y_pos = np.arange(len(forest_df))
    hrs = forest_df['HR'].values
    ci_low = forest_df['95% CI Lower'].values
    ci_high = forest_df['95% CI Upper'].values
    p_vals = forest_df['p'].values
    
    ax.axvline(1.0, color='gray', linestyle='--', linewidth=1)
    ax.errorbar(hrs, y_pos, xerr=[hrs - ci_low, ci_high - hrs], fmt='o', color='#1f77b4',
                ecolor='#333333', elinewidth=1.5, capsize=3.5, markersize=6)
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(forest_df['Label'], fontsize=9.5)
    ax.set_xscale('log')
    ax.set_xlabel("Hazard Ratio (95% Confidence Interval)", fontsize=11, fontweight='medium')
    ax.set_title(f"Multivariate Cox Proportional Hazards Model for Overall Survival (N={n_cox_complete})", fontsize=11.5, fontweight='bold', pad=10)
    ax.grid(True, linestyle=':', alpha=0.5, axis='x')
    
    # Annotate HR and p-value on right side
    for i, (hr, low, high, p) in enumerate(zip(hrs, ci_low, ci_high, p_vals)):
        p_txt = "<0.001" if p < 0.001 else f"{p:.3f}"
        ax.text(ax.get_xlim()[1]*1.05, i, f"HR {hr:.2f} ({low:.2f}–{high:.2f}), p={p_txt}", 
                va='center', fontsize=8.5, color='#111111')
        
    plt.tight_layout()
    fig2_path = os.path.join(OUTPUT_DIR, "fig2_forest.png")
    plt.savefig(fig2_path, dpi=300, bbox_inches='tight')
    plt.close()
    print("Saved fig2_forest.png")
    
    # ----------------------------------------------------
    # 4. Competing Risks Analysis
    # ----------------------------------------------------
    print("\n--- Competing Risks Analysis (LumA, Her2, Basal) ---")
    comp_subtypes = ['LumA', 'Her2', 'Basal']
    df_comp = df_clean[df_clean[pam_col].isin(comp_subtypes)].copy()
    # Event coding:
    # 0 = Living / censored
    # 1 = Died of Disease (breast cancer mortality)
    # 2 = Died of Other Causes (competing mortality)
    df_comp['event_type'] = 0
    df_comp.loc[df_comp['death_from_cancer'] == 'Died of Disease', 'event_type'] = 1
    df_comp.loc[df_comp['death_from_cancer'] == 'Died of Other Causes', 'event_type'] = 2
    
    # Compare CIF vs 1 - KM at 120 months
    comp_results = []
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), sharey=True, dpi=300)
    
    for idx, st in enumerate(comp_subtypes):
        st_data = df_comp[df_comp[pam_col] == st]
        
        # Aalen-Johansen CIF for cause 1
        ajf = AalenJohansenFitter(calculate_variance=True)
        ajf.fit(st_data['os_time'], st_data['event_type'], event_of_interest=1)
        cif_120 = ajf.predict(120.0)
        
        # 1 - KM for cause 1 (treating cause 2 as censored)
        kmf_bc = KaplanMeierFitter()
        kmf_bc.fit(st_data['os_time'], event_observed=(st_data['event_type'] == 1).astype(int))
        one_minus_km_120 = 1.0 - kmf_bc.predict(120.0)
        
        diff_120 = one_minus_km_120 - cif_120
        comp_results.append({
            'Subtype': st,
            'N_total': len(st_data),
            'Breast_Cancer_Deaths': (st_data['event_type'] == 1).sum(),
            'Other_Cause_Deaths': (st_data['event_type'] == 2).sum(),
            'CIF_120mo': float(cif_120),
            'One_minus_KM_120mo': float(one_minus_km_120),
            'Absolute_Overestimation_KM': float(diff_120),
            'Relative_Overestimation_Pct': float(diff_120 / cif_120 * 100) if cif_120 > 0 else 0
        })
        
        # Plot comparison
        ax_i = axes[idx]
        ajf.plot(ax=ax_i, label='CIF (Aalen-Johansen)', color='#d62728', linewidth=2)
        (1.0 - kmf_bc.survival_function_).plot(ax=ax_i, label='1 - KM (Naive Censoring)', color='#1f77b4', linestyle='--', linewidth=1.8)
        ax_i.set_xlim(0, 300)
        ax_i.set_ylim(0, 0.75)
        ax_i.set_title(f"{st} (N={len(st_data)})", fontsize=11, fontweight='bold')
        ax_i.set_xlabel("Time (Months)", fontsize=10)
        if idx == 0:
            ax_i.set_ylabel("Cumulative Incidence of BC Death", fontsize=10)
        ax_i.grid(True, linestyle=':', alpha=0.5)
        ax_i.legend(loc='upper left', fontsize=8.5)
        
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig_competing_risks_cif_vs_km.png"), dpi=300)
    plt.close()
    
    comp_df = pd.DataFrame(comp_results)
    comp_df.to_csv(os.path.join(OUTPUT_DIR, "competing_risks_120mo_comparison.csv"), index=False)
    print("Competing risks 120-month comparison:")
    print(comp_df)
    
    # Cause-specific Cox regression comparing Age HR
    # Age HR on Cause 1 (BC death) vs Cause 2 (Other death)
    cph_bc = CoxPHFitter()
    df_cox_bc = df_clean[['age_at_diagnosis', 'os_time', 'death_from_cancer']].dropna().copy()
    df_cox_bc['bc_event'] = (df_cox_bc['death_from_cancer'] == 'Died of Disease').astype(int)
    cph_bc.fit(df_cox_bc[['age_at_diagnosis', 'os_time', 'bc_event']], duration_col='os_time', event_col='bc_event')
    hr_age_bc = np.exp(cph_bc.params_['age_at_diagnosis'])
    ci_age_bc = [np.exp(cph_bc.confidence_intervals_.loc['age_at_diagnosis', '95% lower-bound']),
                 np.exp(cph_bc.confidence_intervals_.loc['age_at_diagnosis', '95% upper-bound'])]
    p_age_bc = cph_bc.summary.loc['age_at_diagnosis', 'p']
    
    cph_other = CoxPHFitter()
    df_cox_other = df_clean[['age_at_diagnosis', 'os_time', 'death_from_cancer']].dropna().copy()
    df_cox_other['other_event'] = (df_cox_other['death_from_cancer'] == 'Died of Other Causes').astype(int)
    cph_other.fit(df_cox_other[['age_at_diagnosis', 'os_time', 'other_event']], duration_col='os_time', event_col='other_event')
    hr_age_other = np.exp(cph_other.params_['age_at_diagnosis'])
    ci_age_other = [np.exp(cph_other.confidence_intervals_.loc['age_at_diagnosis', '95% lower-bound']),
                    np.exp(cph_other.confidence_intervals_.loc['age_at_diagnosis', '95% upper-bound'])]
    p_age_other = cph_other.summary.loc['age_at_diagnosis', 'p']
    
    print(f"Cause-specific Cox Age HR (Breast Cancer Death): HR={hr_age_bc:.3f} (95% CI {ci_age_bc[0]:.3f}–{ci_age_bc[1]:.3f}, p={p_age_bc:.3e})")
    print(f"Cause-specific Cox Age HR (Other Cause Death):   HR={hr_age_other:.3f} (95% CI {ci_age_other[0]:.3f}–{ci_age_other[1]:.3f}, p={p_age_other:.3e})")
    
    # Save Fine-Gray R script
    fg_r_code = """# Fine-Gray Subdistribution Hazard Regression for METABRIC Cohort
# Required R packages: cmprsk, survival, tidycmprsk
suppressPackageStartupMessages({
  if (!requireNamespace("cmprsk", quietly = TRUE)) install.packages("cmprsk")
  library(cmprsk)
  library(survival)
})

# Load clean METABRIC dataset
data <- read.csv("METABRIC_RNA_Mutation.csv", stringsAsFactors = FALSE)
data <- data[data$pam50_._claudin.low_subtype != "NC", ]

# Event coding: 0=censored, 1=Died of Disease (Breast Cancer), 2=Died of Other Causes
data$status <- 0
data$status[data$death_from_cancer == "Died of Disease"] <- 1
data$status[data$death_from_cancer == "Died of Other Causes"] <- 2

# Covariates matrix
covs <- model.matrix(~ age_at_diagnosis + tumor_size + lymph_nodes_examined_positive + 
                       er_status + pam50_._claudin.low_subtype, data = data)[, -1]

# Fit Fine-Gray subdistribution hazard model for cause 1 (Breast cancer mortality)
fg_fit <- crr(ftime = data$overall_survival_months, 
              fstatus = data$status, 
              cov1 = covs, 
              failcode = 1, 
              cencode = 0)

summary(fg_fit)
"""
    with open(os.path.join(OUTPUT_DIR, "fine_gray_analysis.R"), "w") as f:
        f.write(fg_r_code)
    print("Saved fine_gray_analysis.R")
    
    # ----------------------------------------------------
    # 5. Genomics Analysis
    # ----------------------------------------------------
    print("\n--- Genomics Analysis: 489 mRNA univariate Cox models ---")
    mrna_cols = df.columns[31:520].tolist()
    genomics_results = []
    
    # Univariate Cox for each mRNA gene
    for g in mrna_cols:
        sub_g = df_clean[[g, 'os_time', 'os_event']].dropna()
        cph_g = CoxPHFitter()
        try:
            cph_g.fit(sub_g, duration_col='os_time', event_col='os_event')
            coef = cph_g.params_[g]
            hr = np.exp(coef)
            ci_low = np.exp(cph_g.confidence_intervals_.loc[g, '95% lower-bound'])
            ci_high = np.exp(cph_g.confidence_intervals_.loc[g, '95% upper-bound'])
            pval = cph_g.summary.loc[g, 'p']
            z = cph_g.summary.loc[g, 'z']
            genomics_results.append({
                'gene': g,
                'coef': coef,
                'HR': hr,
                'HR_lower95': ci_low,
                'HR_upper95': ci_high,
                'p_value': pval,
                'z_score': z
            })
        except Exception as e:
            continue
            
    df_mrna_cox = pd.DataFrame(genomics_results)
    # BH-FDR correction
    rejected, q_values, _, _ = smm.multipletests(df_mrna_cox['p_value'], method='fdr_bh')
    df_mrna_cox['q_value_fdr'] = q_values
    df_mrna_cox['significant_fdr_05'] = rejected
    df_mrna_cox.sort_values('p_value', inplace=True)
    df_mrna_cox.to_csv(os.path.join(OUTPUT_DIR, "genomics_univariate_cox_489.csv"), index=False)
    
    n_sig_fdr = int(df_mrna_cox['significant_fdr_05'].sum())
    print(f"489 mRNA Univariate Cox: {n_sig_fdr} genes significant at BH-FDR q < 0.05")
    print("Top 10 prognostic genes by FDR:")
    print(df_mrna_cox[['gene', 'HR', 'HR_lower95', 'HR_upper95', 'p_value', 'q_value_fdr']].head(10))
    
    # Volcano Plot
    fig, ax = plt.subplots(figsize=(7.5, 6), dpi=300)
    df_mrna_cox['neg_log10_p'] = -np.log10(df_mrna_cox['p_value'])
    sig_mask = df_mrna_cox['q_value_fdr'] < 0.05
    
    ax.scatter(df_mrna_cox.loc[~sig_mask, 'coef'], df_mrna_cox.loc[~sig_mask, 'neg_log10_p'],
               color='#999999', alpha=0.5, s=25, label='FDR q ≥ 0.05')
    ax.scatter(df_mrna_cox.loc[sig_mask & (df_mrna_cox['coef'] > 0), 'coef'], 
               df_mrna_cox.loc[sig_mask & (df_mrna_cox['coef'] > 0), 'neg_log10_p'],
               color='#d62728', alpha=0.7, s=35, label='High risk (HR > 1, FDR < 0.05)')
    ax.scatter(df_mrna_cox.loc[sig_mask & (df_mrna_cox['coef'] < 0), 'coef'], 
               df_mrna_cox.loc[sig_mask & (df_mrna_cox['coef'] < 0), 'neg_log10_p'],
               color='#1f77b4', alpha=0.7, s=35, label='Low risk (HR < 1, FDR < 0.05)')
    
    # Label top 5 genes
    top_label_genes = df_mrna_cox.head(8)
    for _, r in top_label_genes.iterrows():
        ax.text(r['coef'], r['neg_log10_p'] + 0.15, r['gene'], fontsize=8, ha='center', weight='bold')
        
    ax.axvline(0, color='black', linestyle='--', linewidth=0.8)
    ax.set_xlabel("Log Hazard Ratio (Cox Coefficient)", fontsize=11)
    ax.set_ylabel("-log10(p-value)", fontsize=11)
    ax.set_title("Volcano Plot: 489 mRNA Expression Markers vs Overall Survival", fontsize=11.5, fontweight='bold')
    ax.legend(frameon=True, fontsize=9)
    ax.grid(True, linestyle=':', alpha=0.5)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig_volcano_genomics.png"), dpi=300)
    plt.close()
    print("Saved fig_volcano_genomics.png")
    
    # Top 10 mutation frequencies
    mutation_cols = df.columns[520:].tolist()
    mut_bin = df_clean[mutation_cols].fillna("0").map(lambda x: 0 if str(x).strip() in ["0", ""] else 1)
    top10_mut = mut_bin.mean().sort_values(ascending=False).head(10)
    df_top10_mut = pd.DataFrame({
        'Gene': top10_mut.index,
        'Frequency': top10_mut.values,
        'Count': (top10_mut * n_after_nc).astype(int).values
    })
    df_top10_mut.to_csv(os.path.join(OUTPUT_DIR, "top10_mutations.csv"), index=False)
    
    # TP53 Mutation Analysis
    print("\n--- TP53 Mutation Survival Analysis ---")
    df_clean['tp53_status'] = mut_bin['tp53_mut']
    
    # KM for TP53
    fig, ax = plt.subplots(figsize=(7, 5.5), dpi=300)
    kmf_tp53_wt = KaplanMeierFitter()
    kmf_tp53_mut = KaplanMeierFitter()
    
    wt_data = df_clean[df_clean['tp53_status'] == 0]
    mut_data = df_clean[df_clean['tp53_status'] == 1]
    
    kmf_tp53_wt.fit(wt_data['os_time'], event_observed=wt_data['os_event'], label=f'TP53 Wild-type (N={len(wt_data)})')
    kmf_tp53_mut.fit(mut_data['os_time'], event_observed=mut_data['os_event'], label=f'TP53 Mutated (N={len(mut_data)})')
    
    kmf_tp53_wt.plot_survival_function(ax=ax, color='#1f77b4', linewidth=2)
    kmf_tp53_mut.plot_survival_function(ax=ax, color='#d62728', linewidth=2)
    
    lr_tp53 = logrank_test(wt_data['os_time'], mut_data['os_time'], 
                           event_observed_A=wt_data['os_event'], event_observed_B=mut_data['os_event'])
    
    ax.set_xlim(0, 300)
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("Overall Survival Time (Months)", fontsize=11)
    ax.set_ylabel("Overall Survival Probability", fontsize=11)
    ax.set_title("Kaplan-Meier Survival by TP53 Somatic Mutation Status", fontsize=11.5, fontweight='bold')
    ax.text(0.97, 0.95, f"Log-rank p = {lr_tp53.p_value:.3e}\nChi-square = {lr_tp53.test_statistic:.2f}",
            transform=ax.transAxes, ha='right', va='top', fontsize=9.5,
            bbox=dict(boxstyle='round,pad=0.5', facecolor='#f8f9fa', edgecolor='#cccccc'))
    ax.grid(True, linestyle='--', alpha=0.4)
    ax.legend(loc='lower left', fontsize=9.5)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "fig_tp53_km.png"), dpi=300)
    plt.close()
    
    # TP53 mutation rate by PAM50
    tp53_by_pam = pd.crosstab(df_clean[pam_col], df_clean['tp53_status'], normalize='index') * 100
    tp53_by_pam_counts = pd.crosstab(df_clean[pam_col], df_clean['tp53_status'])
    chi2_tp53, p_tp53_pam, _, _ = stats.chi2_contingency(tp53_by_pam_counts)
    print(f"TP53 mutation rate by PAM50 (Chi-square = {chi2_tp53:.2f}, p = {p_tp53_pam:.3e}):")
    tp53_pam_summary = pd.DataFrame({
        'WildType_N': tp53_by_pam_counts[0],
        'Mutated_N': tp53_by_pam_counts[1],
        'Mutation_Rate_Pct': tp53_by_pam[1].round(1)
    })
    tp53_pam_summary.to_csv(os.path.join(OUTPUT_DIR, "tp53_mutation_by_pam50.csv"))
    print(tp53_pam_summary)
    
    # Unadjusted vs Adjusted TP53 Cox HR
    # Unadjusted
    cph_tp53_unadj = CoxPHFitter()
    cph_tp53_unadj.fit(df_clean[['tp53_status', 'os_time', 'os_event']], duration_col='os_time', event_col='os_event')
    hr_unadj = np.exp(cph_tp53_unadj.params_['tp53_status'])
    ci_unadj = [np.exp(cph_tp53_unadj.confidence_intervals_.loc['tp53_status', '95% lower-bound']),
                np.exp(cph_tp53_unadj.confidence_intervals_.loc['tp53_status', '95% upper-bound'])]
    p_unadj = cph_tp53_unadj.summary.loc['tp53_status', 'p']
    
    # Adjusted for PAM50 (dummies, LumA ref)
    df_tp53_adj = df_clean[['tp53_status', 'os_time', 'os_event', pam_col]].copy()
    for p in ['LumB', 'Her2', 'claudin-low', 'Basal', 'Normal']:
        df_tp53_adj[f'pam50_{p}'] = (df_tp53_adj[pam_col] == p).astype(int)
    cph_tp53_adj = CoxPHFitter()
    adj_features = ['tp53_status', 'pam50_LumB', 'pam50_Her2', 'pam50_claudin-low', 'pam50_Basal', 'pam50_Normal', 'os_time', 'os_event']
    cph_tp53_adj.fit(df_tp53_adj[adj_features], duration_col='os_time', event_col='os_event')
    hr_adj = np.exp(cph_tp53_adj.params_['tp53_status'])
    ci_adj = [np.exp(cph_tp53_adj.confidence_intervals_.loc['tp53_status', '95% lower-bound']),
              np.exp(cph_tp53_adj.confidence_intervals_.loc['tp53_status', '95% upper-bound'])]
    p_adj = cph_tp53_adj.summary.loc['tp53_status', 'p']
    
    print(f"\nTP53 HR Unadjusted: {hr_unadj:.2f} (95% CI {ci_unadj[0]:.2f}–{ci_unadj[1]:.2f}, p={p_unadj:.3e})")
    print(f"TP53 HR Subtype-Adjusted: {hr_adj:.2f} (95% CI {ci_adj[0]:.2f}–{ci_adj[1]:.2f}, p={p_adj:.3e})")
    
    # ----------------------------------------------------
    # Verification Gate Checks
    # ----------------------------------------------------
    print("\n--- Running Verification Gate ---")
    gate_passed = True
    
    # 1. KM curves start at 1.0 and decrease
    for p, kmf in kmf_dict.items():
        s_vals = kmf.survival_function_[p].values
        if s_vals[0] != 1.0 or any(np.diff(s_vals) > 1e-6):
            print(f"FAILED Gate: KM curve for {p} does not start at 1.0 or is non-monotonic!")
            gate_passed = False
    print("[PASS] KM curves start at 1.0 and decrease monotonically.")
    
    # 2. Age HR > 1.0
    age_hr = cph_summary.loc['age_at_diagnosis', 'HR']
    if age_hr <= 1.0:
        print(f"FAILED Gate: Age HR is {age_hr} <= 1.0!")
        gate_passed = False
    else:
        print(f"[PASS] Age HR is {age_hr:.3f} > 1.0 (consistent with biology).")
        
    # 3. Sample size consistency
    if n_after_nc != 1898:
        print(f"FAILED Gate: N after NC exclusion is {n_after_nc}, expected 1898!")
        gate_passed = False
    else:
        print(f"[PASS] Sample size consistent: Total 1904, NC excluded = 6, Analyzed = 1898.")
        
    if not gate_passed:
        raise ValueError("STAGE 1 Verification Gate FAILED! Review errors.")
    print("Verification Gate PASSED successfully.")
    
    # Update results/summary.json
    with open(os.path.join(RESULTS_DIR, "summary.json"), "r") as f:
        summary = json.load(f)
        
    summary.update({
        "stage1_stats": {
            "n_after_nc": n_after_nc,
            "n_nc_excluded": n_nc,
            "multivariate_logrank_p": float(p_logrank),
            "km_stats_per_pam50": km_stats_dict,
            "cox_multivariate_complete_n": n_cox_complete,
            "cox_multivariate_excluded_n": n_cox_excluded,
            "cox_age_hr": float(age_hr),
            "cox_chemo_hr": float(cph_summary.loc['chemo', 'HR']),
            "cox_violating_ph_vars": violating_vars,
            "competing_risks_120mo": comp_results,
            "cause_specific_age_hr_bc": float(hr_age_bc),
            "cause_specific_age_hr_other": float(hr_age_other),
            "genomics_fdr_significant_count": n_sig_fdr,
            "tp53_unadjusted_hr": float(hr_unadj),
            "tp53_subtype_adjusted_hr": float(hr_adj),
            "tp53_pam50_chi2_p": float(p_tp53_pam)
        }
    })
    
    with open(os.path.join(RESULTS_DIR, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2, default=lambda o: int(o) if isinstance(o, (np.integer, np.int64)) else float(o) if isinstance(o, (np.floating, np.float64)) else str(o))
        
    print("STAGE 1 completed successfully. Results updated in summary.json.")

if __name__ == "__main__":
    run_stage1()
