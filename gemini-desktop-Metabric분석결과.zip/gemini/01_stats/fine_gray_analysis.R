# Fine-Gray Subdistribution Hazard Regression for METABRIC Cohort
# Required R packages: cmprsk, survival, tidycmprsk
suppressPackageStartupMessages({
  if (!requireNamespace("cmprsk", quietly = TRUE)) install.packages("cmprsk")
  library(cmprsk)
  library(survival)
})

# Load clean METABRIC dataset
data <- read.csv("METABRIC_RNA_Mutation.csv", stringsAsFactors = FALSE)
data <- data[data$pam50_._claudin.low_subtype != "NC", ]

# Event coding: 0=censored, 1=Died of Disease (Breast Cancer), 2=Died of Other Causes
data$status <- 0
data$status[data$death_from_cancer == "Died of Disease"] <- 1
data$status[data$death_from_cancer == "Died of Other Causes"] <- 2

# Covariates matrix
covs <- model.matrix(~ age_at_diagnosis + tumor_size + lymph_nodes_examined_positive + 
                       er_status + pam50_._claudin.low_subtype, data = data)[, -1]

# Fit Fine-Gray subdistribution hazard model for cause 1 (Breast cancer mortality)
fg_fit <- crr(ftime = data$overall_survival_months, 
              fstatus = data$status, 
              cov1 = covs, 
              failcode = 1, 
              cencode = 0)

summary(fg_fit)
