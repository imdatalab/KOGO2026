[Date]

The Editor
*BMC Cancer*

Dear Editor,

We submit the manuscript entitled "Clinical, transcriptomic and mutational correlates of overall survival and prediction of 5-year mortality in breast cancer: a reanalysis of the METABRIC cohort" for consideration as a Research Article in *BMC Cancer*.

METABRIC is widely used to develop prognostic models from tumour genomic data. In many of these analyses, all-cause death is used without regard to competing causes, and high-dimensional models are rarely compared with a well-specified clinical baseline. Our study addresses both issues in a single, fully reproducible analysis of 1,898 patients:

- 43.5% of deaths were from causes other than breast cancer. Age was associated much more strongly with other-cause death than with breast-cancer death, and one minus the Kaplan–Meier estimate exceeded the cumulative incidence of breast-cancer death at 120 months in every subtype examined.
- For death within 5 years, an XGBoost model combining clinical, expression and mutation data had a test-set AUROC of 0.771, compared with 0.739 for a clinical model. The difference was not statistically distinguishable from zero in the primary split, in a cohort-based split, or against a parsimonious clinical model.
- Discrimination, calibration, decision curves, SHAP-based interpretation, sensitivity analyses for censoring and for repeated splitting, and a TRIPOD+AI self-assessment are reported in full. The code and a number-to-source trace file are provided.

We believe these findings are relevant to the journal's readership in clinical and translational oncology because they temper expectations for omics-based prognostic models built on public cohorts.

The manuscript has not been published and is not under consideration elsewhere. All authors approved the submission. The data are publicly available, and the analysis code will be deposited in a public repository with a DOI. [Competing interests, funding and generative-AI use statements to be completed in line with journal policy.]

Sincerely,

[Corresponding author name, degree]
[Department, institution, address, e-mail]
