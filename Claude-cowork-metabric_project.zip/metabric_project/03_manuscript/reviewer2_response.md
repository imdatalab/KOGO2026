# Simulated Reviewer 2 report and point-by-point response (draft)

The additional analyses are in `scripts/s03b_reviewer_analyses.py`; their outputs are in `03_manuscript/reviewer_analyses/` and have been added to the revised Methods and Results ("Sensitivity analyses").

## Major comments

**Major 1. Exclusion of early-censored patients.** The binary 5-year outcome excludes patients censored before 60 months. These patients are unlikely to be a random subset, and their exclusion may bias both discrimination and calibration. Please justify the exclusion and quantify its impact, for example with inverse-probability-of-censoring weighting (IPCW).

*Response:* We agree. We compared excluded and included patients (`02_ml/excluded_censoring_bias.csv`). Excluded patients had a median follow-up of 25.4 months, and 66.7% came from cohort 1. We then re-estimated test-set AUROCs with IPCW, using weights from a Kaplan–Meier model of the censoring distribution (estimated probability of remaining uncensored at 60 months 0.965; weight range 1.001 to 1.036). The IPCW AUROCs were 0.738 for M1 (0.686–0.785) and 0.770 for M3 (0.722–0.814), essentially unchanged from the unweighted values. The exclusion and the possible selection bias are now described in the Methods, Results and Limitations. A fully time-to-event model (for example penalised Cox with time-dependent AUROC) remains a direction for future work.

**Major 2. Instability of a single random split.** Conclusions about M3 versus M1 rest on one 70:30 split, and the DeLong CI includes zero. Please assess variability across splits.

*Response:* We refitted M1 and M3 in 50 repeated stratified splits; M3 hyperparameters were fixed at the tuned values to limit computation. The mean AUROC was 0.745 for M1 and 0.774 for M3. The mean difference was 0.029 (2.5th–97.5th percentile 0.002 to 0.050), and M3 exceeded M1 in 100% of splits (`R2_repeated_splits.csv`). This suggests a small but consistent advantage of M3 over the unpenalised M1. However, these splits are not independent samples, and the advantage was negligible in the cohort-based split (0.005). We have therefore kept the cautious wording of the conclusions.

**Major 3. Choice of clinical comparator.** M1 contains treatment variables and expression-derived labels (PAM50, integrative cluster, 3-gene classifier), so it is neither a purely clinical model nor a well-specified one. Its calibration slope suggests overfitting. Please compare against a parsimonious model of routinely available baseline variables.

*Response:* We added a parsimonious logistic model with age, tumour size, positive nodes, grade, ER, PR and HER2 status, and menopausal state. Its test-set AUROC was 0.755 (0.705–0.800), with a calibration slope of 1.01. This is not lower than M1 (M1 minus parsimonious model -0.016; p = 0.349). The M3 advantage over this model was 0.016 (-0.018 to 0.050; p = 0.356). The Discussion now states that the expression-derived labels and treatment variables in M1 did not improve discrimination, and that M1 was overfitted.

**Major 4. All-cause endpoint despite substantial competing mortality.** The authors themselves show that many deaths are not due to breast cancer, yet the prediction models target all-cause death. Please report performance for breast-cancer-specific death.

*Response:* We evaluated the existing test-set predictions against breast-cancer death within 60 months (91 events; 32 other-cause deaths). Treating other-cause deaths as non-events, AUROCs were 0.740 (M1), 0.789 (M2), 0.799 (M3) and 0.708 (M4). Excluding other-cause deaths, they were 0.753, 0.794, 0.808 and 0.707. The genomic models discriminated cancer-specific death better than all-cause death, whereas M1 did not. This is reported as a post hoc observation. Models trained directly for the cause-specific outcome would require a separate pre-specified analysis.

**Major 5. Confounding in the gene-level screen.** Univariable gene-level Cox models mainly recover genes correlated with subtype, proliferation and stage. The number of "significant" genes is therefore not informative.

*Response:* We repeated the gene-level models with adjustment for age, tumour size, nodes, grade, ER, HER2 and subtype (1,810 patients; 1,037 deaths). After FDR correction, 7 genes retained q<0.05, compared with 125 in univariable models; 5 were significant in both. The strongest adjusted association was for MMP11 (HR 1.15 per SD; 1.08–1.23). The Results now label the univariable screen as descriptive and the Discussion reports the attenuation after adjustment (`R5_gene_cox_adjusted.csv`).

## Minor comments

**Minor 1.** Table 1 reports many p values without adjustment. *Response:* Table 1 is descriptive. We now state that its p values are descriptive and not corrected for multiplicity, and we avoid inferential statements based on them.

**Minor 2.** The calibration slope of M1 (0.71) indicates overfitting; please consider penalisation. *Response:* A ridge-penalised M1 had an AUROC of 0.754 (0.706–0.801) and a calibration slope of 0.96. Penalisation improved calibration and did not reduce discrimination. This is reported in the Sensitivity analyses.

**Minor 3.** The mutation definition (any value other than "0") does not distinguish functional from passenger variants. *Response:* Agreed. The file contains protein-change strings (9,739 non-zero cells, 728 with more than one variant) without annotation of pathogenicity. We now state this as a limitation and describe the binary coding explicitly in the Methods.

**Minor 4.** Please specify how median follow-up and the proportional hazards tests were obtained. *Response:* Median follow-up (196.9 months) was estimated with the reverse Kaplan–Meier method. Proportional hazards were tested with Schoenfeld residuals using rank-transformed time. Both are now stated in the Methods.

**Minor 5.** Reproducibility: software versions, random seeds and code availability should be reported. *Response:* Package versions were queried from the analysis environment and are listed in the Methods. All random processes used seed 42, except the repeated splits (seeds 42 to 91). Every number in the text is linked to its source file in `number_trace.csv`, and the code will be deposited with a DOI.
