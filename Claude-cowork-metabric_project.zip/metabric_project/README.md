# METABRIC survival and 5-year mortality prediction — project folder

The research question is whether clinical information at diagnosis, together with tumour gene expression and mutations, predicts overall survival (OS) and 5-year death in breast cancer.
The data are in `data/METABRIC_RNA_Mutation.csv`, a working copy of the upload. The original file was not modified.

## Folder structure
| Folder | Contents |
|---|---|
| `data/` | Working copy of the input data |
| `scripts/` | All code that was actually run (Python and R), in the order listed below |
| `00_data_audit.md`, `00_audit/` | STAGE 0 data audit (missingness, event-coding cross-table, mutation binarisation, leakage table, competing risks) |
| `01_stats/` | STAGE 1: Table 1 (`table1.csv/.md/.docx`), KM curves, Cox model with PH diagnostics and two alternative models, competing risks (incl. Fine–Gray, `finegray_code.R`), genomics, `gate_stage1.md` |
| `02_ml/` | STAGE 2: metrics, ROC/calibration/DCA, SHAP, LASSO coefficients, cohort-split comparison, `gate_stage2.md`, `tripod_ai_check.md`, fitted models (`models/*.joblib`) |
| `03_manuscript/` | STAGE 3: `manuscript.md/.docx`, `Tables_1-3.docx`, `Figure1-4.tiff`, `figure_legends.md`, `number_trace.csv`, `journal_comparison.md`, `cover_letter.md/.docx`, `reviewer2_response.md`, `reviewer_analyses/`, `templates/` |
| `results/` | `summary.json` (central store of numbers), `versions.json`, plotting data, logs |

## Run order
`s00_data_audit.py` → `s01a_table1.py` → `s01b_km.py` → `s01c_cox.py` → `s01d_competing.py` → `Rscript s01d_finegray.R` → `s01e_genomics.py` → `s01f_gate.py` → `s02a_ml_random.py` (~10 min) → `s02b_ml_cohort.py` (~10 min) → `s03a_versions.py` → `s03b_reviewer_analyses.py` → `s03d_build_text.py` → `s03c_figures.py` → `s03e_tables_docx.py`.
Shared helpers are in `common.py` and `ml_common.py`. The seed is 42 throughout; the repeated splits use seeds 42–91.

## How the manuscript numbers are traced
The manuscript, figure legends, cover letter and reviewer response are generated from `03_manuscript/templates/` by `s03d_build_text.py`. Every number is either pulled from `results/summary.json` (or `02_ml/subgroup_auroc.csv`) or is a registered design constant that points to a script line. The build fails if any number is left untraced. The final run had 431 traced numbers and 0 untraced (`number_trace.csv`). Table 1–3 numbers come directly from `01_stats/table1.csv`, `01_stats/cox_multivariable.csv` and `results/summary.json`.

## Deviations and additions to the pre-specified plan (none changes a pre-specified decision)
1. `overall_survival_months` was also excluded from the ML predictors because it defines the outcome (direct leakage).
2. 'NC' (n=6) was excluded in every stage, including ML, for consistency (sample size: 1,904 → 1,898).
3. The ≥3% mutation-frequency filter was computed on the training set only. This selected 45 genes; the full data gives 46.
4. Fine–Gray was run in R 4.3.3 with `survival::finegray`, installed in this environment, rather than only written as code.
5. For sparse categorical tables, Fisher's exact test for r×c tables was replaced by a Monte Carlo permutation χ² test (9,999 resamples).
6. The Aalen–Johansen estimator (lifelines) breaks tied event times with a seeded random jitter.

## Stage reports
- **STAGE 0:** N=1,904 × 693 confirmed. Event coding verified (0 inconsistent records). 43.5% of deaths are other-cause. 46 genes are mutated in ≥3%.
- **STAGE 1:** Gate 13/13 passed. Log-rank χ²=52.8 (p<0.001). Cox n=1,810, age HR 1.52 per 10 years. Five covariates violate proportional hazards and were handled with stratified and piecewise alternatives. Fine–Gray age sHR 1.04. 125 of 489 genes have q<0.05.
- **STAGE 2:** Gate 7/7 passed. N=1,838 (411 events). Test AUROC: M1 0.739, M2 0.743, M3 0.771, M4 0.655. M3−M1 = 0.032 (p=0.10). Cohort split: M3 0.798 vs M1 0.793.
- **STAGE 3:** Manuscript, 3 tables, 4 TIFF figures, number trace, 5-journal comparison (1st choice BMC Cancer), cover letter, and Reviewer 2 report with 5 major and 5 minor points plus responses. Six additional analyses were run for the responses.

## Remaining author tasks
- Replace the `[REF: ...]` placeholders with verified citations.
- Complete the author list, ethics, funding, conflict of interest and generative-AI disclosure.
- Deposit the code with a DOI.
- Re-check journal fees on the submission date.
- Review the TRIPOD+AI partial and not-met items.
