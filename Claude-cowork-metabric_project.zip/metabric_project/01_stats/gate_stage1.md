# STAGE 1 validation gate

| Check | Result |
|---|---|
| KM starts at 1 and is non-increasing (all subtypes) | PASS |
| Age HR > 1 (multivariable Cox) | PASS |
| Age HR > 1 (cause-specific, both causes) | PASS |
| Table 1 subtype N sum = analysed N | PASS |
| Table 1 N + NC excluded = 1904 | PASS |
| KM N = Table 1 N | PASS |
| KM number-at-risk at t=0 = KM N | PASS |
| KM subtype n sum = KM N | PASS |
| Cox complete + excluded = Table 1 N | PASS |
| Cause-specific N + cause-missing + missing covariates = Table 1 N | PASS |
| Fine-Gray N = cause-specific N | PASS |
| Genomics N = Table 1 N | PASS |
| TP53-by-PAM50 n sum = Table 1 N | PASS |

Competing-risk accounting (cause-specific/Fine-Gray complete cases + death with missing cause + missing size/grade): 1809 + 1 + 88 = 1898.
