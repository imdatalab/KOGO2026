# STAGE 1-4: Fine-Gray subdistribution hazard model for breast-cancer death
# (competing event: other-cause death). Same covariates and exclusions as the cause-specific Cox model.
suppressPackageStartupMessages(library(survival))
args <- commandArgs(trailingOnly = FALSE)
root <- normalizePath(file.path(dirname(sub("--file=", "", args[grep("--file=", args)])), ".."))
setwd(root)
d <- read.csv("data/METABRIC_RNA_Mutation.csv", check.names = FALSE)
names(d)[names(d) == "pam50_+_claudin-low_subtype"] <- "pam50"
d <- d[d$pam50 != "NC" & d$death_from_cancer != "" & !is.na(d$death_from_cancer), ]
d$cause <- factor(ifelse(d$death_from_cancer == "Living", "censor",
                  ifelse(d$death_from_cancer == "Died of Disease", "bc", "other")),
                  levels = c("censor", "bc", "other"))
d$time <- d$overall_survival_months
d$age_10y <- d$age_at_diagnosis / 10
d$size_10mm <- d$tumor_size / 10
d$nodes_pos <- d$lymph_nodes_examined_positive
d$grade <- factor(d$neoplasm_histologic_grade, levels = c(1, 2, 3))
d$ER_pos <- as.integer(d$er_status == "Positive")
d$HER2_pos <- as.integer(d$her2_status == "Positive")
d$pam50 <- relevel(factor(d$pam50), ref = "LumA")
vars <- c("time", "cause", "age_10y", "size_10mm", "nodes_pos", "grade", "ER_pos", "HER2_pos",
          "chemotherapy", "hormone_therapy", "radio_therapy", "pam50")
cc <- d[complete.cases(d[, vars]), vars]
fg <- finegray(Surv(time, cause) ~ ., data = cc, etype = "bc")
fit <- coxph(Surv(fgstart, fgstop, fgstatus) ~ age_10y + size_10mm + nodes_pos + grade + ER_pos + HER2_pos +
               chemotherapy + hormone_therapy + radio_therapy + pam50, weights = fgwt, data = fg)
s <- summary(fit)
out <- data.frame(term = rownames(s$conf.int), sHR = s$conf.int[, 1], lo = s$conf.int[, 3],
                  hi = s$conf.int[, 4], p = s$coefficients[, "Pr(>|z|)"], n = nrow(cc),
                  bc_events = sum(cc$cause == "bc"), other_events = sum(cc$cause == "other"))
write.csv(out, "01_stats/finegray_bc_death.csv", row.names = FALSE)
cat(R.version.string, "survival", as.character(packageVersion("survival")), "\n")
print(round(out[, 2:5], 3)[1, ]); cat("n =", nrow(cc), "\n")
