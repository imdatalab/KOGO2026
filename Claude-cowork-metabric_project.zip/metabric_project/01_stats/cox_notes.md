# Cox model notes

Complete-case model: 1810 of 1898 patients (PAM50 'NC' n=6 excluded beforehand; 88 excluded for missing tumour size and/or grade). Deaths: 1037. Harrell's C = 0.675.

## Proportional hazards
Schoenfeld residual test (rank time transform) flagged: ER positive vs negative, Age (per 10 years), Hormone therapy (yes vs no), PAM50 Basal vs LumA, PAM50 LumB vs LumA.

Alternative 1 — stratified Cox: strata = ['ER_pos', 'age_10y_t3', 'hormone', 'pam50_code'] (continuous violators by tertile); HRs for non-violating covariates in `cox_alt1_stratified.csv`.
Alternative 2 — piecewise-constant (time-varying) coefficients with a split at 60 months; period-specific HRs in `cox_alt2_piecewise.csv`.

## Chemotherapy HR and confounding by indication
Chemotherapy was associated with HR 1.49 (95% CI 1.22–1.83; p=<0.001). Treatment was not randomised: in this cohort patients receiving chemotherapy were younger and had more nodes, more grade 3 and more ER-negative tumours (see `chemo_indication_profile.csv`). Residual confounding by indication (unmeasured disease extent, performance status, treatment era/centre) means this HR should be read as an association within a treated-by-indication population, not as an estimate of treatment effect. Strong negative confounding by age (younger, fitter patients selected for chemotherapy, with lower other-cause mortality) operates in the opposite direction, so the net direction of bias cannot be determined from these data.
