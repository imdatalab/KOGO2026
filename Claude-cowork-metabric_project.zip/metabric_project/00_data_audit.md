# STAGE 0. Data audit — METABRIC_RNA_Mutation.csv

Working copy: `data/METABRIC_RNA_Mutation.csv` (original upload untouched). Script: `scripts/s00_data_audit.py`.

**Dimensions:** 1904 rows × 693 columns (expected 1,904 — matched). All required variables present.

## 1. Variable blocks

| block                           |   n_vars | dtypes                                   |   cells_missing |
|:--------------------------------|---------:|:-----------------------------------------|----------------:|
| Clinical (cols 1-31)            |       31 | {'object': 17, 'float64': 9, 'int64': 5} |            1100 |
| mRNA z-score (cols 32-520)      |      489 | {'float64': 489}                         |               0 |
| Somatic mutation (cols 521-693) |      173 | {'object': 173}                          |               0 |

mRNA block: 0 missing cells; pooled mean -0.000, SD 1.000 (consistent with z-scores).

## 2. Clinical variables: type and missingness

| variable                       | dtype   |   n_unique |   n_missing |   pct_missing |
|:-------------------------------|:--------|-----------:|------------:|--------------:|
| patient_id                     | int64   |       1904 |           0 |           0   |
| age_at_diagnosis               | float64 |       1572 |           0 |           0   |
| type_of_breast_surgery         | object  |          2 |          22 |           1.2 |
| cancer_type                    | object  |          2 |           0 |           0   |
| cancer_type_detailed           | object  |          6 |          15 |           0.8 |
| cellularity                    | object  |          3 |          54 |           2.8 |
| chemotherapy                   | int64   |          2 |           0 |           0   |
| pam50_+_claudin-low_subtype    | object  |          7 |           0 |           0   |
| cohort                         | float64 |          5 |           0 |           0   |
| er_status_measured_by_ihc      | object  |          2 |          30 |           1.6 |
| er_status                      | object  |          2 |           0 |           0   |
| neoplasm_histologic_grade      | float64 |          3 |          72 |           3.8 |
| her2_status_measured_by_snp6   | object  |          4 |           0 |           0   |
| her2_status                    | object  |          2 |           0 |           0   |
| tumor_other_histologic_subtype | object  |          8 |          15 |           0.8 |
| hormone_therapy                | int64   |          2 |           0 |           0   |
| inferred_menopausal_state      | object  |          2 |           0 |           0   |
| integrative_cluster            | object  |         11 |           0 |           0   |
| primary_tumor_laterality       | object  |          2 |         106 |           5.6 |
| lymph_nodes_examined_positive  | float64 |         31 |           0 |           0   |
| mutation_count                 | float64 |         30 |          45 |           2.4 |
| nottingham_prognostic_index    | float64 |        310 |           0 |           0   |
| oncotree_code                  | object  |          6 |          15 |           0.8 |
| overall_survival_months        | float64 |       1685 |           0 |           0   |
| overall_survival               | int64   |          2 |           0 |           0   |
| pr_status                      | object  |          2 |           0 |           0   |
| radio_therapy                  | int64   |          2 |           0 |           0   |
| 3-gene_classifier_subtype      | object  |          4 |         204 |          10.7 |
| tumor_size                     | float64 |        111 |          20 |           1.1 |
| tumor_stage                    | float64 |          5 |         501 |          26.3 |
| death_from_cancer              | object  |          3 |           1 |           0.1 |

## 3. Event coding check: overall_survival × death_from_cancer

| overall_survival   |   Died of Disease |   Died of Other Causes |   Living |   Missing |   All |
|:-------------------|------------------:|-----------------------:|---------:|----------:|------:|
| 0                  |               622 |                    480 |        0 |         1 |  1103 |
| 1                  |                 0 |                      0 |      801 |         0 |   801 |
| All                |               622 |                    480 |      801 |         1 |  1904 |

- overall_survival==1 ↔ 'Living' in all 801 cases; overall_survival==0 ↔ died (disease or other) in 1102 cases, plus 1 death with missing cause. Inconsistent rows: 0.

- **Conclusion:** pre-specified coding (death = overall_survival == 0) is confirmed. Deaths = 1103, alive = 801.

## 4. Mutation columns: value format and binarization

- 173 columns, all stored as strings. Cells: '0' = 319653, missing = 0, non-'0' = 9739 (of which 728 contain more than one token).

- Non-'0' values are protein-change strings (e.g., most frequent shown below); rule applied: value != '0' → 1.

| value       |   count |
|:------------|--------:|
| H1047R      |     285 |
| E545K       |     127 |
| E542K       |      73 |
| E17K        |      63 |
| X308_splice |      59 |
| N345K       |      42 |
| K700E       |      36 |
| R175H       |      34 |
| V2061L      |      34 |
| H1047L      |      29 |

- Genes mutated in ≥3% of patients (eligible for ML): **46**. Top 10:

| gene_mut   |   n_mutated |   pct |
|:-----------|------------:|------:|
| pik3ca_mut |         795 | 41.75 |
| tp53_mut   |         659 | 34.61 |
| muc16_mut  |         326 | 17.12 |
| ahnak2_mut |         311 | 16.33 |
| kmt2c_mut  |         234 | 12.29 |
| syne1_mut  |         232 | 12.18 |
| gata3_mut  |         230 | 12.08 |
| map3k1_mut |         198 | 10.4  |
| ahnak_mut  |         176 |  9.24 |
| dnah11_mut |         175 |  9.19 |

Full table: `00_audit/mutation_frequency.csv`.

## 5. Leakage and derived variables

| Variable                                                                            | Content                                  | Handling                                                                     |
|:------------------------------------------------------------------------------------|:-----------------------------------------|:-----------------------------------------------------------------------------|
| overall_survival                                                                    | Outcome (1=alive, 0=dead)                | Outcome; excluded from predictors                                            |
| overall_survival_months                                                             | Follow-up time                           | Defines outcome/time; excluded from ML predictors (direct leakage)           |
| death_from_cancer                                                                   | Vital status + cause                     | Post-baseline outcome; excluded                                              |
| cohort                                                                              | Recruitment cohort/site (1-5)            | Not a patient attribute; excluded from ML, used for temporal/site validation |
| nottingham_prognostic_index                                                         | Derived: 0.2*size + nodal stage + grade  | Derived from size/nodes/grade; excluded (pre-specified)                      |
| tumor_stage                                                                         | Derived from tumor size + nodal status   | Collinear with size/nodes; retained (not in exclusion list), flagged         |
| integrative_cluster                                                                 | Derived from CNA + expression            | Molecular derived; retained in clinical block, flagged                       |
| 3-gene_classifier_subtype                                                           | Derived from ESR1/ERBB2/AURKA expression | Overlaps mRNA block; retained, flagged                                       |
| pam50_+_claudin-low_subtype                                                         | Derived from expression                  | Overlaps mRNA block; retained                                                |
| mutation_count                                                                      | Total mutation count                     | Correlates with binarized mutation total (Spearman 0.98); retained, flagged  |
| er_status / er_status_measured_by_ihc                                               | Two ER measures (IHC vs expression)      | Redundant pair; both retained, flagged                                       |
| her2_status / her2_status_measured_by_snp6                                          | Two HER2 measures                        | Redundant pair; both retained, flagged                                       |
| cancer_type / cancer_type_detailed / oncotree_code / tumor_other_histologic_subtype | Histology codes                          | Near-duplicate encodings; retained, flagged                                  |
| patient_id                                                                          | Identifier                               | Excluded                                                                     |

## 6. Competing risks

- Of 1103 deaths: breast-cancer death 622, other-cause death 480 (43.5% of deaths), cause missing 1.

- Median age at diagnosis by status: {'Died of Disease': 61.1, 'Died of Other Causes': 70.5, 'Living': 56.7, 'Missing': 58.6}. Other-cause death is substantial and concentrated in older patients, so 1−KM for cancer-specific death would be biased upward; cumulative incidence (Aalen–Johansen) is used in STAGE 1.

## 7. Follow-up and 5-year outcome feasibility

- Follow-up range 0.0–355.2 months. Within ≤60 months: deaths 412, censored alive 60 (to be excluded in STAGE 2); follow-up >60 months: 1432.

- Cohort sizes: {1.0: 481, 2.0: 286, 3.0: 734, 4.0: 236, 5.0: 167}.

- PAM50 + claudin-low: {'LumA': 679, 'LumB': 461, 'Her2': 220, 'claudin-low': 199, 'Basal': 199, 'Normal': 140, 'NC': 6}; 'NC' (n=6) excluded in subtype analyses per protocol.
