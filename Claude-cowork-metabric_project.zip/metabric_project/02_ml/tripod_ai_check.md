# TRIPOD+AI self-assessment — 5-year mortality models (M1–M4)

Checklist: TRIPOD+AI [REF: Collins GS et al., TRIPOD+AI statement, BMJ 2024]. Item labels are condensed paraphrases; check wording against the official checklist before submission.
Status reflects the analyses in `scripts/` and the manuscript draft in `03_manuscript/`.
Legend: **Met** / **Partial** / **Not met**.

| Item | Topic | Status | Where / gap |
|---|---|---|---|
| 1 | Title identifies development/evaluation of a prediction model, target population, outcome | Met | Manuscript title |
| 2 | Structured abstract per TRIPOD+AI for Abstracts | Partial | Abstract drafted; abstract-specific checklist not yet cross-checked |
| 3a | Healthcare context and rationale | Met | Introduction |
| 3b | Target population and intended use in the care pathway | Partial | Intended use stated as research/risk stratification; no defined clinical decision point |
| 3c | Known health inequalities across groups | Partial | Not discussed in depth; METABRIC lacks race/ethnicity and socioeconomic data |
| 4 | Objectives (development and evaluation) | Met | Introduction, last paragraph |
| 5a | Data source(s) | Met | Methods: public METABRIC (cBioPortal/Kaggle-derived file) |
| 5b | Dates of accrual, end of follow-up | Partial | Accrual dates not in the analysed file; [REF: original METABRIC description] |
| 6a | Setting, number and location of centres | Partial | Cohort 1–5 codes only; centre identity not in file |
| 6b | Eligibility criteria | Met | Methods + flow (`ml_random.cohort` in summary.json) |
| 6c | Treatments received | Met | Chemo/hormone/radiotherapy as predictors; Table 1 |
| 7 | Data preparation and quality checks | Met | `00_data_audit.md` |
| 8a | Outcome definition, time horizon, how assessed | Met | Death ≤60 months vs alive >60 months |
| 8b | Qualifications/demographics of outcome assessors (if subjective) | Not met | Not available in public data; outcome objective (death) |
| 8c | Blinding of outcome assessment | Not met | Not reported in source data |
| 9a | Choice of initial predictors and any pre-selection | Met | All clinical columns minus pre-specified exclusions; mutations ≥3% (training set) |
| 9b | Definition and timing of predictors | Partial | Defined per source; exact measurement timing (e.g., treatment decided post-diagnosis) not documented |
| 9c | Qualifications of predictor assessors | Not met | Not available |
| 10 | Sample size justification | Partial | EPV reported (`gate_stage2.md`): 5.1 (M1), 0.5 (M2/M3); no formal Riley-type calculation |
| 11 | Handling of missing data | Met | Training-set median/mode imputation inside pipeline |
| 12a | How data were used for development and evaluation | Met | Stratified 70:30 split; cohort-based split as sensitivity |
| 12b | Predictor handling (transformations, encoding) | Met | Standardisation, one-hot (drop-first), train-only fit |
| 12c | Model type, building, hyperparameter tuning, internal validation | Met | LASSO 5-fold CV (Cs=20, AUROC); XGBoost randomised search 25 iterations, 5-fold CV |
| 12d | Heterogeneity across clusters/centres | Partial | Cohort split only; no cluster-level random effects or per-cohort performance |
| 12e | Performance measures and model comparison | Met | AUROC (bootstrap CI), AUPRC, Brier, calibration slope/CITL, DCA, DeLong |
| 12f | Model updating/recalibration | Not met | Not performed |
| 12g | External validation: differences in definitions | Not met | No external dataset |
| 13 | Class imbalance handling | Met | No resampling; prevalence 22.4% retained so probabilities stay calibrated (stated in Methods) |
| 14 | Fairness approach | Partial | Subgroup AUROC by age, ER, menopause (`subgroup_auroc.csv`); no race/SES data |
| 15 | Model output (probability) and thresholds | Partial | Probabilities reported; no recommended threshold |
| 16 | Differences between development and evaluation data | Met | Random vs cohort split comparison (`random_vs_cohort_split.csv`) |
| 17 | Ethics approval | Partial | Public de-identified data; local IRB exemption statement needed [to complete] |
| 18a | Funding | Not met | To be completed by authors |
| 18b | Conflicts of interest | Not met | To be completed by authors |
| 18c | Protocol availability | Partial | Pre-specified decisions in project brief; not publicly registered |
| 18d | Registration | Not met | Not registered |
| 18e | Data availability | Met | Public dataset |
| 18f | Code availability | Partial | `scripts/` complete; repository/DOI not yet created |
| 19 | Patient and public involvement | Not met | None; to be stated |
| 20a | Participant flow, numbers with/without outcome | Met | Flow numbers in Results (1,904 → 1,898 → 1,838) |
| 20b | Characteristics of participants | Met | Table 1 |
| 20c | Comparison of development vs evaluation data | Partial | Event rates per split reported; full train/test characteristics table not produced |
| 21 | Participants and events in each analysis | Met | Table 3, `gate_stage2.md` |
| 22 | Full model specification / access | Partial | LASSO coefficients and fitted pipelines (`02_ml/models/*.joblib`); M1 coefficients not tabulated |
| 23a | Performance with CIs | Met | Table 3 |
| 23b | Performance heterogeneity across subgroups | Partial | Age, ER, menopause only |
| 24 | Model updating results | Not met | N/A (not performed) |
| 25 | Overall interpretation incl. fairness | Met | Discussion |
| 26 | Limitations (non-representative sample, overfitting) | Met | Discussion |
| 27a | Handling of poor-quality/unavailable inputs at deployment | Not met | Not addressed |
| 27b | User interaction / expertise required | Not met | Not addressed |
| 27c | Future research and generalisability | Met | Discussion |

**Summary (52 items incl. sub-items):** Met 24 / Partial 16 / Not met 12. Recount after manuscript finalisation.
Priority gaps before submission: 3c/14 (fairness), 10 (formal sample-size calculation), 12f/24 (recalibration), 18a–d (administrative), 27a–b (deployment).
