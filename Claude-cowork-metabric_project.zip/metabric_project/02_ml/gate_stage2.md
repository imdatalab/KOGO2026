# STAGE 2 validation gate

| Check | Result |
|---|---|
| M1 imputer medians == training medians | PASS |
| M1 imputer medians != full-data medians (at least one) | PASS |
| M1 scaler means == training (imputed) means | PASS |
| M1 one-hot categories == training categories | PASS |
| M2 scaler means == training (imputed) means | PASS |
| Mutation selection (≥3%) computed on training set | PASS |
| No patient overlap train/test | PASS |

## Events per variable (training set)

Training events: 288 (non-events 998).

| Model | Candidate parameters after encoding | EPV |
|---|---|---|
| M1 | 56 | 5.14 |
| M2 | 590 | 0.49 |
| M3 | 590 | 0.49 |
| M4 | 489 | 0.59 |

LASSO non-zero coefficients: M2 30, M4 25. EPV < 10 for all candidate sets; M1 is unpenalised and therefore most exposed to overfitting (see calibration slope).
