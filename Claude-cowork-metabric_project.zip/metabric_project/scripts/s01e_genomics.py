"""STAGE 1-5: genomic analyses — per-gene univariable Cox (mRNA), mutation frequency, TP53."""
import warnings
import numpy as np, pandas as pd
from scipy import stats
from lifelines import CoxPHFitter, KaplanMeierFitter
from lifelines.statistics import logrank_test
from statsmodels.stats.multitest import multipletests
from common import *
warnings.filterwarnings("ignore")

d, clin, mrna, mut = load()
n0 = len(d)
d = d[d.pam50 != "NC"].copy(); n_nc = n0 - len(d)

# ---- per-gene univariable Cox (HR per 1-SD of the z-score)
res = []
for g in mrna:
    z = d[[g, "time", "death"]].dropna()
    sd = z[g].std()
    z = z.assign(x=(z[g] - z[g].mean()) / sd)
    c = CoxPHFitter().fit(z[["x", "time", "death"]], "time", "death").summary.loc["x"]
    res.append({"gene": g, "n": len(z), "HR_per_SD": c["exp(coef)"], "lo": c["exp(coef) lower 95%"],
                "hi": c["exp(coef) upper 95%"], "p": c["p"]})
G = pd.DataFrame(res)
G["q_BH"] = multipletests(G.p, method="fdr_bh")[1]
G = G.sort_values("p").reset_index(drop=True)
G.to_csv("01_stats/gene_univariable_cox.csv", index=False)
nsig = int((G.q_BH < 0.05).sum()); n_up = int(((G.q_BH < 0.05) & (G.HR_per_SD > 1)).sum())

fig, ax = plt.subplots(figsize=(5.2, 4.2))
sig = G.q_BH < 0.05
ax.scatter(np.log2(G.HR_per_SD[~sig]), -np.log10(G.p[~sig]), s=8, c="#999999", alpha=.6, label="q ≥ 0.05")
ax.scatter(np.log2(G.HR_per_SD[sig & (G.HR_per_SD > 1)]), -np.log10(G.p[sig & (G.HR_per_SD > 1)]), s=10, c=OI[5],
           label=f"q < 0.05, HR > 1 (n={n_up})")
ax.scatter(np.log2(G.HR_per_SD[sig & (G.HR_per_SD < 1)]), -np.log10(G.p[sig & (G.HR_per_SD < 1)]), s=10, c=OI[0],
           label=f"q < 0.05, HR < 1 (n={nsig - n_up})")
for r in G.head(10).itertuples():
    ax.annotate(r.gene.upper(), (np.log2(r.HR_per_SD), -np.log10(r.p)), fontsize=6, xytext=(3, 2), textcoords="offset points")
ax.set_xlabel("log2 hazard ratio per 1 SD of mRNA z-score"); ax.set_ylabel("−log10 p")
ax.legend(frameon=False, fontsize=7); ax.set_title(f"Univariable Cox, {len(mrna)} genes (n={len(d)})", fontsize=9)
fig.tight_layout(); fig.savefig("01_stats/fig_volcano_genes.png", dpi=300); plt.close(fig)
G[["gene", "HR_per_SD", "p", "q_BH"]].assign(log2HR=np.log2(G.HR_per_SD)).to_csv("results/volcano_points.csv", index=False)

# ---- mutation frequency (top 10) in analysis population
mf = pd.DataFrame({"gene": [m.replace("_mut", "").upper() for m in mut], "col": mut,
                   "n_mut": d[mut].sum().values, "pct": (d[mut].mean() * 100).round(2).values})
mf = mf.sort_values("n_mut", ascending=False).reset_index(drop=True)
mf.head(10).to_csv("01_stats/mutation_top10.csv", index=False)

# ---- TP53 mutation KM
d["TP53"] = d["tp53_mut"]
fig, ax = plt.subplots(figsize=(5.2, 4.2))
km_rows = {}; TICKS = [0, 60, 120, 180, 240, 300]; curves = []
for v, lab, col in [(0, "TP53 wild-type", OI[0]), (1, "TP53 mutated", OI[5])]:
    s = d[d.TP53 == v]
    km = KaplanMeierFitter().fit(s.time, s.death)
    sf, ci = km.survival_function_, km.confidence_interval_
    ax.step(sf.index, sf.iloc[:, 0], where="post", color=col, label=f"{lab} (n={len(s)})")
    ax.fill_between(ci.index, ci.iloc[:, 0], ci.iloc[:, 1], step="post", color=col, alpha=.15, lw=0)
    km_rows[lab] = {"n": len(s), "events": int(s.death.sum()),
                    "S5y": round(float(km.survival_function_at_times(60).iloc[0]), 3),
                    "S10y": round(float(km.survival_function_at_times(120).iloc[0]), 3),
                    "median": round(float(km.median_survival_time_), 1),
                    "at_risk": [int((s.time >= t).sum()) for t in TICKS]}
    curves.append(pd.DataFrame({"group": lab, "time": sf.index, "S": sf.iloc[:, 0].values,
                                "lo": ci.iloc[:, 0].values, "hi": ci.iloc[:, 1].values}))
lr = logrank_test(d.time[d.TP53 == 1], d.time[d.TP53 == 0], d.death[d.TP53 == 1], d.death[d.TP53 == 0])
ax.set_xlim(0, 300); ax.set_ylim(0, 1.02); ax.set_xticks(TICKS)
ax.set_xlabel("Time since diagnosis (months)"); ax.set_ylabel("Overall survival probability")
ax.legend(frameon=False, fontsize=8, loc="lower left")
ax.text(295, .95, f"Log-rank p{'<0.001' if lr.p_value < .001 else '=' + format(lr.p_value, '.3f')}", ha="right", fontsize=8)
for i, (lab, r) in enumerate(km_rows.items()):
    for t, nr in zip(TICKS, r["at_risk"]):
        ax.text(t, -0.20 - 0.06 * i, str(nr), ha="center", fontsize=7, transform=ax.get_xaxis_transform())
    ax.text(-0.02, -0.20 - 0.06 * i, lab.split()[1], ha="right", fontsize=7, transform=ax.transAxes)
fig.subplots_adjust(bottom=0.30, left=0.16); fig.savefig("01_stats/fig_km_tp53.png", dpi=300); plt.close(fig)
pd.concat(curves).to_csv("results/km_tp53_curves.csv", index=False)

# ---- TP53 rate by PAM50
tab = pd.crosstab(d.pam50, d.TP53).reindex(PAM_ORDER)
chi = stats.chi2_contingency(tab.values)
rate = pd.DataFrame({"pam50": PAM_ORDER, "n": tab.sum(1).values, "TP53_mut": tab[1].values,
                     "pct": (tab[1] / tab.sum(1) * 100).round(1).values})
rate.to_csv("01_stats/tp53_by_pam50.csv", index=False)

# ---- TP53 HR before/after subtype adjustment
def cox(df, cols, strata=None):
    c = CoxPHFitter().fit(df[["time", "death"] + cols + ([strata] if strata else [])], "time", "death",
                          strata=[strata] if strata else None).summary.loc["TP53"]
    return {"HR": c["exp(coef)"], "lo": c["exp(coef) lower 95%"], "hi": c["exp(coef) upper 95%"], "p": c["p"]}
Z = d[["time", "death", "TP53", "age_at_diagnosis", "pam50"]].copy()
for k in PAM_ORDER[1:]:
    Z[f"pam50_{k}"] = (Z.pam50 == k).astype(float)
Z["age_10y"] = Z.age_at_diagnosis / 10
Z["pam_code"] = Z.pam50.astype("category").cat.codes
dm = [f"pam50_{k}" for k in PAM_ORDER[1:]]
tp = pd.DataFrame([{"model": "Crude", **cox(Z, ["TP53"])},
                   {"model": "Adjusted for PAM50 (covariate)", **cox(Z, ["TP53"] + dm)},
                   {"model": "Stratified by PAM50", **cox(Z, ["TP53"], strata="pam_code")},
                   {"model": "Adjusted for PAM50 + age", **cox(Z, ["TP53", "age_10y"] + dm)}])
tp["n"] = len(Z); tp["events"] = int(Z.death.sum())
tp.to_csv("01_stats/tp53_hr_adjustment.csv", index=False)

supdate("genomics", {"n": len(d), "n_genes": len(mrna), "n_q05": nsig, "n_q05_HRgt1": n_up, "n_q05_HRlt1": nsig - n_up,
                     "top10_genes": G.head(10)[["gene", "HR_per_SD", "lo", "hi", "p", "q_BH"]].round(5).to_dict("records"),
                     "mut_top10": mf.head(10)[["gene", "n_mut", "pct"]].to_dict("records"),
                     "tp53_km": km_rows, "tp53_logrank_p": lr.p_value, "tp53_logrank_chi2": round(lr.test_statistic, 2),
                     "tp53_by_pam50": rate.to_dict("records"), "tp53_pam50_chi2": round(chi.statistic, 1),
                     "tp53_pam50_df": int(chi.dof), "tp53_pam50_p": chi.pvalue,
                     "tp53_hr": tp.round(4).to_dict("records")})
print("genes q<0.05:", nsig, "(HR>1:", n_up, ")")
print(G.head(10)[["gene", "HR_per_SD", "lo", "hi", "q_BH"]].round(4).to_string(index=False))
print(rate.to_string(index=False)); print(tp.round(3).to_string(index=False))
