"""STAGE 1-4: competing risks — breast-cancer death vs other-cause death."""
import numpy as np, pandas as pd
from lifelines import AalenJohansenFitter, KaplanMeierFitter, CoxPHFitter
from common import *

d, *_ = load()
n0 = len(d)
d = d[d.pam50 != "NC"].copy(); n_nc = n0 - len(d)
n_cause_missing = int(d.death_from_cancer.isna().sum())
d = d[d.death_from_cancer.notna()].copy()
d["cause"] = d.death_from_cancer.map({"Living": 0, "Died of Disease": 1, "Died of Other Causes": 2}).astype(int)

T = 120; SUBS = ["LumA", "Her2", "Basal"]
rows, curves = [], []
fig, axes = plt.subplots(1, 3, figsize=(9, 3.2), sharey=True)
for ax, k in zip(axes, SUBS):
    s = d[d.pam50 == k]
    aj = AalenJohansenFitter(calculate_variance=True, seed=SEED).fit(s.time, s.cause, event_of_interest=1)
    km = KaplanMeierFitter().fit(s.time, (s.cause == 1).astype(int))
    cif = aj.cumulative_density_; ci = aj.confidence_interval_
    idx = cif.index[cif.index <= T].max()
    cif_t = float(cif.loc[idx].iloc[0]); lo, hi = [float(x) for x in ci.loc[idx].values]
    omk = 1 - float(km.survival_function_at_times(T).iloc[0])
    kci = km.confidence_interval_; kidx = kci.index[kci.index <= T].max()
    omk_lo, omk_hi = 1 - float(kci.loc[kidx].iloc[1]), 1 - float(kci.loc[kidx].iloc[0])
    aj2 = AalenJohansenFitter(seed=SEED).fit(s.time, s.cause, event_of_interest=2)
    oth = aj2.cumulative_density_; oth_t = float(oth.loc[oth.index[oth.index <= T].max()].iloc[0])
    rows.append({"pam50": k, "n": len(s), "bc_deaths": int((s.cause == 1).sum()), "other_deaths": int((s.cause == 2).sum()),
                 "CIF_bc_120": round(cif_t, 3), "CIF_lo": round(lo, 3), "CIF_hi": round(hi, 3),
                 "oneminusKM_bc_120": round(omk, 3), "oneminusKM_lo": round(omk_lo, 3), "oneminusKM_hi": round(omk_hi, 3),
                 "abs_overestimate": round(omk - cif_t, 3), "rel_overestimate_pct": round((omk / cif_t - 1) * 100, 1),
                 "CIF_other_120": round(oth_t, 3)})
    ax.step(cif.index, cif.iloc[:, 0], where="post", color=PAM_COL[k], lw=1.4, label="CIF (Aalen–Johansen)")
    ax.fill_between(ci.index, ci.iloc[:, 0], ci.iloc[:, 1], step="post", color=PAM_COL[k], alpha=0.15, lw=0)
    sf = km.survival_function_
    ax.step(sf.index, 1 - sf.iloc[:, 0], where="post", color="black", lw=1.0, ls="--", label="1 − KM")
    ax.axvline(T, color="grey", lw=0.6, ls=":")
    ax.set_title(f"{k} (n={len(s)})", fontsize=9); ax.set_xlim(0, 300); ax.set_xticks([0, 60, 120, 180, 240, 300])
    ax.set_xlabel("Time since diagnosis (months)")
    curves.append(pd.DataFrame({"pam50": k, "time": cif.index, "CIF": cif.iloc[:, 0].values,
                                "lo": ci.iloc[:, 0].values, "hi": ci.iloc[:, 1].values}))
    curves.append(pd.DataFrame({"pam50": k + "_1mKM", "time": sf.index, "CIF": 1 - sf.iloc[:, 0].values,
                                "lo": np.nan, "hi": np.nan}))
axes[0].set_ylabel("Cumulative incidence of\nbreast-cancer death"); axes[0].legend(frameon=False, fontsize=7, loc="upper left")
fig.tight_layout(); fig.savefig("01_stats/figS_cif_vs_1mKM.png", dpi=300); plt.close(fig)
cr = pd.DataFrame(rows); cr.to_csv("01_stats/competing_cif_vs_km_120m.csv", index=False)
pd.concat(curves).to_csv("results/cif_curves.csv", index=False)

# cause-specific Cox (same covariates as main model; complete cases)
X = pd.DataFrame({"time": d.time, "cause": d.cause, "age_10y": d.age_at_diagnosis / 10, "size_10mm": d.tumor_size / 10,
                  "nodes_pos": d.lymph_nodes_examined_positive,
                  "grade_2": (d.neoplasm_histologic_grade == 2).astype(float),
                  "grade_3": (d.neoplasm_histologic_grade == 3).astype(float),
                  "ER_pos": (d.er_status == "Positive").astype(float), "HER2_pos": (d.her2_status == "Positive").astype(float),
                  "chemo": d.chemotherapy.astype(float), "hormone": d.hormone_therapy.astype(float),
                  "radio": d.radio_therapy.astype(float)})
for k in PAM_ORDER[1:]:
    X[f"pam50_{k}"] = (d.pam50 == k).astype(float)
X.loc[d.neoplasm_histologic_grade.isna(), ["grade_2", "grade_3"]] = np.nan
X = X.dropna()
covs = [c for c in X.columns if c not in ("time", "cause")]
out = []
for ev, nm in [(1, "Breast-cancer death"), (2, "Other-cause death")]:
    Z = X.assign(ev=(X.cause == ev).astype(int))
    c = CoxPHFitter().fit(Z[["time", "ev"] + covs], "time", "ev").summary
    for t in covs:
        out.append({"outcome": nm, "term": t, "HR": c.loc[t, "exp(coef)"], "lo": c.loc[t, "exp(coef) lower 95%"],
                    "hi": c.loc[t, "exp(coef) upper 95%"], "p": c.loc[t, "p"], "events": int(Z.ev.sum())})
cs = pd.DataFrame(out); cs.to_csv("01_stats/cause_specific_cox.csv", index=False)
age = cs[cs.term == "age_10y"].round(4).to_dict("records")
supdate("competing", {"n_excl_NC": n_nc, "n_excl_cause_missing": n_cause_missing, "n_analysed_cif": int(d.pam50.isin(SUBS).sum()),
                      "n_cause_specific": len(X), "cif_vs_km": rows, "age_HR_cause_specific": age})
print(cr[["pam50", "n", "bc_deaths", "other_deaths", "CIF_bc_120", "oneminusKM_bc_120", "rel_overestimate_pct"]].to_string(index=False))
print(cs[cs.term == "age_10y"][["outcome", "HR", "lo", "hi", "p", "events"]].round(3).to_string(index=False), "n", len(X))
