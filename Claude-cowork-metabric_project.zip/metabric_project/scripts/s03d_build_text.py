"""STAGE 3: fill text templates from results/summary.json + results/versions.json and build number_trace.csv.
Every number in the output text must come from a {{key|fmt}} token or a registered design constant;
any other number is reported as UNTRACED and the build fails."""
import json, re, sys
import pandas as pd
from common import *

S = sload(); S["versions"] = json.load(open("results/versions.json"))
PRODUCER = {"stage0": "scripts/s00_data_audit.py", "table1": "scripts/s01a_table1.py", "km": "scripts/s01b_km.py",
            "cox": "scripts/s01c_cox.py", "competing": "scripts/s01d_competing.py", "finegray": "scripts/s01d_finegray.R",
            "genomics": "scripts/s01e_genomics.py", "ml_random": "scripts/s02a_ml_random.py",
            "ml_cohort": "scripts/s02b_ml_cohort.py", "reviewer": "scripts/s03b_reviewer_analyses.py",
            "versions": "scripts/s03a_versions.py", "sub": "scripts/s02a_ml_random.py", "gate_stage1": "scripts/s01f_gate.py"}
IDKEYS = ["pam50", "model", "outcome", "gene_mut", "gene", "covariate", "chemotherapy", "group", "subgroup", "term"]


def keyed(o):
    if isinstance(o, dict):
        return {str(k): keyed(v) for k, v in o.items()}
    if isinstance(o, list):
        if o and all(isinstance(x, dict) for x in o):
            for k in IDKEYS:
                if all(k in x for x in o) and len({str(x[k]) for x in o}) == len(o):
                    return {str(x[k]): keyed(x) for x in o}
        return {str(i): keyed(x) for i, x in enumerate(o)}
    return o


K = keyed(S)
_sg = pd.read_csv("02_ml/subgroup_auroc.csv")
K["sub"] = {g: {m: r.to_dict() for m, r in x.set_index("model").iterrows()} for g, x in _sg.groupby("subgroup")}


def get(path):
    parts, node, i = path.split("."), K, 0
    while i < len(parts):  # allow keys that themselves contain dots (e.g. 'diff_p2.5')
        for j in range(len(parts), i, -1):
            cand = ".".join(parts[i:j])
            if isinstance(node, dict) and cand in node:
                node = node[cand]; i = j; break
        else:
            raise KeyError(path)
    return node


def fmt(v, f):
    v = float(v) if f not in ("s",) else v
    if f == "P":
        return "p < 0.001" if v < 0.001 else f"p = {v:.3f}"
    if f == "pct":
        return f"{v * 100:.1f}"
    if f in ("d", ",d"):
        return format(int(round(v)), f)
    if f == "s":
        return str(v)
    return format(v, f)


# design constants: (regex, description, source file, location)
CONST = [
    (r"diagnosis \(1\) versus survival beyond 60 months \(0\)", "outcome coding", "scripts/ml_common.py", "y = (time <= HORIZON) & death"),
    (r"\b5-year\b|\b5 years\b", "prediction horizon 60 months", "scripts/ml_common.py", "HORIZON = 60"),
    (r"\b60 months\b", "prediction horizon", "scripts/ml_common.py", "HORIZON = 60"),
    (r"\b120 months\b", "competing-risk comparison time", "scripts/s01d_competing.py", "T = 120"),
    (r"\b0–300 months\b", "KM display window", "scripts/s01b_km.py", "TICKS / set_xlim(0, 300)"),
    (r"\b70:30\b|\(70%\)|\(30%\)", "split ratio", "scripts/s02a_ml_random.py", "test_size=0.30"),
    (r"\b5-fold\b", "cross-validation folds", "scripts/ml_common.py", "StratifiedKFold(5)"),
    (r"\b20 values\b", "LASSO penalty grid", "scripts/ml_common.py", "Cs=20"),
    (r"\b25 iterations\b", "XGBoost random search", "scripts/ml_common.py", "n_iter=25"),
    (r"\b1,000 bootstrap\b", "bootstrap resamples", "scripts/ml_common.py", "boot_auc n=1000"),
    (r"\b9,999 resamples\b", "permutation resamples", "scripts/s01a_table1.py", "n_resamples=9999"),
    (r"\b20% of expected counts were below 5\b", "sparse-table rule", "scripts/s01a_table1.py", "(exp < 5).mean() > 0.20"),
    (r"\bp<0\.05\b|\bp < 0\.05\b", "normality / PH threshold", "scripts/s01a_table1.py; scripts/s01c_cox.py", "0.05"),
    (r"\bq<0\.05\b", "FDR threshold", "scripts/s01e_genomics.py", "q_BH < 0.05"),
    (r"\b3%", "mutation frequency threshold", "scripts/ml_common.py", "select_mut thr=0.03"),
    (r"\b(per )?10 years\b", "age scaling", "scripts/s01c_cox.py", "age_at_diagnosis / 10"),
    (r"\b10 mm\b", "size scaling", "scripts/s01c_cox.py", "tumor_size / 10"),
    (r"\b1 SD\b", "gene scaling", "scripts/s01e_genomics.py", "(z - mean)/sd"),
    (r"\b0\.01–0\.60\b", "DCA thresholds", "scripts/s02a_ml_random.py", "np.arange(0.01, 0.61, 0.01)"),
    (r"\b20 features\b|\b20 highest-ranked\b", "SHAP top-20", "scripts/s02a_ml_random.py", "max_display=20"),
    (r"\btop three\b", "dependence plots", "scripts/s02a_ml_random.py", "top3"),
    (r"\b<60 vs ≥60 years\b", "age subgroup cut", "scripts/s02a_ml_random.py", "age_at_diagnosis < 60"),
    (r"\bcohorts? 1–3\b|\bcohorts? 4–5\b|\bcohort 1\b", "cohort split", "scripts/s02b_ml_cohort.py", "cohort.isin([1,2,3])"),
    (r"\bseeds 42 to 91\b", "repeated-split seeds", "scripts/s03b_reviewer_analyses.py", "random_state=SEED + b, b in range(50)"),
    (r"\b50 repeated\b", "repeated splits", "scripts/s03b_reviewer_analyses.py", "range(50)"),
    (r"overall_survival = 0", "event coding", "scripts/common.py", "death = (overall_survival == 0)"),
    (r'coded 1 if its value was not "0" and 0 otherwise', "mutation binarisation", "scripts/common.py", 'd[mut].astype(str) != "0"'),
    (r"\bgrade [123]\b", "grade category level", "scripts/s01c_cox.py", "grade_2/grade_3 vs grade 1"),
    (r"random_state = 42|seed 42", "random seed", "scripts/common.py", "SEED = 42"),
    (r"\bSix sensitivity\b|\(i+v?\)|\(iv\)|\(v\)|\(vi\)", "enumeration", "-", "-"),
    (r"\bThree findings\b|\bFirst\b|\bSecond\b|\bThird\b", "wording", "-", "-"),
]
ALLOW = [r"Reviewer 2", r"\*\*(Major|Minor) \d\.", r"`[^`]*`", r'other than "0"', r"\b00_data_audit\.md\b", r"\[(STROBE|TRIPOD\+AI)[^\]]*\]", r"\[REF:[^\]]*\]", r"95% (CI|CIs|confidence)", r"Figure \d[A-F]?", r"Figures? \d",
         r"Table \d", r"Tables \d–\d", r"\bM[1-4]b?\b", r"M1–M[34]", r"M3–M1", r"\b1 − KM\b|one minus", r"\b[A-Za-z]+\d+[A-Za-z0-9]*\b",
         r"\b\d-gene\b", r"χ²", r"\bdf\b", r"Fine–Gray", r"\bL1\b", r"S\d\b", r"2\.5th–97\.5th", r"log2", r"<60|≥60", r"HR ?[<>] ?1\b"]
NUM = re.compile(r"(?<![A-Za-z])[-−]?\d[\d,]*(\.\d+)?")
TOK = re.compile(r"\{\{([^|}]+)\|([^}]*)\}\}")


def build(template, out, doc, trace, untraced):
    txt = open(template).read()
    marks = []

    def rep(m):
        val = fmt(get(m.group(1)), m.group(2))
        marks.append((m.group(1), val))
        return f"⟦{len(marks) - 1}⟧"
    filled = TOK.sub(rep, txt)
    final_lines = []
    for line in filled.split("\n"):
        for sent in re.split(r"(?<=[.])\s+(?=[A-Z(\[])", line):
            plain = re.sub(r"⟦(\d+)⟧", lambda m: marks[int(m.group(1))][1], sent)
            for i in map(int, re.findall(r"⟦(\d+)⟧", sent)):
                key, val = marks[i]
                trace.append({"document": doc, "sentence": plain.strip()[:300], "number": val, "source_file": "02_ml/subgroup_auroc.csv" if key.startswith("sub.") else "results/summary.json",
                              "row_col": key, "produced_by": PRODUCER.get(key.split(".")[0], "")})
            # check for untraced numbers
            masked = re.sub(r"⟦\d+⟧", " ", sent)
            for pat, desc, src, loc in CONST:
                for m in re.finditer(pat, masked):
                    if src != "-":
                        trace.append({"document": doc, "sentence": plain.strip()[:300], "number": m.group(0), "source_file": src,
                                      "row_col": loc, "produced_by": f"design constant: {desc}"})
                masked = re.sub(pat, " ", masked)
            for pat in ALLOW:
                masked = re.sub(pat, " ", masked)
            for m in NUM.finditer(masked):
                untraced.append({"document": doc, "number": m.group(0), "sentence": plain.strip()[:200]})
        final_lines.append(re.sub(r"⟦(\d+)⟧", lambda m: marks[int(m.group(1))][1], line))
    open(out, "w").write("\n".join(final_lines))


trace, untraced = [], []
for t, o, doc in [("03_manuscript/templates/manuscript_template.md", "03_manuscript/manuscript.md", "manuscript"),
                  ("03_manuscript/templates/figure_legends_template.md", "03_manuscript/figure_legends.md", "figure_legends"),
                  ("03_manuscript/templates/cover_letter_template.md", "03_manuscript/cover_letter.md", "cover_letter"),
                  ("03_manuscript/templates/reviewer_response_template.md", "03_manuscript/reviewer2_response.md", "reviewer_response")]:
    if os.path.exists(t):
        build(t, o, doc, trace, untraced)
pd.DataFrame(trace).to_csv("03_manuscript/number_trace.csv", index=False)
pd.DataFrame(untraced).to_csv("results/untraced_numbers.csv", index=False)
print("traced numbers:", len(trace), "| untraced:", len(untraced))
if untraced:
    print(pd.DataFrame(untraced).head(15).to_string(index=False)); sys.exit(1)
