"""STAGE 3-5: additional analyses requested in the simulated Reviewer 2 report."""
import warnings, joblib
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from sklearn.base import clone
from sklearn.linear_model import LogisticRegressionCV
from lifelines import KaplanMeierFitter, CoxPHFitter
from statsmodels.stats.multitest import multipletests
from ml_common import *
warnings.filterwarnings("ignore")
OUT = "03_manuscript/reviewer_analyses"
import os; os.makedirs(OUT, exist_ok=True)

d, excl, clin_pred, mrna, mut, info = build_ml_cohort()
tr, te = train_test_split(d, test_size=0.30, stratify=d.y, random_state=SEED)   # identical split to s02a
mut_sel = select_mut(tr, mut); full = clin_pred + mrna + mut_sel
M = {k: joblib.load(f"02_ml/models/{k}_random.joblib") for k in ["M1", "M2", "M3", "M4"]}
cols = {"M1": clin_pred, "M2": full, "M3": full, "M4": mrna}
pred = {k: M[k].predict_proba(te[cols[k]])[:, 1] for k in M}
yte = te.y.values
R = {}

def wboot(y, p, w, n=1000):
    rng = np.random.default_rng(SEED); o = []
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if y[i].min() == y[i].max(): continue
        o.append(roc_auc_score(y[i], p[i], sample_weight=w[i]))
    return np.percentile(o, [2.5, 97.5])

# ---- R1: IPCW-weighted AUROC accounting for excluded early-censored patients
allp = pd.concat([d, excl])
G = KaplanMeierFitter().fit(allp.time, 1 - allp.death)        # censoring distribution
def Gm(t):  # G(t-) approximated by G at t minus a small epsilon
    return float(G.survival_function_at_times(np.maximum(np.asarray(t) - 1e-6, 0)).values[0]) if np.ndim(t) == 0 else \
        G.survival_function_at_times(np.maximum(np.asarray(t) - 1e-6, 0)).values
w = np.where(yte == 1, 1 / Gm(te.time.values), 1 / Gm(HORIZON))
r1 = []
for k, p in pred.items():
    lo, hi = wboot(yte, p, w)
    r1.append({"model": k, "AUROC_unweighted": roc_auc_score(yte, p), "AUROC_IPCW": roc_auc_score(yte, p, sample_weight=w),
               "IPCW_lo": lo, "IPCW_hi": hi})
r1 = pd.DataFrame(r1).round(4); r1.to_csv(f"{OUT}/R1_ipcw_auroc.csv", index=False)
R["R1"] = {"weights_range": [round(float(w.min()), 3), round(float(w.max()), 3)], "table": r1.to_dict("records"),
           "G60": round(float(Gm(HORIZON)), 4)}

# ---- R2: repeated stratified splits (50x), M1 refit, M3 refit with fixed tuned hyper-parameters
rows = []
for b in range(50):
    a, c = train_test_split(d, test_size=0.30, stratify=d.y, random_state=SEED + b)
    ms = select_mut(a, mut); fl = clin_pred + ms
    m1 = Pipeline([("pre", make_preprocessor(a, clin_pred)), ("clf", LogisticRegression(C=np.inf, max_iter=5000))])
    m3 = Pipeline([("pre", make_preprocessor(a, fl, scale=False)), ("clf", clone(M["M3"].named_steps["clf"]))])
    m1.fit(a[clin_pred], a.y); m3.fit(a[fl], a.y)
    a1 = roc_auc_score(c.y, m1.predict_proba(c[clin_pred])[:, 1]); a3 = roc_auc_score(c.y, m3.predict_proba(c[fl])[:, 1])
    rows.append({"rep": b, "AUROC_M1": a1, "AUROC_M3": a3, "diff": a3 - a1})
r2 = pd.DataFrame(rows); r2.round(4).to_csv(f"{OUT}/R2_repeated_splits.csv", index=False)
R["R2"] = {"n_rep": 50, **{f"{c}_mean": round(r2[c].mean(), 4) for c in ["AUROC_M1", "AUROC_M3", "diff"]},
           **{f"{c}_p2.5": round(r2[c].quantile(.025), 4) for c in ["AUROC_M1", "AUROC_M3", "diff"]},
           **{f"{c}_p97.5": round(r2[c].quantile(.975), 4) for c in ["AUROC_M1", "AUROC_M3", "diff"]},
           "pct_M3_gt_M1": round(float((r2["diff"] > 0).mean() * 100), 1)}

# ---- R3: reduced clinical model (routinely available baseline variables; no treatment, no expression-derived labels)
red = ["age_at_diagnosis", "tumor_size", "lymph_nodes_examined_positive", "neoplasm_histologic_grade", "er_status",
       "pr_status", "her2_status", "inferred_menopausal_state"]
m1b = Pipeline([("pre", make_preprocessor(tr, red)), ("clf", LogisticRegression(C=np.inf, max_iter=5000))]).fit(tr[red], tr.y)
p1b = m1b.predict_proba(te[red])[:, 1]
lo, hi = boot_auc(yte, p1b); sl, it = calib_slope_intercept(yte, p1b)
dd, dci, dp = delong(yte, pred["M1"], p1b); dd3, dci3, dp3 = delong(yte, pred["M3"], p1b)
R["R3"] = {"vars": red, "AUROC": round(roc_auc_score(yte, p1b), 4), "lo": round(lo, 4), "hi": round(hi, 4),
           "calib_slope": round(sl, 3), "M1_minus_M1b": [round(dd, 4), round(dci[0], 4), round(dci[1], 4), dp],
           "M3_minus_M1b": [round(dd3, 4), round(dci3[0], 4), round(dci3[1], 4), dp3]}

# ---- R4: breast-cancer-specific 5-year death (test set)
bc = ((te.time <= HORIZON) & (te.death_from_cancer == "Died of Disease")).astype(int).values
oth = ((te.time <= HORIZON) & (te.death_from_cancer == "Died of Other Causes")).values
r4 = []
for k, p in pred.items():
    lo1, hi1 = boot_auc(bc, p)
    keep = ~oth
    lo2, hi2 = boot_auc(bc[keep], p[keep])
    r4.append({"model": k, "AUROC_bc_vs_all": roc_auc_score(bc, p), "lo": lo1, "hi": hi1,
               "AUROC_bc_excl_other": roc_auc_score(bc[keep], p[keep]), "lo2": lo2, "hi2": hi2})
r4 = pd.DataFrame(r4).round(4); r4.to_csv(f"{OUT}/R4_bc_specific_auroc.csv", index=False)
R["R4"] = {"n_test": len(te), "bc_deaths_le60": int(bc.sum()), "other_deaths_le60": int(oth.sum()), "table": r4.to_dict("records")}

# ---- R5: gene-level Cox adjusted for clinical covariates and PAM50
dd_, *_ = load(); dd_ = dd_[dd_.pam50 != "NC"]
X = pd.DataFrame({"time": dd_.time, "death": dd_.death, "age_10y": dd_.age_at_diagnosis / 10, "size_10mm": dd_.tumor_size / 10,
                  "nodes_pos": dd_.lymph_nodes_examined_positive,
                  "grade_2": (dd_.neoplasm_histologic_grade == 2).astype(float), "grade_3": (dd_.neoplasm_histologic_grade == 3).astype(float),
                  "ER_pos": (dd_.er_status == "Positive").astype(float), "HER2_pos": (dd_.her2_status == "Positive").astype(float)})
for k in PAM_ORDER[1:]:
    X[f"pam50_{k}"] = (dd_.pam50 == k).astype(float)
X.loc[dd_.neoplasm_histologic_grade.isna(), ["grade_2", "grade_3"]] = np.nan
X = X.join(dd_[mrna]).dropna(subset=list(X.columns[:9]) + [f"pam50_{k}" for k in PAM_ORDER[1:]])
base = [c for c in X.columns if c not in mrna]
out = []
for g in mrna:
    Z = X[base + [g]].copy(); Z[g] = (Z[g] - Z[g].mean()) / Z[g].std()
    c = CoxPHFitter().fit(Z, "time", "death").summary.loc[g]
    out.append({"gene": g, "HR_adj": c["exp(coef)"], "lo": c["exp(coef) lower 95%"], "hi": c["exp(coef) upper 95%"], "p": c["p"]})
r5 = pd.DataFrame(out); r5["q_BH"] = multipletests(r5.p, method="fdr_bh")[1]
un = pd.read_csv("01_stats/gene_univariable_cox.csv")[["gene", "q_BH"]].rename(columns={"q_BH": "q_unadj"})
r5 = r5.merge(un, on="gene").sort_values("p"); r5.round(5).to_csv(f"{OUT}/R5_gene_cox_adjusted.csv", index=False)
R["R5"] = {"n": len(X), "events": int(X.death.sum()), "n_q05_adj": int((r5.q_BH < .05).sum()),
           "n_q05_both": int(((r5.q_BH < .05) & (r5.q_unadj < .05)).sum()),
           "top5": r5.head(5)[["gene", "HR_adj", "lo", "hi", "q_BH"]].round(4).to_dict("records")}

# ---- m2: ridge-penalised clinical model (calibration slope of unpenalised M1 < 1)
cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
m1r = Pipeline([("pre", make_preprocessor(tr, clin_pred)),
                ("clf", LogisticRegressionCV(Cs=20, cv=cv, l1_ratios=[0.0], scoring="neg_log_loss", max_iter=5000,
                                             random_state=SEED))]).fit(tr[clin_pred], tr.y)
p1r = m1r.predict_proba(te[clin_pred])[:, 1]
lo, hi = boot_auc(yte, p1r); sl, it = calib_slope_intercept(yte, p1r)
R["m2_ridge_M1"] = {"AUROC": round(roc_auc_score(yte, p1r), 4), "lo": round(lo, 4), "hi": round(hi, 4),
                    "calib_slope": round(sl, 3), "calib_intercept": round(it, 3)}
supdate("reviewer", R)
print(r1.to_string(index=False)); print({k: v for k, v in R["R2"].items()}); print(R["R3"]); print(r4.to_string(index=False))
print({k: R["R5"][k] for k in ["n", "events", "n_q05_adj", "n_q05_both"]}); print(R["m2_ridge_M1"])
