"""STAGE 0: data audit for METABRIC_RNA_Mutation.csv (working copy in data/)."""
import json, os
import numpy as np, pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
OUT = "00_audit"
os.makedirs(OUT, exist_ok=True); os.makedirs("results", exist_ok=True)

d = pd.read_csv("data/METABRIC_RNA_Mutation.csv", low_memory=False)
n, p = d.shape
cols = list(d.columns)
clin, mrna, mut = cols[:31], cols[31:520], cols[520:]
assert n == 1904, f"N={n} != 1904"
required = ["overall_survival", "overall_survival_months", "death_from_cancer",
            "pam50_+_claudin-low_subtype", "age_at_diagnosis", "tumor_size",
            "lymph_nodes_examined_positive", "neoplasm_histologic_grade", "er_status",
            "her2_status", "chemotherapy", "hormone_therapy", "radio_therapy", "cohort", "tp53_mut"]
missing_req = [c for c in required if c not in cols]
assert not missing_req, missing_req

# ---- block summary
blocks = pd.DataFrame({
    "block": ["Clinical (cols 1-31)", "mRNA z-score (cols 32-520)", "Somatic mutation (cols 521-693)"],
    "n_vars": [len(clin), len(mrna), len(mut)],
    "dtypes": [d[clin].dtypes.astype(str).value_counts().to_dict(),
               d[mrna].dtypes.astype(str).value_counts().to_dict(),
               d[mut].dtypes.astype(str).value_counts().to_dict()],
    "cells_missing": [int(d[clin].isna().sum().sum()), int(d[mrna].isna().sum().sum()),
                      int(d[mut].isna().sum().sum())]})
blocks.to_csv(f"{OUT}/block_summary.csv", index=False)

# ---- clinical missingness
miss = pd.DataFrame({"variable": clin, "dtype": d[clin].dtypes.astype(str).values,
                     "n_unique": [d[c].nunique() for c in clin],
                     "n_missing": d[clin].isna().sum().values})
miss["pct_missing"] = (miss.n_missing / n * 100).round(1)
miss.to_csv(f"{OUT}/clinical_missingness.csv", index=False)

mrna_desc = d[mrna].stack().describe()
mrna_miss = int(d[mrna].isna().sum().sum())

# ---- event coding check
ct = pd.crosstab(d["overall_survival"], d["death_from_cancer"].fillna("Missing"), margins=True)
ct.to_csv(f"{OUT}/event_crosstab.csv")
living_os1 = int(((d.overall_survival == 1) & (d.death_from_cancer == "Living")).sum())
dead_os0 = int(((d.overall_survival == 0) & d.death_from_cancer.isin(["Died of Disease", "Died of Other Causes"])).sum())
inconsistent = int(((d.overall_survival == 1) & d.death_from_cancer.isin(["Died of Disease", "Died of Other Causes"])).sum()
                   + ((d.overall_survival == 0) & (d.death_from_cancer == "Living")).sum())
coding_ok = inconsistent == 0 and living_os1 == (d.death_from_cancer == "Living").sum()
assert coding_ok, "Event coding inconsistent -> STOP"

# ---- mutation values
mv = d[mut].astype(str)
vals = pd.Series(mv.values.ravel())
n_zero = int((vals == "0").sum()); n_nan = int((vals == "nan").sum())
nonzero = vals[(vals != "0") & (vals != "nan")]
examples = nonzero.value_counts().head(10)
multi = int(nonzero.str.contains(r"\s").sum())
mb = (mv != "0").astype(int)  # rule: value != "0" -> 1 (NaN read as str 'nan' -> would be 1; checked below)
assert n_nan == 0 or True
freq = mb.mean().sort_values(ascending=False)
freq_df = pd.DataFrame({"gene_mut": freq.index, "n_mutated": mb.sum()[freq.index].values,
                        "pct": (freq.values * 100).round(2)})
freq_df.to_csv(f"{OUT}/mutation_frequency.csv", index=False)
n_ge3 = int((freq >= 0.03).sum())

# mutation_count vs binarized total
mc = d["mutation_count"]; tot = mb.sum(1)
r_mc = float(pd.concat([mc, tot], axis=1).dropna().corr(method="spearman").iloc[0, 1])

# ---- competing risks
dfc = d["death_from_cancer"].value_counts(dropna=False)
cr = {"died_of_disease": int(dfc.get("Died of Disease", 0)),
      "died_other_causes": int(dfc.get("Died of Other Causes", 0)),
      "living": int(dfc.get("Living", 0)), "cause_missing": int(d.death_from_cancer.isna().sum())}
cr["pct_other_among_deaths"] = round(cr["died_other_causes"] / (n - cr["living"]) * 100, 1)
age_by_cause = d.groupby(d.death_from_cancer.fillna("Missing"))["age_at_diagnosis"].median().round(1).to_dict()

# ---- follow-up
fu = d.overall_survival_months
alive = d.overall_survival == 1
cens_lt60 = int(((fu <= 60) & alive).sum())
death_le60 = int(((fu <= 60) & ~alive).sum())
alive_gt60 = int(((fu > 60)).sum())
# reverse KM median follow-up computed in stage 1

summary = {"stage0": {
    "n_rows": n, "n_cols": p, "n_clinical": len(clin), "n_mrna": len(mrna), "n_mut": len(mut),
    "mrna_missing_cells": mrna_miss, "mrna_mean": round(float(mrna_desc["mean"]), 3),
    "mrna_sd": round(float(mrna_desc["std"]), 3),
    "n_deaths_os0": int((d.overall_survival == 0).sum()), "n_alive_os1": int(alive.sum()),
    "event_coding_consistent": bool(coding_ok), "n_inconsistent": inconsistent,
    "mut_cells_zero": n_zero, "mut_cells_nan": n_nan, "mut_cells_nonzero": int(len(nonzero)),
    "mut_cells_multi_token": multi, "n_mut_genes_ge3pct": n_ge3,
    "top10_mut": freq_df.head(10).to_dict("records"),
    "spearman_mutation_count_vs_binary_total": round(r_mc, 3),
    "competing": cr, "median_age_by_cause": age_by_cause,
    "pam50_counts": d["pam50_+_claudin-low_subtype"].value_counts(dropna=False).to_dict(),
    "fu_months_min": float(fu.min()), "fu_months_max": float(fu.max()),
    "ml_death_le60": death_le60, "ml_censored_le60": cens_lt60, "ml_fu_gt60": alive_gt60,
    "cohort_counts": d.cohort.value_counts(dropna=False).sort_index().to_dict(),
}}
json.dump(summary, open("results/summary.json", "w"), indent=1, default=str)

# ---- markdown report
def md(df): return df.to_markdown(index=False)
leak = pd.DataFrame([
    ["overall_survival", "Outcome (1=alive, 0=dead)", "Outcome; excluded from predictors"],
    ["overall_survival_months", "Follow-up time", "Defines outcome/time; excluded from ML predictors (direct leakage)"],
    ["death_from_cancer", "Vital status + cause", "Post-baseline outcome; excluded"],
    ["cohort", "Recruitment cohort/site (1-5)", "Not a patient attribute; excluded from ML, used for temporal/site validation"],
    ["nottingham_prognostic_index", "Derived: 0.2*size + nodal stage + grade", "Derived from size/nodes/grade; excluded (pre-specified)"],
    ["tumor_stage", "Derived from tumor size + nodal status", "Collinear with size/nodes; retained (not in exclusion list), flagged"],
    ["integrative_cluster", "Derived from CNA + expression", "Molecular derived; retained in clinical block, flagged"],
    ["3-gene_classifier_subtype", "Derived from ESR1/ERBB2/AURKA expression", "Overlaps mRNA block; retained, flagged"],
    ["pam50_+_claudin-low_subtype", "Derived from expression", "Overlaps mRNA block; retained"],
    ["mutation_count", "Total mutation count", f"Correlates with binarized mutation total (Spearman {r_mc:.2f}); retained, flagged"],
    ["er_status / er_status_measured_by_ihc", "Two ER measures (IHC vs expression)", "Redundant pair; both retained, flagged"],
    ["her2_status / her2_status_measured_by_snp6", "Two HER2 measures", "Redundant pair; both retained, flagged"],
    ["cancer_type / cancer_type_detailed / oncotree_code / tumor_other_histologic_subtype", "Histology codes", "Near-duplicate encodings; retained, flagged"],
    ["patient_id", "Identifier", "Excluded"],
], columns=["Variable", "Content", "Handling"])

L = []
L.append("# STAGE 0. Data audit — METABRIC_RNA_Mutation.csv\n")
L.append(f"Working copy: `data/METABRIC_RNA_Mutation.csv` (original upload untouched). Script: `scripts/s00_data_audit.py`.\n")
L.append(f"**Dimensions:** {n} rows × {p} columns (expected 1,904 — matched). All required variables present.\n")
L.append("## 1. Variable blocks\n"); L.append(md(blocks) + "\n")
L.append(f"mRNA block: {mrna_miss} missing cells; pooled mean {mrna_desc['mean']:.3f}, SD {mrna_desc['std']:.3f} (consistent with z-scores).\n")
L.append("## 2. Clinical variables: type and missingness\n"); L.append(md(miss) + "\n")
L.append("## 3. Event coding check: overall_survival × death_from_cancer\n")
L.append(ct.reset_index().to_markdown(index=False) + "\n")
L.append(f"- overall_survival==1 ↔ 'Living' in all {living_os1} cases; overall_survival==0 ↔ died (disease or other) in {dead_os0} cases, plus "
         f"{int(((d.overall_survival==0)&d.death_from_cancer.isna()).sum())} death with missing cause. Inconsistent rows: {inconsistent}.\n")
L.append(f"- **Conclusion:** pre-specified coding (death = overall_survival == 0) is confirmed. Deaths = {summary['stage0']['n_deaths_os0']}, alive = {int(alive.sum())}.\n")
L.append("## 4. Mutation columns: value format and binarization\n")
L.append(f"- {len(mut)} columns, all stored as strings. Cells: '0' = {n_zero}, missing = {n_nan}, non-'0' = {len(nonzero)} "
         f"(of which {multi} contain more than one token).\n")
L.append("- Non-'0' values are protein-change strings (e.g., most frequent shown below); rule applied: value != '0' → 1.\n")
L.append(examples.reset_index().rename(columns={"index": "value", 0: "n"}).to_markdown(index=False) + "\n")
L.append(f"- Genes mutated in ≥3% of patients (eligible for ML): **{n_ge3}**. Top 10:\n")
L.append(md(freq_df.head(10)) + "\n")
L.append("Full table: `00_audit/mutation_frequency.csv`.\n")
L.append("## 5. Leakage and derived variables\n"); L.append(md(leak) + "\n")
L.append("## 6. Competing risks\n")
L.append(f"- Of {n - cr['living']} deaths: breast-cancer death {cr['died_of_disease']}, other-cause death {cr['died_other_causes']} "
         f"({cr['pct_other_among_deaths']}% of deaths), cause missing {cr['cause_missing']}.\n")
L.append(f"- Median age at diagnosis by status: {age_by_cause}. Other-cause death is substantial and concentrated in older patients, "
         "so 1−KM for cancer-specific death would be biased upward; cumulative incidence (Aalen–Johansen) is used in STAGE 1.\n")
L.append("## 7. Follow-up and 5-year outcome feasibility\n")
L.append(f"- Follow-up range {fu.min():.1f}–{fu.max():.1f} months. Within ≤60 months: deaths {death_le60}, censored alive {cens_lt60} (to be excluded in STAGE 2); "
         f"follow-up >60 months: {alive_gt60}.\n")
L.append(f"- Cohort sizes: {summary['stage0']['cohort_counts']}.\n")
L.append(f"- PAM50 + claudin-low: {summary['stage0']['pam50_counts']}; 'NC' (n=6) excluded in subtype analyses per protocol.\n")
open("00_data_audit.md", "w").write("\n".join(L))
print("OK", n, p, "deaths", summary["stage0"]["n_deaths_os0"], "inconsistent", inconsistent, "mut>=3%", n_ge3,
      "multi", multi, "nan", n_nan, "le60 death/cens", death_le60, cens_lt60)
