"""STAGE 3 (final, single conversion): Tables 1-3 as Markdown + Word; manuscript/legends to Word via pandoc."""
import subprocess
import pandas as pd
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.section import WD_ORIENT
from common import *

s = sload()
# ---------- Table 1
t1 = pd.read_csv("01_stats/table1.csv", keep_default_na=False)
t1_note = s["table1"]["note"] + " p values are descriptive and not adjusted for multiple comparisons."
# ---------- Table 2
cx = pd.read_csv("01_stats/cox_multivariable.csv")
t2 = pd.DataFrame({"Variable": cx.label, "HR (95% CI)": [f"{a:.2f} ({b:.2f}–{c:.2f})" for a, b, c in zip(cx.HR, cx.lo, cx.hi)],
                   "p": [fmt_p(p) for p in cx.p], "Schoenfeld test p": [fmt_p(p) for p in cx.PH_p]})
c = s["cox"]
t2_note = (f"Complete-case analysis: n={c['n_complete']:,} ({c['deaths']:,} deaths); {c['n_excl_missing_any']} patients excluded for "
           f"missing tumour size or grade and {c['n_excl_NC']} for PAM50 'NC'. Harrell's C = {c['concordance']:.3f}. "
           "Schoenfeld test with rank-transformed time; see cox_alt1_stratified.csv and cox_alt2_piecewise.csv for models "
           "accommodating non-proportional hazards. HR, hazard ratio; CI, confidence interval.")
# ---------- Table 3
rows = []
for split, key in [("Random 70:30", "ml_random"), ("Cohort 1–3 → 4–5", "ml_cohort")]:
    for m in s[key]["metrics"]:
        rows.append({"Split": split, "Model": m["model"], "Test n (events)": f"{m['n']} ({m['events']})",
                     "AUROC (95% CI)": f"{m['AUROC']:.3f} ({m['AUROC_lo']:.3f}–{m['AUROC_hi']:.3f})",
                     "AUPRC": f"{m['AUPRC']:.3f}", "Brier": f"{m['Brier']:.3f}",
                     "Calibration slope": f"{m['calib_slope']:.2f}", "CITL": f"{m['calib_intercept']:.2f}"})
t3 = pd.DataFrame(rows)
r, k = s["ml_random"]["M3_vs_M1_delong"], s["ml_cohort"]["M3_vs_M1_delong"]
t3_note = (f"M1 clinical logistic regression; M2 LASSO (clinical + mRNA + mutation); M3 XGBoost (same inputs as M2); M4 LASSO (mRNA only). "
           f"AUROC 95% CI from 1,000 bootstrap resamples. M3 − M1 AUROC (DeLong): random split {r['diff']:.3f} "
           f"({r['lo']:.3f} to {r['hi']:.3f}; p={fmt_p(r['p'])}); cohort split {k['diff']:.3f} ({k['lo']:.3f} to {k['hi']:.3f}; "
           f"p={fmt_p(k['p'])}). CITL, calibration-in-the-large; AUPRC, area under the precision–recall curve.")

titles = {"Table 1": "Baseline characteristics by PAM50/claudin-low subtype",
          "Table 2": "Multivariable Cox proportional hazards model for overall survival",
          "Table 3": "Test-set performance of models predicting death within 5 years"}
tabs = [("Table 1", t1, t1_note), ("Table 2", t2, t2_note), ("Table 3", t3, t3_note)]
md = []
for name, df, note in tabs:
    md += [f"## {name}. {titles[name]}\n", df.to_markdown(index=False), f"\n{note}\n"]
open("03_manuscript/tables.md", "w").write("\n".join(md))


def add_table(doc, name, df, note, fs=7.5):
    doc.add_paragraph().add_run(f"{name}. {titles[name]}").bold = True
    t = doc.add_table(rows=1, cols=len(df.columns)); t.style = "Table Grid"
    for j, col in enumerate(df.columns):
        cell = t.rows[0].cells[j]; cell.text = ""; run = cell.paragraphs[0].add_run(str(col)); run.bold = True; run.font.size = Pt(fs)
    for _, row in df.iterrows():
        cells = t.add_row().cells
        for j, v in enumerate(row):
            cells[j].text = ""; run = cells[j].paragraphs[0].add_run(str(v)); run.font.size = Pt(fs)
    p = doc.add_paragraph().add_run(note); p.font.size = Pt(fs); p.italic = True


def landscape(doc):
    sec = doc.sections[0]; sec.orientation = WD_ORIENT.LANDSCAPE
    sec.page_width, sec.page_height = sec.page_height, sec.page_width
    for m in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, m, Cm(1.5))


doc = Document(); landscape(doc)
for i, (name, df, note) in enumerate(tabs):
    if i: doc.add_page_break()
    add_table(doc, name, df, note)
doc.save("03_manuscript/Tables_1-3.docx")
d1 = Document(); landscape(d1); add_table(d1, "Table 1", t1, t1_note); d1.save("01_stats/table1.docx")

# manuscript + legends -> docx (pandoc)
full = open("03_manuscript/manuscript.md").read() + "\n\n" + open("03_manuscript/figure_legends.md").read()
open("results/_manuscript_full.md", "w").write(full)
subprocess.run(["pandoc", "results/_manuscript_full.md", "-o", "03_manuscript/manuscript.docx"], check=True)
subprocess.run(["pandoc", "03_manuscript/cover_letter.md", "-o", "03_manuscript/cover_letter.docx"], check=True)
print("written: Tables_1-3.docx, table1.docx, manuscript.docx, cover_letter.docx")
