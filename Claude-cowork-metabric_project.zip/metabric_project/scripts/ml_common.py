"""Shared ML utilities: cohort construction, train-only preprocessing, models, metrics."""
import numpy as np, pandas as pd
from scipy import stats
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from sklearn.model_selection import StratifiedKFold, RandomizedSearchCV
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from xgboost import XGBClassifier
from common import *

EXCLUDE = ["patient_id", "overall_survival", "death_from_cancer", "cohort", "nottingham_prognostic_index",
           "overall_survival_months"]  # last one: defines the outcome (leakage)
HORIZON = 60


def build_ml_cohort():
    d, clin, mrna, mut = load()
    n0 = len(d)
    d = d[d.pam50 != "NC"].copy(); n_nc = n0 - len(d)
    early_cens = (d.time <= HORIZON) & (d.death == 0)
    excl = d[early_cens].copy()
    d = d[~early_cens].copy()
    d["y"] = ((d.time <= HORIZON) & (d.death == 1)).astype(int)
    clin_pred = [c for c in clin if c not in EXCLUDE]
    info = {"n_start": n0, "n_excl_NC": n_nc, "n_excl_censored_le60": int(early_cens.sum()), "n_ml": len(d),
            "n_events": int(d.y.sum()), "n_nonevents": int((d.y == 0).sum())}
    return d, excl, clin_pred, mrna, mut, info


def split_types(df, cols):
    num = [c for c in cols if pd.api.types.is_numeric_dtype(df[c]) and df[c].nunique() > 2]
    binary_num = [c for c in cols if pd.api.types.is_numeric_dtype(df[c]) and df[c].nunique() <= 2]
    cat = [c for c in cols if not pd.api.types.is_numeric_dtype(df[c])]
    return num, binary_num, cat


def make_preprocessor(df, cols, scale=True):
    num, binn, cat = split_types(df, cols)
    num_steps = [("imp", SimpleImputer(strategy="median"))] + ([("sc", StandardScaler())] if scale else [])
    tr = [("num", Pipeline(num_steps), num)]
    if binn:
        tr.append(("bin", SimpleImputer(strategy="most_frequent"), binn))
    if cat:
        tr.append(("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                                    ("oh", OneHotEncoder(drop="first", handle_unknown="ignore",
                                                         sparse_output=False))]), cat))
    return ColumnTransformer(tr, verbose_feature_names_out=False)


def select_mut(train, mut, thr=0.03):
    f = train[mut].mean()
    return f[f >= thr].index.tolist()


def fit_models(tr, clin_pred, mrna, mut_sel):
    """Fit M1-M4 on training data only. Returns dict of fitted pipelines and their input columns."""
    y = tr.y.values
    cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
    full = clin_pred + mrna + mut_sel
    m = {}
    m["M1"] = (Pipeline([("pre", make_preprocessor(tr, clin_pred)),
                         ("clf", LogisticRegression(C=np.inf, max_iter=5000))]), clin_pred)
    m["M2"] = (Pipeline([("pre", make_preprocessor(tr, full)),
                         ("clf", LogisticRegressionCV(Cs=20, cv=cv, l1_ratios=[1.0], solver="saga", scoring="roc_auc",
                                                      max_iter=5000, random_state=SEED, n_jobs=-1))]), full)
    xgb = Pipeline([("pre", make_preprocessor(tr, full, scale=False)),
                    ("clf", XGBClassifier(random_state=SEED, n_jobs=4, eval_metric="logloss", tree_method="hist"))])
    grid = {"clf__n_estimators": [200, 400, 600], "clf__max_depth": [2, 3, 4], "clf__learning_rate": [0.01, 0.03, 0.05],
            "clf__subsample": [0.7, 0.9], "clf__colsample_bytree": [0.3, 0.5, 0.7], "clf__min_child_weight": [1, 5, 10]}
    m["M3"] = (RandomizedSearchCV(xgb, grid, n_iter=25, cv=cv, scoring="roc_auc", random_state=SEED, n_jobs=1), full)
    m["M4"] = (Pipeline([("pre", make_preprocessor(tr, mrna)),
                         ("clf", LogisticRegressionCV(Cs=20, cv=cv, l1_ratios=[1.0], solver="saga", scoring="roc_auc",
                                                      max_iter=5000, random_state=SEED, n_jobs=-1))]), mrna)
    for k, (est, cols) in m.items():
        est.fit(tr[cols], y)
    return m


def get_pipe(est):
    return est.best_estimator_ if hasattr(est, "best_estimator_") else est


def boot_auc(y, p, n=1000, seed=SEED):
    rng = np.random.default_rng(seed); out = []
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if y[i].min() == y[i].max():
            continue
        out.append(roc_auc_score(y[i], p[i]))
    return np.percentile(out, [2.5, 97.5])


def delong(y, p1, p2):
    """DeLong test for two correlated AUCs."""
    y = np.asarray(y); pos, neg = y == 1, y == 0
    def v(p):
        X, Y = p[pos], p[neg]
        psi = (X[:, None] > Y[None, :]).astype(float) + 0.5 * (X[:, None] == Y[None, :])
        return psi.mean(), psi.mean(1), psi.mean(0)
    a1, v10_1, v01_1 = v(p1); a2, v10_2, v01_2 = v(p2)
    s10 = np.cov(np.vstack([v10_1, v10_2])); s01 = np.cov(np.vstack([v01_1, v01_2]))
    S = s10 / pos.sum() + s01 / neg.sum()
    var = S[0, 0] + S[1, 1] - 2 * S[0, 1]
    z = (a1 - a2) / np.sqrt(var)
    return a1 - a2, (a1 - a2 - 1.96 * np.sqrt(var), a1 - a2 + 1.96 * np.sqrt(var)), 2 * stats.norm.sf(abs(z))


def calib_slope_intercept(y, p):
    import statsmodels.api as sm
    lp = np.log(np.clip(p, 1e-6, 1 - 1e-6) / (1 - np.clip(p, 1e-6, 1 - 1e-6)))
    slope = sm.GLM(y, sm.add_constant(lp), family=sm.families.Binomial()).fit().params[1]
    citl = sm.GLM(y, np.ones_like(lp), family=sm.families.Binomial(), offset=lp).fit().params[0]
    return float(slope), float(citl)


def evaluate(y, preds):
    rows = []
    for k, p in preds.items():
        lo, hi = boot_auc(y, p)
        sl, it = calib_slope_intercept(y, p)
        rows.append({"model": k, "n": len(y), "events": int(y.sum()), "AUROC": roc_auc_score(y, p), "AUROC_lo": lo,
                     "AUROC_hi": hi, "AUPRC": average_precision_score(y, p), "Brier": brier_score_loss(y, p),
                     "calib_slope": sl, "calib_intercept": it})
    return pd.DataFrame(rows)


def net_benefit(y, p, th):
    n = len(y); out = []
    for t in th:
        tp = ((p >= t) & (y == 1)).sum(); fp = ((p >= t) & (y == 0)).sum()
        out.append(tp / n - fp / n * t / (1 - t))
    return np.array(out)
