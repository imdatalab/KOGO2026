"""STAGE 1-1: Table 1 by PAM50 (+claudin-low) subtype; 'NC' excluded."""
import numpy as np, pandas as pd
from scipy import stats
from common import *

d, clin, mrna, mut = load()
n_all = len(d)
d = d[d.pam50 != "NC"].copy()
n_nc = n_all - len(d)
groups = PAM_ORDER
g = d.groupby("pam50")
N = {k: int((d.pam50 == k).sum()) for k in groups}

d["vital_cause"] = d.death_from_cancer.map({"Living": "Alive", "Died of Disease": "Breast cancer death",
                                            "Died of Other Causes": "Other-cause death"})
d["chemotherapy_"] = d.chemotherapy.map({1: "Yes", 0: "No"})
d["hormone_therapy_"] = d.hormone_therapy.map({1: "Yes", 0: "No"})
d["radio_therapy_"] = d.radio_therapy.map({1: "Yes", 0: "No"})
d["grade_"] = d.neoplasm_histologic_grade.map({1.0: "1", 2.0: "2", 3.0: "3"})
d["stage_"] = d.tumor_stage.map({0.0: "0", 1.0: "1", 2.0: "2", 3.0: "3", 4.0: "4"})

cont = [("age_at_diagnosis", "Age at diagnosis, years"), ("tumor_size", "Tumour size, mm"),
        ("lymph_nodes_examined_positive", "Positive lymph nodes, n"), ("mutation_count", "Mutation count"),
        ("nottingham_prognostic_index", "Nottingham Prognostic Index"),
        ("overall_survival_months", "Follow-up, months")]
cat = [("grade_", "Histologic grade", ["1", "2", "3"]),
       ("stage_", "Tumour stage", ["0", "1", "2", "3", "4"]),
       ("er_status", "ER status", ["Positive", "Negative"]),
       ("pr_status", "PR status", ["Positive", "Negative"]),
       ("her2_status", "HER2 status", ["Positive", "Negative"]),
       ("inferred_menopausal_state", "Menopausal state", ["Pre", "Post"]),
       ("type_of_breast_surgery", "Surgery", ["BREAST CONSERVING", "MASTECTOMY"]),
       ("cellularity", "Cellularity", ["Low", "Moderate", "High"]),
       ("chemotherapy_", "Chemotherapy", ["Yes", "No"]),
       ("hormone_therapy_", "Hormone therapy", ["Yes", "No"]),
       ("radio_therapy_", "Radiotherapy", ["Yes", "No"]),
       ("vital_cause", "Vital status", ["Alive", "Breast cancer death", "Other-cause death"])]

rows = []
rows.append({"Variable": "N", **{k: str(N[k]) for k in groups}, "Overall": str(len(d)), "Test": "", "p": ""})
for v, lab in cont:
    x = {k: d.loc[d.pam50 == k, v].dropna() for k in groups}
    normal = all(stats.shapiro(x[k])[1] >= 0.05 for k in groups if len(x[k]) >= 3)
    if normal:
        f = lambda s: f"{s.mean():.1f} ± {s.std():.1f}"
        p = stats.f_oneway(*x.values())[1]; test = "ANOVA"; lab2 = lab + ", mean ± SD"
    else:
        f = lambda s: f"{s.median():.1f} [{s.quantile(.25):.1f}–{s.quantile(.75):.1f}]"
        p = stats.kruskal(*x.values())[1]; test = "Kruskal–Wallis"; lab2 = lab + ", median [IQR]"
    rows.append({"Variable": lab2, **{k: f(x[k]) for k in groups}, "Overall": f(d[v].dropna()),
                 "Test": test, "p": fmt_p(p), "p_raw": p})
    nm = {k: int(d.loc[d.pam50 == k, v].isna().sum()) for k in groups}
    if sum(nm.values()) > 0:
        rows.append({"Variable": "  Missing, n (%)", **{k: f"{nm[k]} ({nm[k]/N[k]*100:.1f})" for k in groups},
                     "Overall": f"{sum(nm.values())} ({sum(nm.values())/len(d)*100:.1f})", "Test": "", "p": ""})

for v, lab, levels in cat:
    sub = d[d[v].notna()]
    tab = pd.crosstab(sub[v], sub.pam50).reindex(index=levels, columns=groups, fill_value=0)
    exp = stats.contingency.expected_freq(tab.values)
    if (exp < 5).mean() > 0.20:
        res = stats.chi2_contingency(tab.values, correction=False, method=stats.PermutationMethod(n_resamples=9999, rng=np.random.default_rng(SEED)))
        test = "Monte Carlo exact (Fisher-type)"
    else:
        res = stats.chi2_contingency(tab.values); test = "χ²"
    p = res.pvalue
    rows.append({"Variable": lab + ", n (%)", **{k: "" for k in groups}, "Overall": "", "Test": test,
                 "p": fmt_p(p), "p_raw": p})
    for lv in levels:
        rows.append({"Variable": f"  {lv}", **{k: f"{tab.loc[lv, k]} ({tab.loc[lv, k]/N[k]*100:.1f})" for k in groups},
                     "Overall": f"{tab.loc[lv].sum()} ({tab.loc[lv].sum()/len(d)*100:.1f})", "Test": "", "p": ""})
    nm = {k: int(d.loc[d.pam50 == k, v].isna().sum()) for k in groups}
    if sum(nm.values()) > 0:
        rows.append({"Variable": "  Missing", **{k: f"{nm[k]} ({nm[k]/N[k]*100:.1f})" for k in groups},
                     "Overall": f"{sum(nm.values())} ({sum(nm.values())/len(d)*100:.1f})", "Test": "", "p": ""})

t1 = pd.DataFrame(rows)
t1.drop(columns=["p_raw"]).fillna("").to_csv("01_stats/table1.csv", index=False)
note = (f"Analysed: {len(d)} of {n_all} patients; excluded PAM50 'NC' n={n_nc}. Percentages use subtype N as denominator; "
        "missing shown as separate rows and excluded from tests. Continuous variables: Shapiro–Wilk p<0.05 in any subtype → "
        "median [IQR] and Kruskal–Wallis, otherwise mean ± SD and ANOVA. Categorical: χ² test, or Monte Carlo permutation "
        "test (9,999 resamples) when >20% of expected counts <5.")
open("01_stats/table1.md", "w").write("# Table 1. Baseline characteristics by PAM50 subtype\n\n"
                                      + t1.drop(columns=["p_raw"]).fillna("").to_markdown(index=False) + "\n\n" + note + "\n")
# gate: N sums
assert sum(N.values()) == len(d)
supdate("table1", {"n_analysed": len(d), "n_excluded_NC": n_nc, "N_by_pam50": N,
                   "p_values": {r["Variable"]: r["p"] for r in rows if r.get("p")},
                   "age_median_overall": float(d.age_at_diagnosis.median()),
                   "age_iqr": [float(d.age_at_diagnosis.quantile(.25)), float(d.age_at_diagnosis.quantile(.75))],
                   "fu_median_obs": float(d.overall_survival_months.median()),
                   "note": note})
print("Table1 rows", len(t1), "N", len(d), N)
print(t1[["Variable", "LumA", "Basal", "Overall", "p"]].head(10).to_string(index=False))
