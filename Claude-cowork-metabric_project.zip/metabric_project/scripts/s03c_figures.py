"""STAGE 3: compose multi-panel manuscript Figures 1-4 (300 dpi TIFF, LZW) from the 300-dpi stage figures."""
import glob
from PIL import Image, ImageDraw, ImageFont
from common import *

Image.MAX_IMAGE_PIXELS = None
FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 90)


def panel(rows, out, W):
    """rows: list of rows, each a list of image paths; each row is scaled to total width W (px)."""
    built, n = [], 0
    for r in rows:
        ims = [Image.open(p).convert("RGB") for p in r]
        h = min(i.height for i in ims)
        ims = [i.resize((int(i.width * h / i.height), h), Image.LANCZOS) for i in ims]
        tw = sum(i.width for i in ims); sc = W / tw
        ims = [i.resize((max(1, int(i.width * sc)), max(1, int(i.height * sc))), Image.LANCZOS) for i in ims]
        row = Image.new("RGB", (W, max(i.height for i in ims)), "white"); x = 0
        for im in ims:
            row.paste(im, (x, 0))
            ImageDraw.Draw(row).text((x + 20, 10), "ABCDEFGH"[n], fill="black", font=FONT); n += 1; x += im.width
        built.append(row)
    canvas = Image.new("RGB", (W, sum(b.height for b in built)), "white"); y = 0
    for b in built:
        canvas.paste(b, (0, y)); y += b.height
    if canvas.height > 2700:  # cap at 9 inches height (300 dpi)
        canvas = canvas.resize((int(canvas.width * 2700 / canvas.height), 2700), Image.LANCZOS)
    canvas.save(out, dpi=(300, 300), compression="tiff_lzw")
    return canvas.size


W = 2250  # 7.5 inches at 300 dpi
sizes = {}
sizes["Figure1"] = panel([["01_stats/fig1_km_pam50.png"], ["01_stats/figS_cif_vs_1mKM.png"]], "03_manuscript/Figure1.tiff", W)
sizes["Figure2"] = panel([["01_stats/fig2_forest.png"], ["01_stats/fig_volcano_genes.png", "01_stats/fig_km_tp53.png"]],
                         "03_manuscript/Figure2.tiff", W)
sizes["Figure3"] = panel([["02_ml/fig_roc.png", "02_ml/fig_calibration.png"],
                          ["02_ml/fig_dca.png", "02_ml/fig_random_vs_cohort_auroc.png"]], "03_manuscript/Figure3.tiff", W)
dep = sorted(glob.glob("02_ml/fig_shap_dependence_*.png"))
sizes["Figure4"] = panel([["02_ml/fig_shap_beeswarm.png"],
                          ["02_ml/fig_shap_waterfall_high_risk.png", "02_ml/fig_shap_waterfall_low_risk.png"], dep],
                         "03_manuscript/Figure4.tiff", W)
print({k: (v, f"{v[0]/300:.1f}x{v[1]/300:.1f} in") for k, v in sizes.items()})
