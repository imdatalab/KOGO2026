"""STAGE 2-5: cohort-based split (train cohorts 1-3, validate cohorts 4-5) vs random split."""
import warnings, joblib
import numpy as np, pandas as pd
from ml_common import *
warnings.filterwarnings("ignore")

d, excl, clin_pred, mrna, mut, info = build_ml_cohort()
tr = d[d.cohort.isin([1, 2, 3])].copy(); te = d[d.cohort.isin([4, 5])].copy()
n_cohort_missing = int(d.cohort.isna().sum())
mut_sel = select_mut(tr, mut)
models = fit_models(tr, clin_pred, mrna, mut_sel)
for k, (est, cols) in models.items():
    joblib.dump(get_pipe(est), f"02_ml/models/{k}_cohort.joblib")
pred = {k: get_pipe(est).predict_proba(te[cols])[:, 1] for k, (est, cols) in models.items()}
yte = te.y.values
met = evaluate(yte, pred)
diff, dci, dp = delong(yte, pred["M3"], pred["M1"])
pd.DataFrame({"y": yte, **pred}).to_csv("results/ml_test_predictions_cohort.csv", index=False)

s = sload()["ml_random"]
rnd = pd.DataFrame(s["metrics"]).set_index("model")
coh = met.set_index("model")
rows = []
for k in ["M1", "M2", "M3", "M4"]:
    rows.append({"model": k,
                 "Random split AUROC (95% CI)": f"{rnd.loc[k,'AUROC']:.3f} ({rnd.loc[k,'AUROC_lo']:.3f}–{rnd.loc[k,'AUROC_hi']:.3f})",
                 "Cohort split AUROC (95% CI)": f"{coh.loc[k,'AUROC']:.3f} ({coh.loc[k,'AUROC_lo']:.3f}–{coh.loc[k,'AUROC_hi']:.3f})",
                 "Random AUPRC": round(rnd.loc[k, "AUPRC"], 3), "Cohort AUPRC": round(coh.loc[k, "AUPRC"], 3),
                 "Random Brier": round(rnd.loc[k, "Brier"], 3), "Cohort Brier": round(coh.loc[k, "Brier"], 3),
                 "Random calib. slope": round(rnd.loc[k, "calib_slope"], 2), "Cohort calib. slope": round(coh.loc[k, "calib_slope"], 2),
                 "Random CITL": round(rnd.loc[k, "calib_intercept"], 2), "Cohort CITL": round(coh.loc[k, "calib_intercept"], 2)})
cmpdf = pd.DataFrame(rows); cmpdf.to_csv("02_ml/random_vs_cohort_split.csv", index=False)
met.round(4).to_csv("02_ml/metrics_cohort_split.csv", index=False)

# AUROC comparison plot data
fig, ax = plt.subplots(figsize=(4.6, 3.6))
x = np.arange(4); w = 0.36
for j, (lab, m, c) in enumerate([("Random split (70:30)", rnd, OI[0]), ("Cohort split (1–3 → 4–5)", coh, OI[1])]):
    v = m.loc[["M1", "M2", "M3", "M4"]]
    ax.errorbar(x + (j - .5) * w, v.AUROC, yerr=[v.AUROC - v.AUROC_lo, v.AUROC_hi - v.AUROC], fmt="o", color=c, capsize=3, label=lab)
ax.set_xticks(x); ax.set_xticklabels(["M1", "M2", "M3", "M4"]); ax.set_ylabel("AUROC (95% CI)"); ax.set_ylim(0.5, 0.9)
ax.axhline(0.5, color="grey", lw=.6); ax.legend(frameon=False, fontsize=7); fig.tight_layout()
fig.savefig("02_ml/fig_random_vs_cohort_auroc.png", dpi=300); plt.close(fig)

supdate("ml_cohort", {"n_train": len(tr), "n_test": len(te), "events_train": int(tr.y.sum()), "events_test": int(yte.sum()),
                      "event_rate_train": round(tr.y.mean(), 4), "event_rate_test": round(yte.mean(), 4),
                      "n_cohort_missing": n_cohort_missing, "n_mut_selected": len(mut_sel),
                      "metrics": met.round(4).to_dict("records"),
                      "M3_vs_M1_delong": {"diff": round(diff, 4), "lo": round(dci[0], 4), "hi": round(dci[1], 4), "p": dp},
                      "xgb_best_params": models["M3"][0].best_params_})
print("train/test", len(tr), len(te), "events", int(tr.y.sum()), int(yte.sum()), "missing cohort", n_cohort_missing)
print(cmpdf.iloc[:, :3].to_string(index=False)); print("M3-M1", round(diff, 3), np.round(dci, 3), round(dp, 4))
