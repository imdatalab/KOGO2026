"""STAGE 2 (1-4, gate): 5-year mortality prediction, stratified 70:30 random split; M1-M4; SHAP."""
import warnings, joblib, os
import numpy as np, pandas as pd
import shap
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, roc_auc_score
from ml_common import *
warnings.filterwarnings("ignore")
os.makedirs("02_ml/models", exist_ok=True)

d, excl, clin_pred, mrna, mut, info = build_ml_cohort()

# ---- 1. excluded early-censored patients vs included (bias check)
def prof(x):
    return {"n": len(x), "age_median": x.age_at_diagnosis.median(), "size_median": x.tumor_size.median(),
            "nodes_median": x.lymph_nodes_examined_positive.median(),
            "grade3_pct": (x.neoplasm_histologic_grade == 3).mean() * 100, "ERneg_pct": (x.er_status == "Negative").mean() * 100,
            "fu_median": x.time.median(), **{f"cohort{int(c)}_pct": (x.cohort == c).mean() * 100 for c in range(1, 6)}}
bias = pd.DataFrame([{"group": "Excluded (censored ≤60 mo)", **prof(excl)},
                     {"group": "Included: event (death ≤60 mo)", **prof(d[d.y == 1])},
                     {"group": "Included: non-event (>60 mo)", **prof(d[d.y == 0])}]).round(1)
bias.to_csv("02_ml/excluded_censoring_bias.csv", index=False)

# ---- 2. stratified 70:30 split
tr, te = train_test_split(d, test_size=0.30, stratify=d.y, random_state=SEED)
mut_sel = select_mut(tr, mut)
models = fit_models(tr, clin_pred, mrna, mut_sel)
for k, (est, cols) in models.items():
    joblib.dump(get_pipe(est), f"02_ml/models/{k}_random.joblib")
pred = {k: get_pipe(est).predict_proba(te[cols])[:, 1] for k, (est, cols) in models.items()}
ytr, yte = tr.y.values, te.y.values

# ---- 3. metrics
met = evaluate(yte, pred)
diff, dci, dp = delong(yte, pred["M3"], pred["M1"])
rng = np.random.default_rng(SEED); bd = []
for _ in range(1000):
    i = rng.integers(0, len(yte), len(yte))
    if yte[i].min() == yte[i].max(): continue
    bd.append(roc_auc_score(yte[i], pred["M3"][i]) - roc_auc_score(yte[i], pred["M1"][i]))
bci = np.percentile(bd, [2.5, 97.5])
met.round(4).to_csv("02_ml/metrics_random_split.csv", index=False)
pd.DataFrame({"y": yte, **pred}).to_csv("results/ml_test_predictions_random.csv", index=False)

names = {"M1": "M1 Clinical logistic", "M2": "M2 LASSO (clin+mRNA+mut)", "M3": "M3 XGBoost (clin+mRNA+mut)",
         "M4": "M4 LASSO (mRNA only)"}
cols4 = dict(zip(["M1", "M2", "M3", "M4"], [OI[0], OI[1], OI[2], OI[3]]))
fig, ax = plt.subplots(figsize=(4.6, 4.4))
for k, p in pred.items():
    f, t, _ = roc_curve(yte, p); r = met.set_index("model").loc[k]
    ax.plot(f, t, color=cols4[k], lw=1.4, label=f"{names[k]}: {r.AUROC:.3f} ({r.AUROC_lo:.3f}–{r.AUROC_hi:.3f})")
ax.plot([0, 1], [0, 1], color="grey", ls="--", lw=.8)
ax.set_xlabel("1 − Specificity"); ax.set_ylabel("Sensitivity"); ax.legend(frameon=False, fontsize=6.5, loc="lower right")
ax.set_title(f"ROC, test set (n={len(yte)}, events={yte.sum()})", fontsize=9)
fig.tight_layout(); fig.savefig("02_ml/fig_roc.png", dpi=300); plt.close(fig)

fig, ax = plt.subplots(figsize=(4.6, 4.4)); cal_rows = []
for k, p in pred.items():
    q = pd.qcut(p, 10, labels=False, duplicates="drop")
    g = pd.DataFrame({"p": p, "y": yte, "q": q}).groupby("q").agg(pred=("p", "mean"), obs=("y", "mean"), n=("y", "size"))
    r = met.set_index("model").loc[k]
    ax.plot(g.pred, g.obs, "o-", color=cols4[k], ms=3, lw=1, label=f"{k}: slope {r.calib_slope:.2f}, CITL {r.calib_intercept:.2f}")
    cal_rows.append(g.assign(model=k))
ax.plot([0, 1], [0, 1], color="grey", ls="--", lw=.8); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
ax.set_xlabel("Predicted probability (decile mean)"); ax.set_ylabel("Observed proportion"); ax.legend(frameon=False, fontsize=7)
ax.set_title("Calibration, test set", fontsize=9)
fig.tight_layout(); fig.savefig("02_ml/fig_calibration.png", dpi=300); plt.close(fig)
pd.concat(cal_rows).reset_index().to_csv("results/ml_calibration_bins_random.csv", index=False)

th = np.arange(0.01, 0.61, 0.01)
nb = pd.DataFrame({"threshold": th, "treat_all": net_benefit(yte, np.ones_like(yte, dtype=float), th), "treat_none": 0.0,
                   **{k: net_benefit(yte, p, th) for k, p in pred.items()}})
nb.to_csv("results/ml_dca_random.csv", index=False)
fig, ax = plt.subplots(figsize=(4.6, 4.4))
ax.plot(th, nb.treat_all, color="grey", lw=1, label="Treat all"); ax.axhline(0, color="black", lw=.8, label="Treat none")
for k in pred: ax.plot(th, nb[k], color=cols4[k], lw=1.4, label=names[k])
ax.set_ylim(-0.05, max(nb.treat_all.max(), 0.25) + 0.02); ax.set_xlabel("Threshold probability"); ax.set_ylabel("Net benefit")
ax.legend(frameon=False, fontsize=6.5); ax.set_title("Decision curve, test set", fontsize=9)
fig.tight_layout(); fig.savefig("02_ml/fig_dca.png", dpi=300); plt.close(fig)

# ---- 4. SHAP for M3
p3 = get_pipe(models["M3"][0]); pre3, xgb = p3.named_steps["pre"], p3.named_steps["clf"]
Xte = pd.DataFrame(pre3.transform(te[models["M3"][1]]), columns=pre3.get_feature_names_out(), index=te.index)
expl = shap.TreeExplainer(xgb)
sv = expl(Xte)
mean_abs = pd.Series(np.abs(sv.values).mean(0), index=Xte.columns).sort_values(ascending=False)
mean_abs.rename("mean_abs_shap").to_csv("02_ml/shap_mean_abs.csv")
pd.DataFrame(sv.values, columns=Xte.columns).to_csv("results/shap_values_test.csv", index=False)
Xte.to_csv("results/shap_features_test.csv", index=False)
json_base = float(np.atleast_1d(sv.base_values)[0])
shap.plots.beeswarm(sv, max_display=20, show=False); plt.gcf().set_size_inches(6.5, 6.5)
plt.xlabel("SHAP value (log-odds contribution to 5-year death)"); plt.tight_layout()
plt.savefig("02_ml/fig_shap_beeswarm.png", dpi=300); plt.close("all")
top3 = mean_abs.index[:3].tolist()
for i, f in enumerate(top3, 1):
    shap.plots.scatter(sv[:, f], color=sv, show=False); plt.gcf().set_size_inches(4.4, 3.6)
    plt.ylabel(f"SHAP value for {f}"); plt.tight_layout()
    plt.savefig(f"02_ml/fig_shap_dependence_{i}_{f}.png", dpi=300); plt.close("all")
pte = pred["M3"]; hi_i, lo_i = int(np.argmax(pte)), int(np.argmin(pte))
for tag, i in [("high_risk", hi_i), ("low_risk", lo_i)]:
    shap.plots.waterfall(sv[i], max_display=12, show=False); plt.gcf().set_size_inches(6.5, 4.8)
    plt.title(f"{tag.replace('_', '-')} patient, predicted risk {pte[i]:.2f}, observed outcome {yte[i]}", fontsize=8)
    plt.tight_layout(); plt.savefig(f"02_ml/fig_shap_waterfall_{tag}.png", dpi=300); plt.close("all")

# LASSO M2 selected features vs SHAP top 20
p2 = get_pipe(models["M2"][0])
coef = pd.Series(p2.named_steps["clf"].coef_.ravel(), index=p2.named_steps["pre"].get_feature_names_out())
sel = coef[coef != 0].sort_values(key=np.abs, ascending=False)
sel.rename("coef").to_csv("02_ml/lasso_M2_selected.csv")
p4 = get_pipe(models["M4"][0])
coef4 = pd.Series(p4.named_steps["clf"].coef_.ravel(), index=p4.named_steps["pre"].get_feature_names_out())
coef4[coef4 != 0].sort_values(key=np.abs, ascending=False).rename("coef").to_csv("02_ml/lasso_M4_selected.csv")
top20 = mean_abs.index[:20].tolist()
cmp = pd.DataFrame({"feature": top20, "shap_rank": range(1, 21), "mean_abs_shap": mean_abs[top20].values,
                    "selected_by_LASSO_M2": [f in sel.index for f in top20],
                    "LASSO_coef": [sel.get(f, 0.0) for f in top20]})
cmp.to_csv("02_ml/shap_top20_vs_lasso.csv", index=False)

# subgroup discrimination (fairness/robustness check, test set)
sg = []
for nm, mask in [("Age <60", te.age_at_diagnosis < 60), ("Age ≥60", te.age_at_diagnosis >= 60),
                 ("ER positive", te.er_status == "Positive"), ("ER negative", te.er_status == "Negative"),
                 ("Premenopausal", te.inferred_menopausal_state == "Pre"), ("Postmenopausal", te.inferred_menopausal_state == "Post")]:
    m = mask.values
    for k in ("M1", "M3"):
        lo, hi = boot_auc(yte[m], pred[k][m])
        sg.append({"subgroup": nm, "model": k, "n": int(m.sum()), "events": int(yte[m].sum()),
                   "AUROC": roc_auc_score(yte[m], pred[k][m]), "lo": lo, "hi": hi})
pd.DataFrame(sg).round(3).to_csv("02_ml/subgroup_auroc.csv", index=False)

# ---- gate: preprocessing fitted on training data only + EPV
checks = {}
pre1 = get_pipe(models["M1"][0]).named_steps["pre"]
num1 = pre1.transformers_[0][2]
imp = pre1.named_transformers_["num"].named_steps["imp"]; sc = pre1.named_transformers_["num"].named_steps["sc"]
checks["M1 imputer medians == training medians"] = bool(np.allclose(imp.statistics_, tr[num1].median().values))
checks["M1 imputer medians != full-data medians (at least one)"] = bool(not np.allclose(imp.statistics_, d[num1].median().values))
checks["M1 scaler means == training (imputed) means"] = bool(np.allclose(
    sc.mean_, tr[num1].fillna(tr[num1].median()).mean().values))
cat1 = pre1.transformers_[-1][2]
oh = pre1.named_transformers_["cat"].named_steps["oh"]
checks["M1 one-hot categories == training categories"] = all(
    set(oh.categories_[j]) == set(tr[c].fillna(tr[c].mode()[0]).unique()) for j, c in enumerate(cat1))
pre2 = get_pipe(models["M2"][0]).named_steps["pre"]
num2 = pre2.transformers_[0][2]
checks["M2 scaler means == training (imputed) means"] = bool(np.allclose(
    pre2.named_transformers_["num"].named_steps["sc"].mean_, tr[num2].fillna(tr[num2].median()).mean().values))
checks["Mutation selection (≥3%) computed on training set"] = mut_sel == select_mut(tr, mut)
checks["No patient overlap train/test"] = len(set(tr.patient_id) & set(te.patient_id)) == 0
nfeat = {k: len(get_pipe(est).named_steps["pre"].get_feature_names_out()) for k, (est, _) in models.items()}
ev_tr = int(ytr.sum())
epv = {k: round(ev_tr / v, 2) for k, v in nfeat.items()}
epv_sel = {"M2_nonzero": int((coef != 0).sum()), "M4_nonzero": int((coef4 != 0).sum())}
gate_ok = all(checks.values())
L = ["# STAGE 2 validation gate\n", "| Check | Result |", "|---|---|"] + [f"| {k} | {'PASS' if v else 'FAIL'} |" for k, v in checks.items()]
L += ["\n## Events per variable (training set)\n", f"Training events: {ev_tr} (non-events {int((ytr == 0).sum())}).\n",
      "| Model | Candidate parameters after encoding | EPV |", "|---|---|---|"]
L += [f"| {k} | {nfeat[k]} | {epv[k]} |" for k in nfeat]
L.append(f"\nLASSO non-zero coefficients: M2 {epv_sel['M2_nonzero']}, M4 {epv_sel['M4_nonzero']}. "
         "EPV < 10 for all candidate sets; M1 is unpenalised and therefore most exposed to overfitting (see calibration slope).")
open("02_ml/gate_stage2.md", "w").write("\n".join(L) + "\n")

best = models["M3"][0].best_params_
supdate("ml_random", {"cohort": info, "n_train": len(tr), "n_test": len(te), "events_train": ev_tr,
                      "events_test": int(yte.sum()), "n_mut_selected": len(mut_sel), "n_clin_pred": len(clin_pred),
                      "clin_pred": clin_pred, "metrics": met.round(4).to_dict("records"),
                      "M3_vs_M1_delong": {"diff": round(diff, 4), "lo": round(dci[0], 4), "hi": round(dci[1], 4), "p": dp},
                      "M3_vs_M1_boot_diff_ci": [round(bci[0], 4), round(bci[1], 4)],
                      "xgb_best_params": best, "xgb_cv_auc": round(models["M3"][0].best_score_, 4),
                      "M2_C": float(np.ravel(p2.named_steps["clf"].C_)[0]), "M4_C": float(np.ravel(p4.named_steps["clf"].C_)[0]),
                      "nfeat": nfeat, "epv": epv, "lasso_nonzero": epv_sel, "shap_top20": mean_abs.head(20).round(4).to_dict(),
                      "shap_top3": top3, "shap_base_value": json_base, "overlap_top20_lasso": int(cmp.selected_by_LASSO_M2.sum()),
                      "waterfall": {"high_pred": round(float(pte[hi_i]), 3), "high_y": int(yte[hi_i]),
                                    "low_pred": round(float(pte[lo_i]), 3), "low_y": int(yte[lo_i])},
                      "gate": checks, "gate_ok": gate_ok, "bias_table": bias.to_dict("records")})
print(info, "train/test", len(tr), len(te), "events", ev_tr, int(yte.sum()), "mut_sel", len(mut_sel))
print(met.round(3).to_string(index=False))
print("M3-M1 DeLong", round(diff, 3), np.round(dci, 3), dp, "| EPV", epv, epv_sel, "| gate", gate_ok)
print("SHAP top3", top3, "overlap", int(cmp.selected_by_LASSO_M2.sum()))
