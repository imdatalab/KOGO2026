"""STAGE 1-3: multivariable Cox model for overall survival, PH diagnostics, alternatives."""
import numpy as np, pandas as pd
from lifelines import CoxPHFitter, CoxTimeVaryingFitter
from lifelines.statistics import proportional_hazard_test
from statsmodels.stats.multitest import multipletests
from common import *

d, *_ = load()
n0 = len(d)
d = d[d.pam50 != "NC"].copy(); n_nc = n0 - len(d)
X = pd.DataFrame({
    "time": d.time, "death": d.death,
    "age_10y": d.age_at_diagnosis / 10, "size_10mm": d.tumor_size / 10,
    "nodes_pos": d.lymph_nodes_examined_positive,
    "grade_2": (d.neoplasm_histologic_grade == 2).astype(float), "grade_3": (d.neoplasm_histologic_grade == 3).astype(float),
    "ER_pos": (d.er_status == "Positive").astype(float), "HER2_pos": (d.her2_status == "Positive").astype(float),
    "chemo": d.chemotherapy.astype(float), "hormone": d.hormone_therapy.astype(float), "radio": d.radio_therapy.astype(float)})
for k in PAM_ORDER[1:]:
    X[f"pam50_{k}"] = (d.pam50 == k).astype(float)
X.loc[d.neoplasm_histologic_grade.isna(), ["grade_2", "grade_3"]] = np.nan
miss_size = int(d.tumor_size.isna().sum()); miss_grade = int(d.neoplasm_histologic_grade.isna().sum())
miss_any = int(X.isna().any(axis=1).sum())
X = X.dropna(); ncc = len(X)
X["pam50"] = d.loc[X.index, "pam50"]
covs = [c for c in X.columns if c not in ("time", "death", "pam50")]

cph = CoxPHFitter().fit(X[["time", "death"] + covs], "time", "death")
labels = {"age_10y": "Age (per 10 years)", "size_10mm": "Tumour size (per 10 mm)", "nodes_pos": "Positive nodes (per node)",
          "grade_2": "Grade 2 vs 1", "grade_3": "Grade 3 vs 1", "ER_pos": "ER positive vs negative",
          "HER2_pos": "HER2 positive vs negative", "chemo": "Chemotherapy (yes vs no)",
          "hormone": "Hormone therapy (yes vs no)", "radio": "Radiotherapy (yes vs no)",
          **{f"pam50_{k}": f"PAM50 {k} vs LumA" for k in PAM_ORDER[1:]}}
s = cph.summary
hr = pd.DataFrame({"term": s.index, "label": [labels[i] for i in s.index], "HR": s["exp(coef)"],
                   "lo": s["exp(coef) lower 95%"], "hi": s["exp(coef) upper 95%"], "p": s["p"]}).reset_index(drop=True)

# Schoenfeld-residual based PH test (rank time transform)
ph = proportional_hazard_test(cph, X[["time", "death"] + covs], time_transform="rank").summary.reset_index()
ph.columns = ["term", "chi2", "p", "log2p"]
ph["label"] = ph.term.map(labels)
hr = hr.merge(ph[["term", "chi2", "p"]].rename(columns={"chi2": "PH_chi2", "p": "PH_p"}), on="term")
hr.to_csv("01_stats/cox_multivariable.csv", index=False)
violators = ph.loc[ph.p < 0.05, "term"].tolist()

# Alternative 1: stratified Cox (violators as strata; continuous violators by tertile)
X1 = X.copy(); strata = []
for v in violators:
    if X1[v].nunique() > 2:
        X1[v + "_t3"] = pd.qcut(X1[v], 3, labels=False, duplicates="drop"); strata.append(v + "_t3")
    else:
        strata.append(v)
pam_viol = [v for v in violators if v.startswith("pam50_")]
if pam_viol:  # stratify on the full subtype factor rather than single dummies
    strata = [s_ for s_ in strata if not s_.startswith("pam50_")] + ["pam50_code"]
    X1["pam50_code"] = X1.pam50.astype("category").cat.codes
keep1 = [c for c in covs if c not in violators and not (pam_viol and c.startswith("pam50_"))]
cph1 = CoxPHFitter().fit(X1[["time", "death"] + keep1 + strata], "time", "death", strata=strata)
a1 = cph1.summary[["exp(coef)", "exp(coef) lower 95%", "exp(coef) upper 95%", "p"]]
a1.columns = ["HR", "lo", "hi", "p"]; a1.insert(0, "model", "Alt1_stratified"); a1.to_csv("01_stats/cox_alt1_stratified.csv")

# Alternative 2: piecewise-constant HR for violators (0-60 vs >60 months) via episode splitting
CUT = 60
ep = []
for i, r in X.iterrows():
    if r.time <= CUT:
        ep.append({**r[covs].to_dict(), "id": i, "start": 0, "stop": r.time, "event": r.death, "late": 0})
    else:
        ep.append({**r[covs].to_dict(), "id": i, "start": 0, "stop": CUT, "event": 0, "late": 0})
        ep.append({**r[covs].to_dict(), "id": i, "start": CUT, "stop": r.time, "event": r.death, "late": 1})
E = pd.DataFrame(ep)
E = E[E.stop > E.start]
tv_terms = []
for v in violators:
    E[v + "_x_late"] = E[v] * E["late"]; tv_terms.append(v + "_x_late")
ctv = CoxTimeVaryingFitter().fit(E[["id", "start", "stop", "event"] + covs + tv_terms], id_col="id",
                                 event_col="event", start_col="start", stop_col="stop")
cs = ctv.summary; cov_mat = pd.DataFrame(np.asarray(ctv.variance_matrix_), index=cs.index, columns=cs.index)
a2 = []
for v in violators:
    b0, b1 = cs.loc[v, "coef"], cs.loc[v + "_x_late", "coef"]
    se0 = cs.loc[v, "se(coef)"]
    var_late = cov_mat.loc[v, v] + cov_mat.loc[v + "_x_late", v + "_x_late"] + 2 * cov_mat.loc[v, v + "_x_late"]
    se1 = np.sqrt(var_late)
    a2.append({"term": v, "label": labels[v],
               "HR_0_60": np.exp(b0), "lo_0_60": np.exp(b0 - 1.96 * se0), "hi_0_60": np.exp(b0 + 1.96 * se0),
               "HR_gt60": np.exp(b0 + b1), "lo_gt60": np.exp(b0 + b1 - 1.96 * se1), "hi_gt60": np.exp(b0 + b1 + 1.96 * se1),
               "p_interaction": cs.loc[v + "_x_late", "p"]})
a2 = pd.DataFrame(a2); a2.to_csv("01_stats/cox_alt2_piecewise.csv", index=False)

# Forest plot
fig, ax = plt.subplots(figsize=(6.6, 5.2))
y = np.arange(len(hr))[::-1]
col = [OI[5] if t in violators else OI[0] for t in hr.term]
for yy, r, c in zip(y, hr.itertuples(), col):
    ax.plot([r.lo, r.hi], [yy, yy], color=c, lw=1.2)
ax.scatter(hr.HR, y, c=col, s=22, marker="s", zorder=3)
ax.axvline(1, color="grey", ls="--", lw=0.8); ax.set_xscale("log")
ax.set_yticks(y); ax.set_yticklabels(hr.label, fontsize=8)
for yy, r in zip(y, hr.itertuples()):
    ax.text(1.02, yy, f"{r.HR:.2f} ({r.lo:.2f}–{r.hi:.2f})", transform=ax.get_yaxis_transform(), fontsize=7, va="center")
ax.set_xlabel("Hazard ratio (95% CI), log scale")
ax.set_title(f"Multivariable Cox model, overall survival (n={ncc}, deaths={int(X.death.sum())})", fontsize=9)
ax.text(0, -0.13, "Orange: proportional-hazards assumption violated (Schoenfeld test p<0.05)", transform=ax.transAxes, fontsize=7, color=OI[5])
fig.subplots_adjust(left=0.30, right=0.78, bottom=0.14)
fig.savefig("01_stats/fig2_forest.png", dpi=300); plt.close(fig)

# indication pattern for chemotherapy (descriptive)
cc = d.loc[X.index]
ind = cc.groupby("chemotherapy").agg(n=("age_at_diagnosis", "size"), age=("age_at_diagnosis", "median"),
                                     nodes=("lymph_nodes_examined_positive", "median"),
                                     grade3=("neoplasm_histologic_grade", lambda s: (s == 3).mean()),
                                     ERneg=("er_status", lambda s: (s == "Negative").mean()),
                                     death=("death", "mean")).round(3)
ind.to_csv("01_stats/chemo_indication_profile.csv")

age_row = hr[hr.term == "age_10y"].iloc[0]; ch = hr[hr.term == "chemo"].iloc[0]
summ = {"n_start": n0, "n_excl_NC": n_nc, "n_missing_size": miss_size, "n_missing_grade": miss_grade,
        "n_excl_missing_any": miss_any, "n_complete": ncc, "deaths": int(X.death.sum()),
        "concordance": round(cph.concordance_index_, 3),
        "HR": hr[["term", "HR", "lo", "hi", "p", "PH_p"]].round(4).to_dict("records"),
        "violators": violators, "alt1_strata": strata, "alt2_cut_months": CUT,
        "alt2": a2.round(4).to_dict("records"), "alt1": a1.reset_index().round(4).to_dict("records"),
        "chemo_profile": ind.reset_index().to_dict("records"),
        "gate_age_HR_gt1": bool(age_row.HR > 1)}
supdate("cox", summ)

# chemotherapy confounding-by-indication note
txt = f"""# Cox model notes

Complete-case model: {ncc} of {n0 - n_nc} patients (PAM50 'NC' n={n_nc} excluded beforehand; {miss_any} excluded for missing tumour size and/or grade). Deaths: {int(X.death.sum())}. Harrell's C = {cph.concordance_index_:.3f}.

## Proportional hazards
Schoenfeld residual test (rank time transform) flagged: {', '.join(labels[v] for v in violators) if violators else 'none'}.

Alternative 1 — stratified Cox: strata = {strata} (continuous violators by tertile); HRs for non-violating covariates in `cox_alt1_stratified.csv`.
Alternative 2 — piecewise-constant (time-varying) coefficients with a split at {CUT} months; period-specific HRs in `cox_alt2_piecewise.csv`.

## Chemotherapy HR and confounding by indication
Chemotherapy was associated with HR {ch.HR:.2f} (95% CI {ch.lo:.2f}–{ch.hi:.2f}; p={fmt_p(ch.p)}). Treatment was not randomised: in this cohort patients receiving chemotherapy were younger and had more nodes, more grade 3 and more ER-negative tumours (see `chemo_indication_profile.csv`). Residual confounding by indication (unmeasured disease extent, performance status, treatment era/centre) means this HR should be read as an association within a treated-by-indication population, not as an estimate of treatment effect. Strong negative confounding by age (younger, fitter patients selected for chemotherapy, with lower other-cause mortality) operates in the opposite direction, so the net direction of bias cannot be determined from these data.
"""
open("01_stats/cox_notes.md", "w").write(txt)
print("complete", ncc, "excluded", miss_any, "deaths", int(X.death.sum()), "C", round(cph.concordance_index_, 3))
print(hr[["label", "HR", "lo", "hi", "p", "PH_p"]].round(3).to_string(index=False))
print("violators", violators)
