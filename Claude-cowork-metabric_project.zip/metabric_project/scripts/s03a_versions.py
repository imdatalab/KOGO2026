"""STAGE 3: record software versions actually used in this environment."""
import json, platform, subprocess, importlib, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
pk = ["numpy", "pandas", "scipy", "statsmodels", "sklearn", "lifelines", "xgboost", "shap", "matplotlib", "docx"]
v = {"python": platform.python_version()}
for p in pk:
    v["python-docx" if p == "docx" else ("scikit-learn" if p == "sklearn" else p)] = importlib.import_module(p).__version__ \
        if hasattr(importlib.import_module(p), "__version__") else "n/a"
r = subprocess.run(["Rscript", "-e", 'cat(paste(R.version$major, R.version$minor, sep="."), as.character(packageVersion("survival")))'],
                   capture_output=True, text=True).stdout.split()
v["R"], v["survival"] = r[0], r[1]
json.dump(v, open("results/versions.json", "w"), indent=1)
print(v)
