"""STAGE 1 validation gate + stage report (reads only results/summary.json and 01_stats/*.csv)."""
import pandas as pd
from common import *

s = sload()
fg = pd.read_csv("01_stats/finegray_bc_death.csv")
supdate("finegray", fg.round(4).to_dict("records"))
s = sload()
t1, km, cx, cr, gn = s["table1"], s["km"], s["cox"], s["competing"], s["genomics"]
tp53 = pd.read_csv("01_stats/tp53_by_pam50.csv")
checks = {
    "KM starts at 1 and is non-increasing (all subtypes)": km["gate_km_start1_monotone"],
    "Age HR > 1 (multivariable Cox)": cx["gate_age_HR_gt1"],
    "Age HR > 1 (cause-specific, both causes)": all(r["HR"] > 1 for r in cr["age_HR_cause_specific"]),
    "Table 1 subtype N sum = analysed N": sum(t1["N_by_pam50"].values()) == t1["n_analysed"],
    "Table 1 N + NC excluded = 1904": t1["n_analysed"] + t1["n_excluded_NC"] == 1904,
    "KM N = Table 1 N": km["n"] == t1["n_analysed"],
    "KM number-at-risk at t=0 = KM N": km["risk_sum_t0"] == km["n"],
    "KM subtype n sum = KM N": sum(r["n"] for r in km["by_subtype"]) == km["n"],
    "Cox complete + excluded = Table 1 N": cx["n_complete"] + cx["n_excl_missing_any"] == t1["n_analysed"],
    "Cause-specific N + cause-missing + missing covariates = Table 1 N":
        cr["n_cause_specific"] + cr["n_excl_cause_missing"] + cx["n_excl_missing_any"] == t1["n_analysed"],
    "Fine-Gray N = cause-specific N": int(fg.n.iloc[0]) == cr["n_cause_specific"],
    "Genomics N = Table 1 N": gn["n"] == t1["n_analysed"],
    "TP53-by-PAM50 n sum = Table 1 N": int(tp53.n.sum()) == t1["n_analysed"],
}
ok = all(checks.values())
supdate("gate_stage1", {"checks": {k: bool(v) for k, v in checks.items()}, "all_pass": ok})
L = ["# STAGE 1 validation gate\n", "| Check | Result |", "|---|---|"]
L += [f"| {k} | {'PASS' if v else 'FAIL'} |" for k, v in checks.items()]
L.append(f"\nCompeting-risk accounting (cause-specific/Fine-Gray complete cases + death with missing cause + missing size/grade): "
         f"{cr['n_cause_specific']} + {cr['n_excl_cause_missing']} + {cx['n_excl_missing_any']} = "
         f"{cr['n_cause_specific'] + cr['n_excl_cause_missing'] + cx['n_excl_missing_any']}.")
open("01_stats/gate_stage1.md", "w").write("\n".join(L) + "\n")
for k, v in checks.items():
    print("PASS" if v else "FAIL", "|", k)
print("ALL PASS" if ok else "GATE FAILED")
