"""Shared helpers: paths, data loading, palette, summary.json I/O."""
import json, os
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SEED = 42
# Okabe-Ito colour-blind-safe palette
OI = ["#0072B2", "#E69F00", "#009E73", "#CC79A7", "#56B4E9", "#D55E00", "#F0E442", "#000000"]
PAM_ORDER = ["LumA", "LumB", "Her2", "Basal", "claudin-low", "Normal"]
PAM_COL = dict(zip(PAM_ORDER, OI[:6]))
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.dpi": 300})


def load():
    d = pd.read_csv("data/METABRIC_RNA_Mutation.csv", low_memory=False)
    cols = list(d.columns)
    clin, mrna, mut = cols[:31], cols[31:520], cols[520:]
    d = d.rename(columns={"pam50_+_claudin-low_subtype": "pam50"})
    clin = ["pam50" if c == "pam50_+_claudin-low_subtype" else c for c in clin]
    d["death"] = (d["overall_survival"] == 0).astype(int)          # pre-specified event coding
    d["time"] = d["overall_survival_months"]
    d[mut] = (d[mut].astype(str) != "0").astype(int)                 # value != "0" -> 1
    return d, clin, mrna, mut


def sload():
    return json.load(open("results/summary.json"))


def supdate(key, obj):
    s = sload(); s[key] = obj
    json.dump(s, open("results/summary.json", "w"), indent=1, default=str)


def fmt_p(p):
    return "<0.001" if p < 0.001 else f"{p:.3f}"
