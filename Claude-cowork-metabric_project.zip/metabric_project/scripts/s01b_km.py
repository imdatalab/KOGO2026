"""STAGE 1-2: Kaplan-Meier overall survival by PAM50 subtype (NC excluded)."""
import numpy as np, pandas as pd
from lifelines import KaplanMeierFitter
from lifelines.statistics import multivariate_logrank_test, pairwise_logrank_test
from lifelines.utils import median_survival_times
from common import *

d, *_ = load()
d = d[d.pam50 != "NC"].copy()
TICKS = [0, 60, 120, 180, 240, 300]

# reverse KM median follow-up
rk = KaplanMeierFitter().fit(d.time, 1 - d.death)
fu_med = float(rk.median_survival_time_)

lr = multivariate_logrank_test(d.time, d.pam50, d.death)
pw = pairwise_logrank_test(d.time, d.pam50, d.death).summary.reset_index()
pw.columns = ["group1", "group2", "chi2", "p", "log2p"]
from statsmodels.stats.multitest import multipletests
pw["q_BH"] = multipletests(pw.p, method="fdr_bh")[1]
pw.to_csv("01_stats/km_pairwise_logrank.csv", index=False)

fig = plt.figure(figsize=(7.2, 5.6))
ax = fig.add_axes([0.11, 0.33, 0.85, 0.62]); axr = fig.add_axes([0.11, 0.04, 0.85, 0.18])
rows, curves, risk = [], [], {}
for k in PAM_ORDER:
    s = d[d.pam50 == k]
    km = KaplanMeierFitter(label=k).fit(s.time, s.death)
    sf = km.survival_function_; ci = km.confidence_interval_
    cdf = pd.DataFrame({"pam50": k, "time": sf.index, "S": sf.iloc[:, 0].values,
                        "lo": ci.iloc[:, 0].values, "hi": ci.iloc[:, 1].values})
    curves.append(cdf)
    ax.step(sf.index, sf.iloc[:, 0], where="post", color=PAM_COL[k], lw=1.4, label=f"{k} (n={len(s)})")
    ax.fill_between(ci.index, ci.iloc[:, 0], ci.iloc[:, 1], step="post", color=PAM_COL[k], alpha=0.12, lw=0)
    out = {"pam50": k, "n": len(s), "events": int(s.death.sum())}
    for t in (60, 120):
        S = float(km.survival_function_at_times(t).iloc[0])
        idx = ci.index[ci.index <= t].max(); lo, hi = ci.loc[idx].values
        out[f"S{t//12}y"] = round(S, 3); out[f"S{t//12}y_lo"] = round(float(lo), 3); out[f"S{t//12}y_hi"] = round(float(hi), 3)
    med = km.median_survival_time_
    mci = median_survival_times(ci)
    out["median_months"] = None if np.isinf(med) else round(float(med), 1)
    out["median_lo"] = None if np.isinf(mci.iloc[0, 0]) else round(float(mci.iloc[0, 0]), 1)
    out["median_hi"] = None if np.isinf(mci.iloc[0, 1]) else round(float(mci.iloc[0, 1]), 1)
    rows.append(out)
    risk[k] = [int((s.time >= t).sum()) for t in TICKS]
ax.set_xlim(0, 300); ax.set_ylim(0, 1.02); ax.set_xticks(TICKS)
ax.set_xlabel("Time since diagnosis (months)"); ax.set_ylabel("Overall survival probability")
ax.legend(frameon=False, fontsize=8, loc="lower left")
ax.text(298, 0.97, f"Log-rank χ²={lr.test_statistic:.1f}, df={len(PAM_ORDER)-1}, p{'<0.001' if lr.p_value<0.001 else '='+format(lr.p_value,'.3f')}",
        ha="right", fontsize=8)
axr.set_xlim(0, 300); axr.set_ylim(-0.5, len(PAM_ORDER) - 0.5); axr.axis("off")
axr.set_title("Number at risk", fontsize=8, loc="left")
for i, k in enumerate(PAM_ORDER):
    y = len(PAM_ORDER) - 1 - i
    axr.text(-8, y, k, ha="right", va="center", fontsize=7, color=PAM_COL[k])
    for t, nr in zip(TICKS, risk[k]):
        axr.text(t, y, str(nr), ha="center", va="center", fontsize=7)
fig.savefig("01_stats/fig1_km_pam50.png", dpi=300); plt.close(fig)

res = pd.DataFrame(rows); res.to_csv("01_stats/km_summary.csv", index=False)
pd.concat(curves).to_csv("results/km_pam50_curves.csv", index=False)
pd.DataFrame(risk, index=TICKS).T.to_csv("results/km_pam50_risk.csv")
# gate
cv = pd.concat(curves)
gate = bool(all(g.sort_values("time").S.iloc[0] == 1.0 and (np.diff(g.sort_values("time").S) <= 1e-12).all()
                for _, g in cv.groupby("pam50")))
supdate("km", {"n": len(d), "events": int(d.death.sum()), "logrank_chi2": round(lr.test_statistic, 2),
               "logrank_df": len(PAM_ORDER) - 1, "logrank_p": lr.p_value, "median_followup_reverseKM": round(fu_med, 1),
               "by_subtype": rows, "gate_km_start1_monotone": gate, "risk_sum_t0": int(sum(r[0] for r in risk.values()))})
print("N", len(d), "events", int(d.death.sum()), "logrank", round(lr.test_statistic, 1), "p", lr.p_value, "gate", gate, "FU", round(fu_med, 1))
print(res.to_string(index=False))
